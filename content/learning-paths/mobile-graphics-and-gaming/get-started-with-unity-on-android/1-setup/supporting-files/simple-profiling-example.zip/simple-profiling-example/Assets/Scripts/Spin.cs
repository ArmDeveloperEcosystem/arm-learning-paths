using UnityEngine;
//using UnityEngine.Profiling;

public class Spin : MonoBehaviour
{
    public Vector3 rotation;

    // Update is called once per frame
    void Update()
    {
//        Profiler.BeginSample("Something1");
        DoSomething1();
//        Profiler.EndSample();

//        Profiler.BeginSample("Something2");
        DoSomething2();
//        Profiler.EndSample();
    }

    void DoSomething1() {
        System.Threading.Thread.Sleep(100);
    }

    void DoSomething2() {
        transform.Rotate(rotation * Time.deltaTime);
    }
}
