﻿/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using Character;
using UnityEngine;
using UnityEngine.UI;

namespace UI {
	public class HealthBar : AbstractPlayerManagerUiInterface
	{
		[SerializeField] Image _image;

		protected override void OnNewCharacterAssigned()
		{
			_currentPlayer.Stats.HealthUpdatedEvent += HandelHealthUpdatedEvent;
			_image.fillAmount = _currentPlayer.Stats.CurrentHealthPercent;
		}


		private void HandelHealthUpdatedEvent(object sender, HealthUpdatedEventArgs e)
		{
			SetCurrentHealth(((float)e.CurrentHealth / (float)e.MaxHealth));
		}

		private void SetCurrentHealth(float healthPercent)
		{
			_image.fillAmount = healthPercent;
		}

		private void OnDestroy()
		{
			if (_currentPlayer != null)
			{
				_currentPlayer.Stats.HealthUpdatedEvent -= HandelHealthUpdatedEvent;
			}
		}

	}
}
