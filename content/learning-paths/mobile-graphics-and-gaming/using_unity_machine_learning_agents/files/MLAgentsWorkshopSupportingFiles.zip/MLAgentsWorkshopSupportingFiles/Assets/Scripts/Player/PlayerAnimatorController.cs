/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using Animation;
using UnityEngine;

namespace Player
{
	public class PlayerAnimatorController : AbstractAnimatorController
	{
		[SerializeField] CharacterController _characterController;

		protected override void OnAnimatorMove()
		{
			if (IsInteracting == false)
			{
				return;
			}

			Vector3 deltaPosition = _animator.deltaPosition;
			deltaPosition.y = 0;
			Vector3 velocity = deltaPosition / Time.deltaTime;
			_characterController.SimpleMove(velocity);
		}
	}
}
