/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuGdcDemoAutoDemoTimer : AbstractAnimationEvaluatiorBehaviour
{
	[SerializeField] GameObject _visulizationGO;
	[SerializeField] AnimationCurve _gameObjectXScaleAniamation;


	public override void Evaluate(float percentComplete)
	{
		_visulizationGO.transform.localScale = new Vector3(_gameObjectXScaleAniamation.Evaluate(percentComplete), _visulizationGO.transform.localScale.y, _visulizationGO.transform.localScale.z);

	}

	public override void OnAnimationComplete()
	{

	}

	public override void OnPlay()
	{

	}


}
