/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using UnityEngine;

namespace UI
{
	public class DisableCanvasOnAbstractAnimationComplete : MonoBehaviour
	{
		[SerializeField] AbstractAnimationEvaluatiorBehaviour _animator;
		[SerializeField] Canvas _canvas;

		private void Awake()
		{
			_animator.Ended += _animator_Ended;
		}

		private void _animator_Ended(object sender, System.EventArgs e)
		{
			_canvas.enabled = false;
		}

		private void OnDestroy()
		{
			if (_animator != null)
			{
				_animator.Ended -= _animator_Ended;
			}
		}
	}
}