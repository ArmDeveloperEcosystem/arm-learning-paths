﻿/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using Animation;
using Character;
using Player;
using UnityEngine;

namespace Ability {
	public class AbilityHandler : MonoBehaviour {

		[SerializeField] AbstractAbility[] _abilities;
		[SerializeField] AbstractCharacterManager _playerManager;

		private AbstractAbility _loadedAbility;
		private int _characterID;

		public AbstractAbility AbilityTwo { get => _abilities[0]; }
		public AbstractAbility[] Abilities { get => _abilities; }

		public void Init(int characterID)
		{
			_characterID = characterID;
			for (int i = 0; i < _abilities.Length; i++)
			{
				_abilities[i].InitilizeAbility(_playerManager);
			}
		}

		public void LoadAbility(int abilityNumber)
		{
			_loadedAbility = _abilities[abilityNumber];
			_loadedAbility.LoadAbility();
			_playerManager.SendLoadedAbilityEvent(abilityNumber);
		}

		public void FireAbility()
		{
			var abilityGameObject = _loadedAbility.FireAbility();
			_playerManager.SendFiredAbilityEvent(abilityGameObject);
			
		}

	}
}
