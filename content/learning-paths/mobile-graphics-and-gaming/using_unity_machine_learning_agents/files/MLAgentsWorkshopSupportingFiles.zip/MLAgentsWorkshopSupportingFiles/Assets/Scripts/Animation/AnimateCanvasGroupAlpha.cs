/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using UnityEngine;

namespace Animation
{
	public class AnimateCanvasGroupAlpha : AbstractAnimationEvaluatiorBehaviour
	{

		[SerializeField] CanvasGroup _canvasGroup;
		[SerializeField]AnimationCurve _animation;

		public override void Evaluate(float percentComplete)
		{
			_canvasGroup.alpha = _animation.Evaluate(percentComplete);
		}

		public override void OnAnimationComplete()
		{
			
		}

		public override void OnPlay()
		{
			
		}
	}
}