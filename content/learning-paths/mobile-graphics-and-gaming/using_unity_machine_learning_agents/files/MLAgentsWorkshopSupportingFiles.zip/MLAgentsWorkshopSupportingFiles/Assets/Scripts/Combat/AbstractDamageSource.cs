﻿/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using Character;
using System;
using UnityEngine;

namespace Combat
{
	public abstract class AbstractDamageSource : MonoBehaviour
	{
		public AbstractCharacterManager Owner { get; protected set; }

		public int CharacterID { get => Owner.CharacterID;  }

		public TeamID CharacterTeamID { get => Owner.TeamID; }
    }

	public enum AffixType
	{
		Physical, Fire
	}

    public class DamageSourceCollisionEventArgs: EventArgs
	{
		public Collider HittingCollider;
		public AbstractDamageable Damageable;
		public Collider ColliderHit;
	}
}
