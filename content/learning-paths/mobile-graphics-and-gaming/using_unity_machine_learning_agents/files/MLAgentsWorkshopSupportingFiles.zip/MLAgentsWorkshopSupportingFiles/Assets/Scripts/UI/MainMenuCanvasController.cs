/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using System;
using UnityEngine;

namespace UI
{
	public class MainMenuCanvasController : MonoBehaviour
	{
		[SerializeField] Canvas _canvas;
		[SerializeField] AbstractAnimationEvaluatiorBehaviour[] _hideAnimations;
		[SerializeField] AbstractAnimationEvaluatiorBehaviour[] _showAnimations;
		[SerializeField] CanvasGroup _canvasGroup;
	


		public void Hide()
		{
			_canvasGroup.interactable = false;
			foreach (var animation in _hideAnimations)
			{
				animation.Play();
			}
		}

		public void Show()
		{
			_canvas.enabled = true;
			foreach (var animation in _showAnimations)
			{
				animation.Play();
			}
			_canvasGroup.interactable = true;
		}
	}
}
