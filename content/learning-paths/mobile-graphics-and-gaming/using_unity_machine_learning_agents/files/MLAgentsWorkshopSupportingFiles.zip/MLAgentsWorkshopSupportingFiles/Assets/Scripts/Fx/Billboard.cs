/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Fx
{
    public class Billboard : MonoBehaviour
    {
        [SerializeField]
        SpriteRenderer _sprite;

        private bool _isShown = true;
        Transform _lookAtTarget; 

        public void LookAt(Transform target)
        {
            _lookAtTarget = target;
        }

        public void Show()
        {
            _isShown = true;
            _sprite.enabled = true;
        }

        public void Hide()
        {
            _isShown = false;
            _sprite.enabled = false;
        }

        void LateUpdate()
        {
            if (_isShown && _lookAtTarget != null)
            {
                transform.LookAt(_lookAtTarget);
            }
        }
    }
}
