/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using Character;
using Combat;
using System.Collections;
using UnityEngine;

namespace Ability
{
	public abstract class AbstractProjectileDamageAbility : AbstractDamageSource
	{
		[Header ("Abstract Projectile Damage Ability Parameters")]
		[SerializeField] protected Collider _collider;
		[SerializeField] protected float _projectileForwardVelocity;
		[SerializeField] protected float _projectileUpwardVelocity;
		[SerializeField] protected Rigidbody _rigidbody;
		[SerializeField] protected LayerMask _ignoreLayer;
		[SerializeField] protected float _destoryObjectTimer = 3f;


		private Coroutine _Coroutine;

		public void CastSpell(AbstractCharacterManager owner, Vector3 direction)
		{
			Owner = owner;
			OnCastSpell();
			_rigidbody.AddForce(direction * _projectileForwardVelocity);
			_rigidbody.AddForce(transform.up * _projectileUpwardVelocity);
		}


		protected abstract void OnCastSpell();

		protected abstract void OnTriggerEnter(Collider collision);

		protected void  StartDestoryObjectCountDown()
		{
			StartCoroutine(TimerCoroutine());
		}

		IEnumerator TimerCoroutine()
		{
			yield return new WaitForSeconds (_destoryObjectTimer);
			Destroy(this.gameObject);
		}
	}
}
