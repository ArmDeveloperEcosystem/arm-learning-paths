Streamline Annotation capability
================================
Copyright (c) 2019 Arm Limited. All rights reserved.

When added to a Unity project, these files will be automatically
compiled when building projects for Android.

These files are provided in this repository for convenience.
The definitive location of the most up-to-date versions is:

https://github.com/ARM-software/gator