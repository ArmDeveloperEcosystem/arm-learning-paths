﻿/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using Item;
using UnityEngine;

namespace Character {
	public class WeaponHolderSlot : MonoBehaviour {

		[SerializeField] bool _isLeftHandSlot;

		private GameObject _currentModel;
		public GameObject CurrentModel { get => _currentModel; set => _currentModel = value; }

		public void UnloadWeapon()
		{
			if (_currentModel != null)
			{
				_currentModel.SetActive(false);
			}
		}

		public void UnloadWeaponAndDestory()
		{
			if (_currentModel != null)
			{
				Destroy(_currentModel);
			}
		}

		public WeaponItemContainer LoadWeaponModel(WeaponItem item)
		{
			GameObject weaponGO = null;
			UnloadWeaponAndDestory();
			if (item == null)
			{
				UnloadWeapon();
				return null;
			}

			if (_isLeftHandSlot)
			{
				weaponGO = Instantiate(item.LeftContainer.gameObject, transform, false);
			}
			else
			{
				weaponGO = Instantiate(item.RightContainer.gameObject, transform, false);
			}

			_currentModel = weaponGO;
			return weaponGO.GetComponent<WeaponItemContainer>();
		}

		public void SetOnStartOverrideWeapon(WeaponItem item, GameObject gameObject)
		{
			_currentModel = gameObject;
		}
	}
}
