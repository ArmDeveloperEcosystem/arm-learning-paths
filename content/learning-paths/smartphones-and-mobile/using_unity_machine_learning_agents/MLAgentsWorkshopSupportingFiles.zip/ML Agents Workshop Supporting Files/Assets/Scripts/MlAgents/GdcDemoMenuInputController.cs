/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using PlayerInput;
using System;
using UnityEngine;

public class GdcDemoMenuInputController : MonoBehaviour
{
	[SerializeField] PlayerInputController _input;
	private bool _sendInput;

	public event EventHandler<EventArgs> Easy;
	public event EventHandler<EventArgs> Medium;
	public event EventHandler<EventArgs> Hard;
	public event EventHandler<EventArgs> Demo;


	private void Awake()
	{

		_input.RollInputPressed += HandleEasyButtonPressed;
		_input.AttackInputPressed += HandleMediumSelected;
		_input.AbilityInputPressed += HandleHardSelected;
		_input.StartInputPressed += DemoSelected;
	}

	public void SendInputEvents(bool value)
	{
		_sendInput = value;
	}

	private void HandleEasyButtonPressed(object sender, EventArgs e)
	{
		if (_sendInput)
		{
			Easy?.Invoke(this, EventArgs.Empty);
		}
	}

	private void HandleMediumSelected(object sender, EventArgs e)
	{
		if (_sendInput)
		{
			Medium?.Invoke(this, EventArgs.Empty);
		}
	}

	private void HandleHardSelected(object sender, EventArgs e)
	{
		if (_sendInput)
		{
			Hard?.Invoke(this, EventArgs.Empty);
		}
	}
	private void DemoSelected(object sender, EventArgs e)
	{
		if (_sendInput)
		{
			Demo?.Invoke(this, EventArgs.Empty);
		}
	}


	private void OnDestroy()
	{
		_input.AbilityInputPressed -= HandleEasyButtonPressed;
		_input.RunningInputUpdated -= HandleMediumSelected;
		_input.RollInputPressed -= HandleHardSelected;
		_input.StartInputPressed -= DemoSelected;
	}
}
