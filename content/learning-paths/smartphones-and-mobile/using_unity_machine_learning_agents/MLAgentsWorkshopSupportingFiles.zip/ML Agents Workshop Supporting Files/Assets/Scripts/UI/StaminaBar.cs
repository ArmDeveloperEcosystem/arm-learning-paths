/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using System;
using Character;
using UnityEngine;
using UnityEngine.UI;

namespace UI
{
	public class StaminaBar : AbstractPlayerManagerUiInterface
	{
		[SerializeField] Image _image;


		protected override void OnNewCharacterAssigned()
		{
			_currentPlayer.Stats.StaminaUpdatedEvent += HandleStaminaUpdatedEvent;
			_image.fillAmount = _currentPlayer.Stats.CurrenStaminaPercent;
		}

		private void HandleStaminaUpdatedEvent(object sender, StaminaUpdatedEventArgs e)
		{
			SetCurrentStamina(e.CurrentStamina / e.MaxStamina);
		}

		private void SetCurrentStamina(float healthPercent)
		{
			_image.fillAmount = healthPercent;
		}

		private void OnDestroy()
		{
			if (_currentPlayer.Stats.HealthUpdatedEvent != null)
			{
				_currentPlayer.Stats.StaminaUpdatedEvent -= HandleStaminaUpdatedEvent;
			}
		}

	}
}
