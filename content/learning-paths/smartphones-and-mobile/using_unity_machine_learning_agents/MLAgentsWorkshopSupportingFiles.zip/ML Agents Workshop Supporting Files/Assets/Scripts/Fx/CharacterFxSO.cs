/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Fx
{
	[CreateAssetMenu(menuName = "VFX SO/Character Vfx SO")]
	public class CharacterFxSO : ScriptableObject
	{
		[SerializeField] ParticleEffectController _fireHandVfxPrefab;
		[SerializeField] ParticleEffectController _woodVfxPrefab;
		[SerializeField] ParticleEffectController _stoneVfxPrefab;
		[SerializeField] ParticleEffectController _dirtVfxPrefab;
		[SerializeField] ParticleEffectController _metalVfxPrefab;

		public ParticleEffectController FireHandVfxPrefab { get => _fireHandVfxPrefab; }
		public ParticleEffectController WoodVfxPrefab { get => _woodVfxPrefab; }
		public ParticleEffectController StoneVfxPrefab { get => _stoneVfxPrefab; }
		public ParticleEffectController DirtVfxPrefab { get => _dirtVfxPrefab; }
		public ParticleEffectController MetalVfxPrefab { get => _metalVfxPrefab; }
	}
}
