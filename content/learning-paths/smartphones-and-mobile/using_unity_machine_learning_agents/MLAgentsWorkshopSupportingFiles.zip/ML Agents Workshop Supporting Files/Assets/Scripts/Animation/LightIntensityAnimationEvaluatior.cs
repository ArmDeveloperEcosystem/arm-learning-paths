/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using UnityEngine;

namespace Animation
{
	public class LightIntensityAnimationEvaluatior : AbstractAnimationEvaluatiorBehaviour
	{
		[SerializeField] Light _light;
		[SerializeField] AnimationCurve _animationCurve;


		public override void Evaluate(float percentComplete)
		{
			_light.enabled = true;
			float value = _animationCurve.Evaluate(percentComplete);
			_light.intensity = value;
		}

		public override void OnAnimationComplete()
		{
			_light.enabled = false;
		}

		public override void OnPlay()
		{
			_light.enabled = true;
		}
	}
}
