﻿/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using System;
using UnityEngine;

namespace Joystick { 
	public abstract class AbstractJoystick : MonoBehaviour {

		public EventHandler<EventArgs> InputStarted;
		public EventHandler<JoystickEventArgs> InputUpdated;
		public EventHandler<EventArgs> InputEnded;

		public void SendInputStartedEvent()
		{
			InputStarted?.Invoke(this, EventArgs.Empty);
		}

		public void SendInputUpdatedEvet(Vector2 input)
		{
			InputUpdated?.Invoke(this, new JoystickEventArgs() { Input = input });
		}

		public void SendInputEndedEvent()
		{
			InputEnded?.Invoke(this, EventArgs.Empty);
		}
	}

	public class JoystickEventArgs: EventArgs {
		public Vector2 Input;
	}
}
