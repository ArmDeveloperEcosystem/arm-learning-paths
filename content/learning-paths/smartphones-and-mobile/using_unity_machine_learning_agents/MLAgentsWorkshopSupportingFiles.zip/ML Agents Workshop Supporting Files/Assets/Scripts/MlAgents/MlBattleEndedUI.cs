/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using System;
using UI;
using UnityEngine;

public class MlBattleEndedUI : MonoBehaviour
{
	[SerializeField] MainMenuCanvasController _canvasController;
	[SerializeField] AbstractAnimationEvaluatiorBehaviour _loadMainMenuTimer;
	private MlAgentsGdcDemoController _demoController;


	private void LoadMainMenuTimer_Ended(object sender, EventArgs e)
	{
		_loadMainMenuTimer.Ended -= LoadMainMenuTimer_Ended;
		_demoController.ShowMenu();
}

	internal void ShowWinner(MlAgentsGdcDemoController mlAgentsGdcDemoController)
	{
		_demoController = mlAgentsGdcDemoController;
		_canvasController.Show();
		_loadMainMenuTimer.Play();
		_loadMainMenuTimer.Ended += LoadMainMenuTimer_Ended;
	}

	internal void Hide()
	{
		_canvasController.Hide();
	}
}
