﻿/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using Item;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace Player {
	public class PlayerInventory : MonoBehaviour {

		[SerializeField] WeaponSlotManager _weaponSlotManager;
        [SerializeField] List<WeaponItem> _weapons;


		public List<WeaponItem> Weapons { get => _weapons;}

		private void Start()
        {
			_weaponSlotManager.LoadWeapon(_weapons[0]);
        }

		internal void EquipWeapon(WeaponItem weaponItem)
		{
			_weaponSlotManager.LoadWeapon(weaponItem);
		}
	}
}
