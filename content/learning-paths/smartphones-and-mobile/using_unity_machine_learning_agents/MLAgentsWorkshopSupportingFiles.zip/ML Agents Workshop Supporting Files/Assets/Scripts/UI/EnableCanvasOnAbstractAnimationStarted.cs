/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */


using UnityEngine;

public class EnableCanvasOnAbstractAnimationStarted : MonoBehaviour
{
	[SerializeField] AbstractAnimationEvaluatiorBehaviour _animator;
	[SerializeField] Canvas _canvas;

	private void Awake()
	{
		_animator.Started += HandleAnimationStatedEvent;
	}

	private void HandleAnimationStatedEvent(object sender, System.EventArgs e)
	{
		_canvas.enabled = true;
	}

	private void OnDestroy()
	{
		if (_animator != null)
		{
			_animator.Started -= HandleAnimationStatedEvent;
		}
	}
}
