﻿/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using Combat;
using UnityEngine;

namespace Item {
	public class WeaponItemContainer : MonoBehaviour {
		[SerializeField]
		DamageCollider _damageCollider;

		[SerializeField]
		ParticleSystem[] _attackVfx;

		public DamageCollider DamageCollider { get => _damageCollider; }
		public ParticleSystem[] AttackVfx { get => _attackVfx;}



		public void PlayAttackVFX()
		{
			for (int i = 0; i < _attackVfx.Length; i++)
			{
				_attackVfx[i].Play();
			}
		}
		public void StopAttackVFX()
		{
			for (int i = 0; i < _attackVfx.Length; i++)
			{
				_attackVfx[i].Stop();
			}	
		}
	}
}
