﻿/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using Character;
using UnityEngine;
using UnityEngine.UI;

namespace UI
{
	public class ManaBar : AbstractPlayerManagerUiInterface
	{
		[SerializeField] Image _image;


		protected override void OnNewCharacterAssigned()
		{
			_currentPlayer.Stats.ManaUpdatedEvent += HandleManaUpdatedEvent;
			_image.fillAmount = _currentPlayer.Stats.CurrentManaPercent;
		}

		private void HandleManaUpdatedEvent(object sender, ManaUpdatedEventArgs e)
		{
			SetCurrentMana(e.CurrentMana / e.MaxMana);
		}

		private void SetCurrentMana(float healthPercent)
		{
			_image.fillAmount = healthPercent;
		}

		private void OnDestroy()
		{
			if (_currentPlayer.Stats.ManaUpdatedEvent != null)
			{
				_currentPlayer.Stats.ManaUpdatedEvent -= HandleManaUpdatedEvent;
			}
		}

	}
}