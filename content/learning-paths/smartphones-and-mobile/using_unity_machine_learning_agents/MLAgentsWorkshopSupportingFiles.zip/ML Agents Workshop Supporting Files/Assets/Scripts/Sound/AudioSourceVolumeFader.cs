/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Sounds
{
	public class AudioSourceVolumeFader : AbstractAnimationEvaluatiorBehaviour
	{
		[SerializeField] AudioSource _audioSource;
		[SerializeField] AnimationCurve _volumeAnimation;
		[SerializeField] bool _startAudioPlayingOnAnimationStart;
		[SerializeField] bool _StopAudioOnAnimationComplete;

		public override void Evaluate(float percentComplete)
		{
			_audioSource.volume = _volumeAnimation.Evaluate(percentComplete);
		}

		public override void OnAnimationComplete()
		{
			if (_StopAudioOnAnimationComplete)
			{
				_audioSource.Stop();
			}
		}

		public override void OnPlay()
		{
			if (_startAudioPlayingOnAnimationStart)
			{
				_audioSource.Play();
			}
		}

	}
}
