/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2022 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

using UnityEngine;

public class SingletonBehaviour<T> : MonoBehaviour where T : MonoBehaviour {
	private static T singletonInstance = null;
	public static T Instance {
		get {
			if (singletonInstance == null) {
				singletonInstance = FindObjectOfType<T>();
			}
			return singletonInstance;
		}
	}

	public virtual void Awake() {
		if (singletonInstance != null) {
			Debug.LogWarning("Singleton<" + typeof(T) + "> already exists! Something may have called Instance accessor before Awake.");
		}
		else {
			singletonInstance = this as T;
		}
	}

	public virtual void OnDestroy() {
		if (singletonInstance == this) {
			singletonInstance = null;
		}
	}
}
