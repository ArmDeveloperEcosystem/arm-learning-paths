/* Copyright 2026 Arm Limited and/or its affiliates.
 * SPDX-License-Identifier: Apache-2.0
 */
#pragma once
#include <cstddef>
#include <cstdint>

bool microphone_start();
bool microphone_read(int16_t* samples, size_t count, uint32_t* buffered_blocks);
