/* Copyright 2026 Arm Limited and/or its affiliates.
 * SPDX-License-Identifier: Apache-2.0
 */
#pragma once
#include <cstddef>
#include <cstdint>

bool dashboard_initialize(size_t samples, size_t sample_rate, float threshold);
[[noreturn]] void dashboard_replay(
    const float* probabilities, size_t frames, size_t samples, size_t sample_rate,
    float threshold, size_t speech_frames, size_t segments, int64_t inference_ms);

#if CONFIG_SILERO_LIVE_AUDIO
bool dashboard_live_start(float threshold);
void dashboard_live_update(float probability, float peak, float rms, uint32_t frame,
    uint32_t speech_frames, uint32_t segments, int64_t inference_ms);
#endif
