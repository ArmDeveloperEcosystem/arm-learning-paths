/* Copyright 2024 Alif Semiconductor.
 * Copyright 2026 Arm Limited and/or its affiliates.
 * SPDX-License-Identifier: Apache-2.0
 */
#include "microphone.h"
#include <zephyr/audio/dmic.h>
#include <zephyr/device.h>
#include <zephyr/drivers/pdm/pdm_alif.h>
#include <zephyr/kernel.h>
#include <zephyr/sys/printk.h>
#include <cstring>

namespace {
constexpr size_t kBlockBytes = 512 * sizeof(int16_t);
constexpr uint32_t kBlocks = 8;
K_MEM_SLAB_DEFINE(audio_slab, kBlockBytes, kBlocks, 4);
const struct device* const microphone = DEVICE_DT_GET(DT_NODELABEL(pdm));
}

bool microphone_start() {
  if (!device_is_ready(microphone)) {
    printk("ERROR on-board PDM microphone is not ready\n");
    return false;
  }
  struct pcm_stream_cfg stream{};
  stream.pcm_rate = 16000;
  stream.pcm_width = 16;
  stream.block_size = kBlockBytes;
  stream.mem_slab = &audio_slab;
  struct dmic_cfg config{};
  config.streams = &stream;
  config.channel.req_num_streams = 1;
  config.channel.req_num_chan = 1;
  // The Alif driver consumes a physical-channel bit mask.
  config.channel.req_chan_map_lo = PDM_MASK_CHANNEL_4;
  const int status = dmic_configure(microphone, &config);
  if (status != 0) {
    printk("ERROR PDM configure: %d\n", status);
    return false;
  }
  pdm_set_ch_phase(microphone, 4, 0x1f);
  pdm_set_ch_gain(microphone, 4, CONFIG_SILERO_MIC_GAIN << 4);
  struct pdm_ch_config channel{};
  channel.ch_num = 4;
  const uint32_t fir[18] = {
      0x001, 0x003, 0x003, 0x7f4, 0x004, 0x7ed,
      0x7f5, 0x7f4, 0x7d3, 0x7fe, 0x7bc, 0x7e5,
      0x7d9, 0x793, 0x029, 0x72c, 0x072, 0x2fd};
  std::memcpy(channel.ch_fir_coef, fir, sizeof(fir));
  channel.ch_iir_coef = 4;
  pdm_channel_config(microphone, &channel);
  // Mode 2 produces 16 kHz; the driver's pcm_rate field does not set the clock.
  pdm_mode(microphone, PDM_MODE_HIGH_QUALITY_512_CLK_FRQ);
  const int start = dmic_trigger(microphone, DMIC_TRIGGER_START);
  if (start != 0) {
    printk("ERROR PDM start: %d\n", start);
    return false;
  }
  return true;
}

bool microphone_read(int16_t* samples, size_t count, uint32_t* buffered_blocks) {
  void* block = nullptr;
  size_t bytes = 0;
  const int status = dmic_read(microphone, 0, &block, &bytes, 1000);
  if (status != 0 || block == nullptr) {
    printk("ERROR PDM read: %d\n", status);
    dmic_trigger(microphone, DMIC_TRIGGER_STOP);
    return false;
  }
  const uint32_t used = k_mem_slab_num_used_get(&audio_slab);
  const bool valid = bytes == kBlockBytes && count == 512 && used < kBlocks - 1;
  if (valid) {
    std::memcpy(samples, block, bytes);
  }
  k_mem_slab_free(&audio_slab, block);
  if (!valid) {
    printk("ERROR PDM block/latency: bytes=%zu buffered=%u\n", bytes, used);
    dmic_trigger(microphone, DMIC_TRIGGER_STOP);
    return false;
  }
  *buffered_blocks = used;
  return true;
}
