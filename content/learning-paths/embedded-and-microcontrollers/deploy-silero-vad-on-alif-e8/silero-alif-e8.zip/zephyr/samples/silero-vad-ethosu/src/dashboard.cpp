/* Copyright 2026 Arm Limited and/or its affiliates.
 * SPDX-License-Identifier: Apache-2.0
 */
#include "dashboard.h"
#include <zephyr/cache.h>
#include <zephyr/device.h>
#include <zephyr/drivers/display/cdc200.h>
#include <zephyr/drivers/display.h>
#include <cerrno>
#include <zephyr/drivers/mipi_dsi/dsi_dw.h>
#include <zephyr/kernel.h>
#include <zephyr/sys/printk.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>

extern "C" volatile uint32_t silero_dashboard_frame;
volatile uint32_t silero_dashboard_frame;

namespace {
constexpr size_t kScreenWidth = 480;
constexpr size_t kScreenHeight = 800;
constexpr uint16_t rgb565(uint8_t r, uint8_t g, uint8_t b) {
  return static_cast<uint16_t>(((r & 0xf8u) << 8) | ((g & 0xfcu) << 3) | (b >> 3));
}
constexpr uint16_t kBackground = rgb565(6, 12, 25);
constexpr uint16_t kCard = rgb565(13, 26, 44);
constexpr uint16_t kInset = rgb565(8, 18, 33);
constexpr uint16_t kBorder = rgb565(32, 51, 72);
constexpr uint16_t kWhite = rgb565(239, 247, 253);
constexpr uint16_t kMuted = rgb565(130, 154, 176);
constexpr uint16_t kTeal = rgb565(35, 226, 195);
constexpr uint16_t kAmber = rgb565(255, 193, 84);
constexpr uint16_t kFuture = rgb565(39, 59, 79);
uint16_t* pixels;
struct cdc200_fb_desc framebuffer;

constexpr uint8_t kFont[][5] = {
    {0x00, 0x00, 0x00, 0x00, 0x00}, {0x00, 0x00, 0x5f, 0x00, 0x00},
    {0x00, 0x07, 0x00, 0x07, 0x00}, {0x14, 0x7f, 0x14, 0x7f, 0x14},
    {0x24, 0x2a, 0x7f, 0x2a, 0x12}, {0x23, 0x13, 0x08, 0x64, 0x62},
    {0x36, 0x49, 0x55, 0x22, 0x50}, {0x00, 0x05, 0x03, 0x00, 0x00},
    {0x00, 0x1c, 0x22, 0x41, 0x00}, {0x00, 0x41, 0x22, 0x1c, 0x00},
    {0x14, 0x08, 0x3e, 0x08, 0x14}, {0x08, 0x08, 0x3e, 0x08, 0x08},
    {0x00, 0x50, 0x30, 0x00, 0x00}, {0x08, 0x08, 0x08, 0x08, 0x08},
    {0x00, 0x60, 0x60, 0x00, 0x00}, {0x20, 0x10, 0x08, 0x04, 0x02},
    {0x3e, 0x51, 0x49, 0x45, 0x3e}, {0x00, 0x42, 0x7f, 0x40, 0x00},
    {0x42, 0x61, 0x51, 0x49, 0x46}, {0x21, 0x41, 0x45, 0x4b, 0x31},
    {0x18, 0x14, 0x12, 0x7f, 0x10}, {0x27, 0x45, 0x45, 0x45, 0x39},
    {0x3c, 0x4a, 0x49, 0x49, 0x30}, {0x01, 0x71, 0x09, 0x05, 0x03},
    {0x36, 0x49, 0x49, 0x49, 0x36}, {0x06, 0x49, 0x49, 0x29, 0x1e},
    {0x00, 0x36, 0x36, 0x00, 0x00}, {0x00, 0x56, 0x36, 0x00, 0x00},
    {0x08, 0x14, 0x22, 0x41, 0x00}, {0x14, 0x14, 0x14, 0x14, 0x14},
    {0x00, 0x41, 0x22, 0x14, 0x08}, {0x02, 0x01, 0x51, 0x09, 0x06},
    {0x32, 0x49, 0x79, 0x41, 0x3e}, {0x7e, 0x11, 0x11, 0x11, 0x7e},
    {0x7f, 0x49, 0x49, 0x49, 0x36}, {0x3e, 0x41, 0x41, 0x41, 0x22},
    {0x7f, 0x41, 0x41, 0x22, 0x1c}, {0x7f, 0x49, 0x49, 0x49, 0x41},
    {0x7f, 0x09, 0x09, 0x09, 0x01}, {0x3e, 0x41, 0x49, 0x49, 0x7a},
    {0x7f, 0x08, 0x08, 0x08, 0x7f}, {0x00, 0x41, 0x7f, 0x41, 0x00},
    {0x20, 0x40, 0x41, 0x3f, 0x01}, {0x7f, 0x08, 0x14, 0x22, 0x41},
    {0x7f, 0x40, 0x40, 0x40, 0x40}, {0x7f, 0x02, 0x0c, 0x02, 0x7f},
    {0x7f, 0x04, 0x08, 0x10, 0x7f}, {0x3e, 0x41, 0x41, 0x41, 0x3e},
    {0x7f, 0x09, 0x09, 0x09, 0x06}, {0x3e, 0x41, 0x51, 0x21, 0x5e},
    {0x7f, 0x09, 0x19, 0x29, 0x46}, {0x46, 0x49, 0x49, 0x49, 0x31},
    {0x01, 0x01, 0x7f, 0x01, 0x01}, {0x3f, 0x40, 0x40, 0x40, 0x3f},
    {0x1f, 0x20, 0x40, 0x20, 0x1f}, {0x3f, 0x40, 0x38, 0x40, 0x3f},
    {0x63, 0x14, 0x08, 0x14, 0x63}, {0x07, 0x08, 0x70, 0x08, 0x07},
    {0x61, 0x51, 0x49, 0x45, 0x43},
};

void fill_rect(
    size_t x,
    size_t y,
    size_t width,
    size_t height,
    uint16_t color) {
  const size_t x_end = std::min(x + width, kScreenWidth);
  const size_t y_end = std::min(y + height, kScreenHeight);
  for (size_t row = y; row < y_end; ++row) {
    std::fill(
        pixels + row * kScreenWidth + x,
        pixels + row * kScreenWidth + x_end,
        color);
  }
}

const uint8_t* glyph(char character) {
  if (character >= 'a' && character <= 'z') {
    character -= 'a' - 'A';
  }
  if (character < ' ' || character > 'Z') {
    character = '?';
  }
  return kFont[character - ' '];
}

void draw_text(
    size_t x,
    size_t y,
    const char* text,
    size_t scale,
    uint16_t color) {
  while (*text != '\0') {
    const uint8_t* columns = glyph(*text++);
    for (size_t column = 0; column < 5; ++column) {
      for (size_t row = 0; row < 7; ++row) {
        if ((columns[column] & (1u << row)) != 0) {
          fill_rect(x + column * scale, y + row * scale, scale, scale, color);
        }
      }
    }
    x += 6 * scale;
  }
}

void draw_centered(size_t y, const char* text, size_t scale, uint16_t color) {
  const size_t width = std::strlen(text) * 6 * scale - scale;
  draw_text((kScreenWidth - width) / 2, y, text, scale, color);
}

void card(size_t x, size_t y, size_t width, size_t height) {
  fill_rect(x, y, width, height, kBorder);
  fill_rect(x + 1, y + 1, width - 2, height - 2, kCard);
  fill_rect(x, y, 5, 5, kBackground);
  fill_rect(x + width - 5, y, 5, 5, kBackground);
  fill_rect(x, y + height - 5, 5, 5, kBackground);
  fill_rect(x + width - 5, y + height - 5, 5, 5, kBackground);
}

void draw_dashboard(const float* probabilities, size_t frames, size_t current,
    size_t samples, size_t sample_rate, float threshold, size_t speech_frames,
    size_t segments, int64_t inference_ms, bool summary) {
  std::fill(pixels, pixels + kScreenWidth * kScreenHeight, kBackground);
  const bool ready = probabilities != nullptr && frames != 0;
  const float probability = ready ? std::clamp(probabilities[current], 0.0f, 1.0f) : 0.0f;
  const bool speech = ready && probabilities[current] > threshold;
  const uint16_t accent = speech ? kTeal : kAmber;
  char value[64];

  fill_rect(24, 29, 5, 17, kTeal);
  draw_text(40, 32, "ARM / ALIF ENSEMBLE E8", 2, kMuted);
  draw_text(24, 66, "SILERO", 6, kWhite);
  draw_text(25, 123, "VOICE ACTIVITY DETECTION", 2, kMuted);

  card(24, 164, 432, 184);
  draw_text(44, 183, "SPEECH PROBABILITY", 2, kMuted);
  fill_rect(331, 181, 104, 24, ready ? accent : kBorder);
  draw_text(343, 186, ready ? (speech ? "SPEECH" : "QUIET") : "WAIT", 2, kBackground);
  if (ready) {
    std::snprintf(value, sizeof(value), "%.1f%%", static_cast<double>(probability * 100.0f));
    draw_text(42, 224, value, 8, kWhite);
    std::snprintf(value, sizeof(value), "FRAME %02zu / %02zu", current + 1, frames);
    draw_text(44, 309, value, 2, kMuted);
    draw_text(288, 309, summary ? "COMPLETE" : "REPLAY", 2, kTeal);
  } else {
    draw_text(44, 228, "RUNNING", 6, kWhite);
    draw_text(44, 309, "ONE MODEL RUN", 2, kTeal);
  }

  card(24, 366, 432, 196);
  draw_text(44, 386, "PROBABILITY TIMELINE", 2, kMuted);
  constexpr size_t graph_x = 44;
  constexpr size_t graph_y = 425;
  constexpr size_t graph_w = 392;
  constexpr size_t graph_h = 94;
  fill_rect(graph_x, graph_y, graph_w, graph_h, kInset);
  const size_t threshold_y = graph_y + graph_h - 1 -
      static_cast<size_t>(std::clamp(threshold, 0.0f, 1.0f) * (graph_h - 1));
  for (size_t x = graph_x; x < graph_x + graph_w; x += 8) {
    fill_rect(x, threshold_y, 3, 1, kMuted);
  }
  if (ready) {
    for (size_t i = 0; i < frames; ++i) {
      const size_t x0 = graph_x + i * graph_w / frames;
      const size_t x1 = graph_x + (i + 1) * graph_w / frames;
      const size_t height = std::max<size_t>(2,
          static_cast<size_t>(std::clamp(probabilities[i], 0.0f, 1.0f) * (graph_h - 1)));
      const uint16_t color = i <= current || summary
          ? (probabilities[i] > threshold ? kTeal : kAmber) : kFuture;
      fill_rect(x0, graph_y + graph_h - height, std::max<size_t>(1, x1 - x0 - 1), height, color);
    }
    fill_rect(graph_x + current * graph_w / frames, graph_y - 4, 2, graph_h + 8, kWhite);
  }
  draw_text(44, 536, "0.00S", 1, kMuted);
  std::snprintf(value, sizeof(value), "%.2fS", static_cast<double>(samples) / sample_rate);
  draw_text(404, 536, value, 1, kMuted);
  std::snprintf(value, sizeof(value), "THRESHOLD %.2f", static_cast<double>(threshold));
  draw_text(180, 536, value, 1, kMuted);

  draw_text(25, 585, "PRERECORDED CLIP", 2, kWhite);
  const size_t consumed = ready ? std::min(samples, (current + 1) * size_t{512}) : 0;
  std::snprintf(value, sizeof(value), "%.2f / %.2f S",
      static_cast<double>(consumed) / sample_rate, static_cast<double>(samples) / sample_rate);
  draw_text(25, 613, value, 2, kMuted);
  fill_rect(25, 643, 430, 6, kBorder);
  if (samples) {
    fill_rect(25, 643, consumed * 430 / samples, 6, kTeal);
  }

  card(24, 672, 210, 77);
  card(246, 672, 210, 77);
  draw_text(40, 685, "SPEECH FRAMES", 1, kMuted);
  draw_text(262, 685, "SPEECH SEGMENTS", 1, kMuted);
  std::snprintf(value, sizeof(value), "%zu/%zu", speech_frames, frames);
  draw_text(40, 707, ready ? value : "--", 3, kWhite);
  std::snprintf(value, sizeof(value), "%zu", segments);
  draw_text(262, 707, ready ? value : "--", 3, kWhite);
  std::snprintf(value, sizeof(value), "INFERENCE LOOP / %lld MS", static_cast<long long>(inference_ms));
  draw_text(25, 763, ready ? value : "EXECUTORCH / ETHOS-U85", 1, kMuted);
  draw_text(25, 780, "LOOPING RESULTS / NO MICROPHONE", 1, kTeal);
}

#if CONFIG_SILERO_LIVE_AUDIO
constexpr size_t kHistory = 98;
struct LiveSnapshot {
  float probabilities[kHistory];
  float peak;
  float rms;
  float threshold;
  uint32_t frame;
  uint32_t speech_frames;
  uint32_t segments;
  int64_t inference_ms;
};
LiveSnapshot live{};
K_MUTEX_DEFINE(live_mutex);
K_THREAD_STACK_DEFINE(display_stack, 4096);
struct k_thread display_thread;

void draw_live_dashboard(const LiveSnapshot& data) {
  std::fill(pixels, pixels + kScreenWidth * kScreenHeight, kBackground);
  const bool ready = data.frame != 0;
  const float probability = data.probabilities[kHistory - 1];
  const bool speech = ready && probability > data.threshold;
  const uint16_t accent = speech ? kTeal : kAmber;
  char value[64];
  fill_rect(24, 29, 5, 17, kTeal);
  draw_text(40, 32, "ARM / ALIF ENSEMBLE E8", 2, kMuted);
  draw_text(24, 66, "SILERO", 6, kWhite);
  draw_text(25, 123, "LIVE VOICE ACTIVITY", 2, kTeal);
  card(24, 164, 432, 184);
  draw_text(44, 183, "SPEECH PROBABILITY", 2, kMuted);
  fill_rect(331, 181, 104, 24, ready ? accent : kBorder);
  draw_text(343, 186, ready ? (speech ? "SPEECH" : "QUIET") : "WAIT", 2, kBackground);
  if (ready) {
    std::snprintf(value, sizeof(value), "%.1f%%", static_cast<double>(probability * 100.0f));
    draw_text(42, 224, value, 8, kWhite);
  } else {
    draw_text(44, 228, "READY", 6, kWhite);
  }
  std::snprintf(value, sizeof(value), "FRAME %u", data.frame);
  draw_text(44, 309, value, 2, kMuted);
  draw_text(366, 309, "LIVE", 2, kTeal);
  card(24, 366, 432, 196);
  draw_text(44, 386, "RECENT SPEECH PROBABILITY", 2, kMuted);
  constexpr size_t graph_x = 44, graph_y = 425, graph_w = 392, graph_h = 94;
  fill_rect(graph_x, graph_y, graph_w, graph_h, kInset);
  const size_t threshold_y = graph_y + graph_h - 1 -
      static_cast<size_t>(data.threshold * (graph_h - 1));
  for (size_t x = graph_x; x < graph_x + graph_w; x += 8) {
    fill_rect(x, threshold_y, 3, 1, kMuted);
  }
  const size_t count = std::min<size_t>(data.frame, kHistory);
  for (size_t i = kHistory - count; i < kHistory; ++i) {
    const float p = std::clamp(data.probabilities[i], 0.0f, 1.0f);
    const size_t height = std::max<size_t>(2, static_cast<size_t>(p * (graph_h - 1)));
    fill_rect(graph_x + i * 4, graph_y + graph_h - height, 3, height,
        p > data.threshold ? kTeal : kAmber);
  }
  draw_text(44, 536, "-3.1S", 1, kMuted);
  draw_text(418, 536, "NOW", 1, kMuted);
  std::snprintf(value, sizeof(value), "THRESHOLD %.2f", static_cast<double>(data.threshold));
  draw_text(180, 536, value, 1, kMuted);
  draw_text(25, 585, "ON-BOARD MICROPHONE", 2, kWhite);
  const double dbfs = 20.0 * std::log10(std::max(0.00001f, data.rms));
  std::snprintf(value, sizeof(value), "MIC %5.1f DBFS / PEAK %.3f", dbfs, static_cast<double>(data.peak));
  draw_text(25, 613, value, 2, kMuted);
  fill_rect(25, 643, 430, 6, kBorder);
  const size_t level = static_cast<size_t>(std::clamp((dbfs + 72.0) / 72.0, 0.0, 1.0) * 430);
  fill_rect(25, 643, level, 6, kTeal);
  card(24, 672, 210, 77);
  card(246, 672, 210, 77);
  draw_text(40, 685, "SPEECH ACTIVITY", 1, kMuted);
  draw_text(262, 685, "SPEECH SEGMENTS", 1, kMuted);
  const double percent = ready ? 100.0 * data.speech_frames / data.frame : 0.0;
  std::snprintf(value, sizeof(value), "%.1f%%", percent);
  draw_text(40, 707, value, 3, kWhite);
  std::snprintf(value, sizeof(value), "%u", data.segments);
  draw_text(262, 707, value, 3, kWhite);
  std::snprintf(value, sizeof(value), "NPU+CPU INFERENCE %lld MS / 32 MS AUDIO", static_cast<long long>(data.inference_ms));
  draw_text(25, 763, value, 1, kMuted);
  std::snprintf(value, sizeof(value), "PDM4 / GAIN %uX / %.1f S CAPTURED", CONFIG_SILERO_MIC_GAIN, data.frame * 0.032);
  draw_text(25, 780, value, 1, kTeal);
}
#endif

bool present() {
  const int status = sys_cache_data_flush_range(framebuffer.fb_addr, framebuffer.fb_size);
  if (status != 0) {
    printk("ERROR dashboard cache flush: %d\n", status);
    return false;
  }
  ++silero_dashboard_frame;
  return true;
}
} // namespace

bool dashboard_initialize(size_t samples, size_t sample_rate, float threshold) {
  const struct device* panel = DEVICE_DT_GET(DT_NODELABEL(mw405));
  const struct device* dsi = DEVICE_DT_GET(DT_NODELABEL(mipi_dsi));
  const struct device* cdc = DEVICE_DT_GET(DT_CHOSEN(zephyr_display));
  if (!device_is_ready(panel) || !device_is_ready(dsi) || !device_is_ready(cdc)) {
    printk("ERROR display devices are not ready\n");
    return false;
  }
  const int orientation = display_set_orientation(panel, DISPLAY_ORIENTATION_ROTATED_180);
  if (orientation != 0 && orientation != -ENOTSUP) {
    printk("ERROR panel orientation: %d\n", orientation);
    return false;
  }
  if (dsi_dw_set_mode(dsi, DSI_DW_VIDEO_MODE) != 0) {
    printk("ERROR display video mode\n");
    return false;
  }
  const int blanking = display_blanking_off(panel);
  if (blanking != 0) {
    printk("ERROR panel blanking: %d\n", blanking);
    return false;
  }
  cdc200_get_framebuffer(cdc, 0, &framebuffer);
  if (framebuffer.fb_addr == nullptr || framebuffer.fb_size != 480 * 800 * sizeof(uint16_t)) {
    printk("ERROR display framebuffer size: %zu\n", framebuffer.fb_size);
    return false;
  }
  pixels = reinterpret_cast<uint16_t*>(framebuffer.fb_addr);
#if CONFIG_SILERO_LIVE_AUDIO
  live.threshold = threshold;
  draw_live_dashboard(live);
#else
  draw_dashboard(nullptr, 0, 0, samples, sample_rate, threshold, 0, 0, 0, false);
#endif
  if (!present()) {
    return false;
  }
  cdc200_set_enable(cdc, true);
  return true;
}

[[noreturn]] void dashboard_replay(const float* probabilities, size_t frames,
    size_t samples, size_t sample_rate, float threshold, size_t speech_frames,
    size_t segments, int64_t inference_ms) {
  for (;;) {
    for (size_t i = 0; i < frames; ++i) {
      draw_dashboard(probabilities, frames, i, samples, sample_rate, threshold,
          speech_frames, segments, inference_ms, false);
      if (!present()) {
        k_panic();
      }
      k_msleep(64);
    }
    draw_dashboard(probabilities, frames, frames - 1, samples, sample_rate, threshold,
        speech_frames, segments, inference_ms, true);
    if (!present()) {
      k_panic();
    }
    k_msleep(1200);
  }
}

#if CONFIG_SILERO_LIVE_AUDIO
namespace {
void live_display_worker(void*, void*, void*) {
  for (;;) {
    LiveSnapshot snapshot;
    k_mutex_lock(&live_mutex, K_FOREVER);
    snapshot = live;
    k_mutex_unlock(&live_mutex);
    draw_live_dashboard(snapshot);
    if (!present()) {
      k_panic();
    }
    k_msleep(100);
  }
}
}

bool dashboard_live_start(float threshold) {
  live.threshold = threshold;
  return k_thread_create(&display_thread, display_stack,
      K_THREAD_STACK_SIZEOF(display_stack), live_display_worker,
      nullptr, nullptr, nullptr, K_PRIO_PREEMPT(5), 0, K_NO_WAIT) != nullptr;
}

void dashboard_live_update(float probability, float peak, float rms, uint32_t frame,
    uint32_t speech_frames, uint32_t segments, int64_t inference_ms) {
  k_mutex_lock(&live_mutex, K_FOREVER);
  std::move(live.probabilities + 1, live.probabilities + kHistory, live.probabilities);
  live.probabilities[kHistory - 1] = probability;
  live.peak = peak;
  live.rms = rms;
  live.frame = frame;
  live.speech_frames = speech_frames;
  live.segments = segments;
  live.inference_ms = inference_ms;
  k_mutex_unlock(&live_mutex);
}
#endif
