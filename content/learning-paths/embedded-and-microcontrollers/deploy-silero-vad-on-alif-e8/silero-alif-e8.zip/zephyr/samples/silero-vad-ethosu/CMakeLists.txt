# Copyright 2026 Arm Limited and/or its affiliates.
# SPDX-License-Identifier: Apache-2.0

cmake_minimum_required(VERSION 3.24)

set(CONFIG_ARM_ETHOS_U85_256 y CACHE BOOL "E8 Ethos-U85, 256 MACs" FORCE)
set(ETHOSU_TARGET_NPU_CONFIG "ethos-u85-256" CACHE STRING "Ethos-U HAL target" FORCE)
set(MAX_KERNEL_NUM 128 CACHE STRING "ExecuTorch kernel registry capacity" FORCE)
set(EXECUTORCH_LOG_LEVEL Info CACHE STRING "ExecuTorch runtime log level" FORCE)
set(CMAKE_SKIP_INSTALL_RULES ON CACHE BOOL "" FORCE)

set(ET_PTE_FILE_PATH "" CACHE FILEPATH "Silero VAD PTE")
set(AUDIO_PATH "" CACHE FILEPATH "16 kHz mono 16-bit PCM validation WAV")
set(MAX_AUDIO_SAMPLES 40000 CACHE STRING "Maximum embedded WAV samples")
set(VAD_THRESHOLD 0.5 CACHE STRING "Speech probability threshold")

get_filename_component(EXECUTORCH_ROOT "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)
set(ETHOSU_DRIVER_PATH "$ENV{ZEPHYR_BASE}/../modules/hal/ethos_u"
  CACHE PATH "Zephyr workspace Ethos-U core driver")
if(NOT EXISTS "${ETHOSU_DRIVER_PATH}/include/ethosu_driver.h")
  message(FATAL_ERROR "ETHOSU_DRIVER_PATH must point to the Zephyr Ethos-U HAL module.")
endif()
# Use the same driver headers as Zephyr, without fetching a second bare-metal SDK.
set(ETHOS_SDK_PATH "${CMAKE_CURRENT_BINARY_DIR}/ethos-u" CACHE PATH "" FORCE)
file(COPY "${ETHOSU_DRIVER_PATH}/include"
  DESTINATION "${ETHOS_SDK_PATH}/core_software/core_driver")
foreach(input_file ET_PTE_FILE_PATH)
  if(NOT IS_ABSOLUTE "${${input_file}}" OR NOT EXISTS "${${input_file}}")
    message(FATAL_ERROR "${input_file} must point to an existing absolute file path.")
  endif()
endforeach()

find_package(Python3 REQUIRED COMPONENTS Interpreter)

execute_process(
  COMMAND ${Python3_EXECUTABLE} ${EXECUTORCH_ROOT}/codegen/tools/gen_oplist.py
    --model_file_path=${ET_PTE_FILE_PATH}
    --output_path=${CMAKE_CURRENT_BINARY_DIR}/selected_operators.yaml
  RESULT_VARIABLE GEN_OPLIST_RESULT
  OUTPUT_VARIABLE GEN_OPLIST_OUTPUT
  ERROR_VARIABLE GEN_OPLIST_ERROR
)
if(NOT GEN_OPLIST_RESULT EQUAL 0)
  message(FATAL_ERROR "Could not inspect PTE operators: ${GEN_OPLIST_ERROR}")
endif()
message(STATUS "${GEN_OPLIST_OUTPUT}")

find_package(Zephyr REQUIRED HINTS $ENV{ZEPHYR_BASE})
project(executorch_silero_vad_ethosu)

if(NOT TARGET libexecutorch)
  message(FATAL_ERROR "ExecuTorch Zephyr module is missing; set ZEPHYR_EXTRA_MODULES.")
endif()
include(${EXECUTORCH_ROOT}/tools/cmake/Utils.cmake)
include(${EXECUTORCH_ROOT}/tools/cmake/Codegen.cmake)

# Recurrent state and q/dq operations intentionally remain on the CPU.
if(NOT TARGET portable_kernels)
  add_subdirectory(${EXECUTORCH_ROOT}/kernels/portable
    ${CMAKE_CURRENT_BINARY_DIR}/silero_portable_kernels)
endif()
if(NOT DEFINED EXECUTORCH_ENABLE_DTYPE_SELECTIVE_BUILD)
  set(EXECUTORCH_ENABLE_DTYPE_SELECTIVE_BUILD "")
endif()
gen_selected_ops(
  LIB_NAME "silero_vad_portable_ops_lib"
  OPS_SCHEMA_YAML ""
  ROOT_OPS ""
  INCLUDE_ALL_OPS ""
  OPS_FROM_MODEL "${ET_PTE_FILE_PATH}"
  DTYPE_SELECTIVE_BUILD "${EXECUTORCH_ENABLE_DTYPE_SELECTIVE_BUILD}"
)
generate_bindings_for_kernels(
  LIB_NAME "silero_vad_portable_ops_lib"
  FUNCTIONS_YAML ${EXECUTORCH_ROOT}/kernels/portable/functions.yaml
  DTYPE_SELECTIVE_BUILD "${EXECUTORCH_ENABLE_DTYPE_SELECTIVE_BUILD}"
)
gen_operators_lib(
  LIB_NAME "silero_vad_portable_ops_lib"
  KERNEL_LIBS portable_kernels
  DEPS executorch
  DTYPE_SELECTIVE_BUILD "${EXECUTORCH_ENABLE_DTYPE_SELECTIVE_BUILD}"
)

set(MODEL_HEADER ${CMAKE_CURRENT_BINARY_DIR}/model_pte.h)
set(AUDIO_HEADER ${CMAKE_CURRENT_BINARY_DIR}/audio.h)
add_custom_command(
  OUTPUT ${MODEL_HEADER}
  COMMAND ${Python3_EXECUTABLE} ${EXECUTORCH_ROOT}/examples/arm/common/pte_to_header.py
    --pte ${ET_PTE_FILE_PATH} --outdir ${CMAKE_CURRENT_BINARY_DIR}
    --section .rodata.silero_model
  DEPENDS ${ET_PTE_FILE_PATH} ${EXECUTORCH_ROOT}/examples/arm/common/pte_to_header.py
  VERBATIM
)
target_sources(app PRIVATE src/main.cpp src/dashboard.cpp ${MODEL_HEADER}
  ${EXECUTORCH_ROOT}/examples/arm/common/arm_memory_allocator.cpp)
if(CONFIG_SILERO_LIVE_AUDIO)
  target_sources(app PRIVATE src/microphone.cpp)
else()
  if(NOT IS_ABSOLUTE "${AUDIO_PATH}" OR NOT EXISTS "${AUDIO_PATH}")
    message(FATAL_ERROR "Validation mode requires an absolute AUDIO_PATH.")
  endif()
  add_custom_command(
    OUTPUT ${AUDIO_HEADER}
    COMMAND ${Python3_EXECUTABLE}
      ${EXECUTORCH_ROOT}/examples/arm/silero_vad_example_ethos_u/runtime/wav_to_array.py
      --audio ${AUDIO_PATH} --output ${AUDIO_HEADER} --max-samples ${MAX_AUDIO_SAMPLES}
    DEPENDS ${AUDIO_PATH}
      ${EXECUTORCH_ROOT}/examples/arm/silero_vad_example_ethos_u/runtime/wav_to_array.py
    VERBATIM
  )
  target_sources(app PRIVATE ${AUDIO_HEADER})
endif()
target_include_directories(app PRIVATE ${CMAKE_CURRENT_BINARY_DIR}
  ${EXECUTORCH_ROOT}/examples/arm/common)
target_compile_definitions(app PRIVATE VAD_THRESHOLD=${VAD_THRESHOLD})
target_link_libraries(app PRIVATE libexecutorch extension_runner_util
  silero_vad_portable_ops_lib portable_kernels quantized_ops_lib)

foreach(registration_target silero_vad_portable_ops_lib quantized_ops_lib
    executorch_delegate_ethos_u)
  if(NOT TARGET ${registration_target})
    message(FATAL_ERROR "Required runtime target is missing: ${registration_target}")
  endif()
  executorch_target_link_options_shared_lib(${registration_target})
endforeach()
target_link_libraries(app PRIVATE executorch_delegate_ethos_u)
if(TARGET ethosu_core_driver)
  # The model, including commands and weights, is copied into shared SRAM.
  target_compile_definitions(ethosu_core_driver PRIVATE
    NPU_QCONFIG=0
    NPU_REGIONCFG_0=0)
  target_link_libraries(app PRIVATE ethosu_core_driver)
endif()
