/*
 * Copyright 2026 Arm Limited and/or its affiliates.
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * See LICENSE-BSD in the sample directory.
 */

#include <executorch/extension/data_loader/buffer_data_loader.h>
#include <executorch/runtime/core/memory_allocator.h>
#include <executorch/runtime/executor/program.h>
#include <executorch/runtime/platform/log.h>
#include <executorch/runtime/platform/platform.h>
#include <executorch/runtime/platform/runtime.h>
#include <algorithm>
#include <array>
#include <cinttypes>
#include <cstdint>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <vector>
#include <zephyr/cache.h>
#include <zephyr/kernel.h>

#include "arm_memory_allocator.h"

#if !CONFIG_SILERO_LIVE_AUDIO
#include "audio.h"
#endif
#include "microphone.h"
#include "dashboard.h"
#include "model_pte.h"

using executorch::aten::ScalarType;
using executorch::aten::Tensor;
using executorch::extension::BufferDataLoader;
using executorch::runtime::Error;
using executorch::runtime::EValue;
using executorch::runtime::HierarchicalAllocator;
using executorch::runtime::MemoryManager;
using executorch::runtime::Method;
using executorch::runtime::MethodMeta;
using executorch::runtime::Program;
using executorch::runtime::Result;
using executorch::runtime::Span;

constexpr size_t kSampleRate = 16000;
constexpr size_t kWindowSize = 512;
constexpr size_t kContextSize = 64;
constexpr size_t kInputSize = kWindowSize + kContextSize;
constexpr float kFrameDuration =
    static_cast<float>(kWindowSize) / static_cast<float>(kSampleRate);
constexpr float kVadThreshold = static_cast<float>(VAD_THRESHOLD);

alignas(16) static uint8_t method_allocation_pool[
    CONFIG_EXECUTORCH_METHOD_ALLOCATOR_POOL_SIZE];
alignas(16) static uint8_t temp_allocation_pool[
    CONFIG_EXECUTORCH_TEMP_ALLOCATOR_POOL_SIZE];
alignas(CONFIG_DCACHE_LINE_SIZE) static uint8_t model_pte_runtime[sizeof(model_pte)];

#if !CONFIG_SILERO_LIVE_AUDIO
void copy_input_frame(
    Tensor& input_tensor,
    std::array<float, kContextSize>& context,
    size_t frame_index) {
  float* input_data = input_tensor.mutable_data_ptr<float>();
  std::copy_n(context.data(), kContextSize, input_data);

  size_t offset = frame_index * kWindowSize;
  size_t remaining = audio_data_len > offset ? audio_data_len - offset : 0;
  size_t chunk_len = std::min(kWindowSize, remaining);

  if (chunk_len > 0) {
    std::copy_n(audio_data + offset, chunk_len, input_data + kContextSize);
  }
  if (chunk_len < kWindowSize) {
    std::fill_n(
        input_data + kContextSize + chunk_len, kWindowSize - chunk_len, 0.0f);
  }

  if (chunk_len >= kContextSize) {
    std::copy_n(
        audio_data + offset + chunk_len - kContextSize,
        kContextSize,
        context.data());
  } else if (chunk_len > 0) {
    size_t keep = kContextSize - chunk_len;
    std::move(context.begin() + chunk_len, context.end(), context.begin());
    std::copy_n(audio_data + offset, chunk_len, context.data() + keep);
  }
}

#endif

int main() {
  executorch::runtime::runtime_init();
  ET_LOG(Info, "Runtime initialized");
#if CONFIG_SILERO_LIVE_AUDIO
  ET_CHECK_MSG(dashboard_initialize(0, kSampleRate, kVadThreshold), "Display initialization failed");
#else
  ET_CHECK_MSG(dashboard_initialize(audio_data_len, kSampleRate, kVadThreshold), "Display initialization failed");
#endif
  std::memcpy(model_pte_runtime, model_pte, sizeof(model_pte));
  const int cache_status = sys_cache_data_flush_range(
      model_pte_runtime, sizeof(model_pte_runtime));
  ET_CHECK_MSG(cache_status == 0, "Model cache flush failed: %d", cache_status);
  BufferDataLoader loader(model_pte_runtime, sizeof(model_pte_runtime));
  ET_LOG(Info, "Size of the model = %zu", sizeof(model_pte));
  Result<Program> program = Program::load(&loader);
  ET_CHECK_MSG(
      program.ok(),
      "Program::load failed: 0x%" PRIx32,
      static_cast<uint32_t>(program.error()));

  const auto method_name_result = program->get_method_name(0);
  ET_CHECK_MSG(method_name_result.ok(), "Program has no methods");
  const char* method_name = *method_name_result;
  ET_LOG(Info, "Running method %s", method_name);

  Result<MethodMeta> method_meta_result = program->method_meta(method_name);
  ET_CHECK_MSG(
      method_meta_result.ok(),
      "method_meta lookup failed: 0x%" PRIx32,
      static_cast<uint32_t>(method_meta_result.error()));

  ArmMemoryAllocator method_allocator(
      sizeof(method_allocation_pool), method_allocation_pool);
  ArmMemoryAllocator temp_allocator(
      sizeof(temp_allocation_pool), temp_allocation_pool);

  std::vector<uint8_t*> planned_buffers;
  std::vector<Span<uint8_t>> planned_spans;
  size_t num_memory_planned_buffers =
      method_meta_result->num_memory_planned_buffers();
  ET_LOG(Info, "num_memory_planned_buffers = %zu", num_memory_planned_buffers);
  for (size_t id = 0; id < num_memory_planned_buffers; ++id) {
    size_t buffer_size =
        method_meta_result->memory_planned_buffer_size(id).get();
    ET_LOG(Info, "Planned memory buffer_size %zu %zu bytes", id, buffer_size);

    uint8_t* buffer = reinterpret_cast<uint8_t*>(
        method_allocator.allocate(buffer_size, 16UL));

    ET_CHECK_MSG(
        buffer != nullptr,
        "Could not allocate memory for memory planned buffer size %zu",
        buffer_size);
    planned_buffers.push_back(buffer);
    planned_spans.push_back({planned_buffers.back(), buffer_size});
  }
  HierarchicalAllocator planned_memory(
      {planned_spans.data(), planned_spans.size()});

  MemoryManager memory_manager(
      &method_allocator, &planned_memory, &temp_allocator);

  Result<Method> method = program->load_method(method_name, &memory_manager);
  ET_CHECK_MSG(
      method.ok(),
      "load_method failed: 0x%" PRIx32,
      static_cast<uint32_t>(method.error()));

  size_t num_inputs = method->inputs_size();
  ET_LOG(Info, "Number of input tensors = %zu", num_inputs);
  ET_CHECK_MSG(num_inputs == 1, "Silero VAD expects one audio input");

  EValue* input_evalues = method_allocator.allocateList<EValue>(num_inputs);
  Error input_status = method->get_inputs(input_evalues, num_inputs);
  ET_CHECK_MSG(input_status == Error::Ok, "Get inputs failed");
  Tensor& audio_input = input_evalues[0].toTensor();

  ET_CHECK_MSG(
      audio_input.scalar_type() == ScalarType::Float,
      "Audio input must be float");
  ET_CHECK_MSG(
      audio_input.dim() == 2 && audio_input.size(0) == 1 &&
          audio_input.size(1) == kInputSize,
      "Audio input expects %zu elements, got %zu",
      kInputSize,
      audio_input.numel());

#if CONFIG_SILERO_LIVE_AUDIO
  ET_CHECK_MSG(method->outputs_size() == 1, "Silero VAD expects one output");
  std::array<float, kContextSize> context{};
  std::array<int16_t, kWindowSize> pcm{};
  std::array<EValue, 1> outputs;
  ET_CHECK_MSG(dashboard_live_start(kVadThreshold), "Display worker failed");
  ET_CHECK_MSG(microphone_start(), "Microphone initialization failed");
  ET_LOG(Info, "LIVE microphone: PDM channel 4, 16000 Hz mono PCM16, 512 samples/window");
  ET_LOG(Info, "LIVE context/state persist; dashboard refreshes independently at 10 Hz");
  ET_LOG(Info, "LIVE hardware microphone gain=%ux; clipped counts exact PCM16 extrema", CONFIG_SILERO_MIC_GAIN);
  uint32_t frame = 0;
  uint32_t speech_frames = 0;
  uint32_t segments = 0;
  uint32_t max_buffered = 0;
  uint64_t clipped_samples = 0;
  bool speaking = false;
  const int64_t live_start = k_uptime_get();
  for (;;) {
    uint32_t buffered = 0;
    ET_CHECK_MSG(microphone_read(pcm.data(), pcm.size(), &buffered), "Microphone capture failed");
    max_buffered = std::max(max_buffered, buffered);
    float* input = audio_input.mutable_data_ptr<float>();
    std::copy(context.begin(), context.end(), input);
    float peak = 0.0f;
    double energy = 0.0;
    for (size_t i = 0; i < kWindowSize; ++i) {
      clipped_samples += pcm[i] == INT16_MIN || pcm[i] == INT16_MAX;
      const float sample = static_cast<float>(pcm[i]) / 32768.0f;
      input[kContextSize + i] = sample;
      peak = std::max(peak, std::abs(sample));
      energy += static_cast<double>(sample) * sample;
    }
    std::copy_n(input + kWindowSize, kContextSize, context.data());
    const int64_t started = k_uptime_get();
    const Error status = method->execute();
    ET_CHECK_MSG(status == Error::Ok, "Live inference failed: 0x%" PRIx32, static_cast<uint32_t>(status));
    ET_CHECK_MSG(method->get_outputs(outputs.data(), outputs.size()) == Error::Ok, "Live outputs failed");
    const Tensor probability_output = outputs[0].toTensor();
    ET_CHECK_MSG(probability_output.scalar_type() == ScalarType::Float && probability_output.numel() == 1,
        "Silero VAD expects one float probability");
    const float probability = probability_output.const_data_ptr<float>()[0];
    ET_CHECK_MSG(std::isfinite(probability) && probability >= 0.0f && probability <= 1.0f,
        "Invalid live probability");
    const int64_t inference_ms = k_uptime_get() - started;
    const bool speech = probability > kVadThreshold;
    speech_frames += speech;
    segments += speech && !speaking;
    speaking = speech;
    ++frame;
    const float rms = static_cast<float>(std::sqrt(energy / kWindowSize));
    dashboard_live_update(probability, peak, rms, frame, speech_frames, segments, inference_ms);
    if (frame % 32 == 0) {
      ET_LOG(Info, "LIVE frame=%u elapsed_ms=%lld p=%.6f %s rms=%.5f peak=%.5f inference_ms=%lld buffered_max=%u gain=%ux clipped=%llu",
          frame, static_cast<long long>(k_uptime_get() - live_start), static_cast<double>(probability),
          speech ? "speech" : "quiet", static_cast<double>(rms), static_cast<double>(peak),
          static_cast<long long>(inference_ms), max_buffered, CONFIG_SILERO_MIC_GAIN,
          static_cast<unsigned long long>(clipped_samples));
    }
  }
#else
  std::array<float, kContextSize> context{};
  size_t num_frames = (audio_data_len + kWindowSize - 1) / kWindowSize;
  ET_CHECK_MSG(num_frames > 0, "Audio must contain at least one frame");
  std::vector<float> probabilities(num_frames, 0.0f);
  size_t num_outputs = method->outputs_size();
  ET_CHECK_MSG(num_outputs == 1, "Silero VAD expects one probability output");
  std::vector<EValue> outputs(num_outputs);

  ET_LOG(
      Info,
      "Running %zu audio samples (%zu frames), threshold=%f",
      audio_data_len,
      num_frames,
      static_cast<double>(kVadThreshold));

  const int64_t start_ms = k_uptime_get();
  for (size_t frame_index = 0; frame_index < num_frames; ++frame_index) {
    copy_input_frame(audio_input, context, frame_index);

    Error inference_status = method->execute();
    ET_CHECK_MSG(
        inference_status == Error::Ok,
        "Inference failed 0x%" PRIx32,
        static_cast<uint32_t>(inference_status));

    Error outputs_status = method->get_outputs(outputs.data(), outputs.size());
    ET_CHECK_MSG(
        outputs_status == Error::Ok,
        "get_outputs failed 0x%" PRIx32,
        static_cast<uint32_t>(outputs_status));

    Tensor probability_output = outputs[0].toTensor();
    ET_CHECK_MSG(
        probability_output.scalar_type() == ScalarType::Float &&
            probability_output.numel() == 1,
        "Silero VAD expects one float probability");
    probabilities[frame_index] = probability_output.const_data_ptr<float>()[0];
  }
  const int64_t elapsed_ms = k_uptime_get() - start_ms;
  ET_LOG(
      Info,
      "Inference loop: %lld ms for %zu frames",
      static_cast<long long>(elapsed_ms),
      num_frames);

  bool speech_active = false;
  size_t speech_start_frame = 0;
  size_t speech_frames = 0;
  size_t num_segments = 0;

  for (size_t frame_index = 0; frame_index < num_frames; ++frame_index) {
    float probability = probabilities[frame_index];

    bool is_speech = probability > kVadThreshold;
    if (is_speech) {
      speech_frames++;
      if (!speech_active) {
        speech_active = true;
        speech_start_frame = frame_index;
      }
    } else if (speech_active) {
      speech_active = false;
      ET_LOG(
          Info,
          "SEGMENT %.3f %.3f speech",
          static_cast<double>(speech_start_frame * kFrameDuration),
          static_cast<double>(frame_index * kFrameDuration));
      num_segments++;
    }

    ET_LOG(
        Info,
        "PROB %.3f %f %s",
        static_cast<double>(frame_index * kFrameDuration),
        static_cast<double>(probability),
        is_speech ? "speech" : "silence");
  }

  if (speech_active) {
    ET_LOG(
        Info,
        "SEGMENT %.3f %.3f speech",
        static_cast<double>(speech_start_frame * kFrameDuration),
        static_cast<double>(num_frames * kFrameDuration));
    num_segments++;
  }

  float speech_percent = 100.0f * static_cast<float>(speech_frames) /
      static_cast<float>(num_frames);
  ET_LOG(
      Info,
      "%zu segments, %zu frames, %.1fs",
      num_segments,
      num_frames,
      static_cast<double>(num_frames * kFrameDuration));
  ET_LOG(
      Info,
      "Speech: %zu/%zu frames (%.1f%%)",
      speech_frames,
      num_frames,
      static_cast<double>(speech_percent));
  ET_LOG(Info, "Model executed successfully.");
  ET_LOG(Info, "Display: looping visual replay of prerecorded results; no new inference");
  dashboard_replay(probabilities.data(), num_frames, audio_data_len, kSampleRate,
      kVadThreshold, speech_frames, num_segments, elapsed_ms);
#endif
}
