# Local Alif E8 Silero VAD application

Copy `zephyr/samples/silero-vad-ethosu` into the pinned ExecuTorch checkout.
The application uses the existing Silero exporter and WAV/header helper without
changing the model. It runs prerecorded audio; no microphone driver is required.

The PTE and WAV are embedded into the firmware. At startup, the PTE is copied
once into aligned SRAM so that Ethos-U DMA access does not depend on MRAM mapping.
A single loaded method processes all frames, preserving the initialized int8
LSTM state and the 64-sample host context. CPU fallback kernels are selected from
the PTE and linked alongside the quantized kernels and Ethos-U delegate.

Configuration starts with a 2 MiB method pool, 1 MiB temporary pool, 64 KiB heap,
and 16 KiB main stack. The board overlay selects the same 7.25 MiB application
SRAM region as the validated MobileSAM Alif deployment and enables the HP NPU.
The current exported PTE has a 3,136-byte planned buffer. These allocator values
are capacities, not measured Silero hardware requirements.

The app stages the initialized west workspace's Ethos-U HAL headers in the build
directory and links Zephyr's existing driver. Set `ETHOSU_DRIVER_PATH` explicitly
if your workspace uses a different module location.

Build from the ExecuTorch source root using an already initialized vendor west
workspace and an active released-dependency Python environment:

```bash
west -z "$ZEPHYR_BASE" build -b alif_e8_dk/ae822fa0e5597xx0/rtss_hp \
  zephyr/samples/silero-vad-ethosu -d "$SILERO_OUTPUT/build-alif" -- \
  -DZEPHYR_EXTRA_MODULES="$EXECUTORCH_ROOT;$SDK_ALIF" \
  -DPython3_EXECUTABLE="$(command -v python)" \
  -DUSER_CACHE_DIR="$SILERO_OUTPUT/cache" \
  -DET_PTE_FILE_PATH="$SILERO_OUTPUT/silero_vad_ethos_u.pte" \
  -DAUDIO_PATH="$SILERO_OUTPUT/validation.wav"
```

Output format matches the source example: `PROB <time> <probability> speech|silence`
and `SEGMENT <start> <end> speech`, followed by `Model executed successfully.`.
The inference-loop timing covers input preparation, method execution, and output
retrieval; it excludes UART probability printing. It is not an NPU-only metric.

Validate captured application UART output with the existing
`examples/arm/silero_vad_example_ethos_u/runtime/compare_vad_probs.py` and the exact
`expected_probs.bin` produced by the same export and validation WAV.

Validated locally with ExecuTorch source `12dac4aa042b66a7229e8d7d3af2bdde8c9f262f`,
released Python packages torch 2.14.0, ExecuTorch 1.5.1 and TorchAO 0.18.0,
Alif Zephyr `f002a4d8499c35fc70ec4d5324faa7b01c152c72`, sdk-alif
`1db82c9d0cc594e2b548a13699e8a4157e6dcd4c`, and Zephyr SDK 0.17.0.
The firmware links successfully: 830,084 bytes of flash and 3,597,440 bytes of
RAM. The firmware load address is `0x80200000` (MRAM base `0x80000000` plus the
board's `0x200000` load offset). Application UART is UART4 at 115,200 baud.
The application has not been flashed or executed on a physical board.

The runner in `src/main.cpp` derives from the ExecuTorch Silero example and uses
the BSD 3-Clause license in `LICENSE-BSD`. The Zephyr application configuration
uses the Apache 2.0 license in `LICENSE-APACHE`.
