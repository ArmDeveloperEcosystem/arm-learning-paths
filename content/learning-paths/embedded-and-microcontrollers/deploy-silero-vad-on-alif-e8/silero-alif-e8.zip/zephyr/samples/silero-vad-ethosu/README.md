# Live Silero VAD on Alif Ensemble E8

The default configuration captures the E8 on-board PDM microphone (channel 4)
at 16 kHz, mono signed PCM16. Each new 512-sample block is divided by 32768 and
prepended with the previous 64 samples. One loaded ExecuTorch method retains its
initialized recurrent state throughout capture. The U85 runs the delegated
model; CPU fallback operations and streaming state remain on the CPU.

The RGB565 dashboard shows live probability, microphone RMS/peak energy,
a rolling 3.1-second probability history, speech activity and segment starts.
A lower-priority display thread refreshes independently, at most ten times per
second. Inference is paced by microphone reads, with no artificial frame delay.
UART prints a live diagnostic every 32 blocks; it does not print the embedded
clip's PROB/SEGMENT validation records in live mode.

The Alif driver requires `PDM_MODE_HIGH_QUALITY_512_CLK_FRQ` for 16 kHz; setting
`pcm_rate` alone does not set its rate. The application uses the vendor channel-4
phase and FIR coefficients, with the DC-blocking IIR enabled. The default
linear hardware gain is 50x (`CONFIG_SILERO_MIC_GAIN=50`, raw register `0x320`),
selected for this board's acoustic validation. The pinned SDK's live PDM source
uses the same unsigned 8.4 programming convention and contains a 50x fallback;
its LE-audio Kconfig default is 20x. The application's 50x setting is a measured
input-calibration choice, not a change to the PTE or the SDK default.
UART reports exact PCM16
extrema as a cumulative `clipped` sample count. Check quiet false positives and
clipping with real acoustic input; gain is hardware input conditioning and does
not change the PTE or classification threshold. Eight 1024-byte
slab blocks buffer capture. Each block is copied and released before inference.
A read timeout, wrong block size or near-exhausted slab stops the application
with an explicit error. The unmodified vendor driver can silently handle FIFO
overflow internally, so frame-rate/elapsed-time telemetry must also be checked.

The PTE is copied once into cache-line-aligned SRAM and cleaned from the CPU
cache. `NPU_QCONFIG=0` and `NPU_REGIONCFG_0=0` select the matching SRAM port.
The board keeps the display MIPI route selected continuously; no camera or MIPI
route switching is involved. The unmodified pinned vendor SDK supplies all
microphone and display drivers.

Build with the documented released Python environment and initialized vendor
west workspace:

```bash
west -z "$ZEPHYR_BASE" build -b alif_e8_dk/ae822fa0e5597xx0/rtss_hp \
  "$EXECUTORCH_ROOT/zephyr/samples/silero-vad-ethosu" \
  -d "$SILERO_OUTPUT/build-alif" -- \
  -DZEPHYR_EXTRA_MODULES="$EXECUTORCH_ROOT;$SDK_ALIF" \
  -DPython3_EXECUTABLE="$(command -v python)" \
  -DUSER_CACHE_DIR="$SILERO_OUTPUT/cache" \
  -DET_PTE_FILE_PATH="$SILERO_OUTPUT/silero_vad_ethos_u.pte"
```

For the separate deterministic embedded-clip test, add
`-DEXTRA_CONF_FILE=validation.conf` and
`-DAUDIO_PATH="$SILERO_OUTPUT/validation.wav"` in a fresh build directory.
This mode runs the original 79-window test once, emits all PROB/SEGMENT records,
then displays a clearly labeled replay of the cached results. Compare its UART
with `compare_vad_probs.py` and the same export's `expected_probs.bin`.
Validation mode does not start the microphone. It must not be mistaken for live
microphone validation.

Firmware hardware evidence and exact artifact identities are recorded in the
Learning Path validation section. A successful build alone is not proof of
microphone capture or real-time performance.

The runner derives from the ExecuTorch Silero example under `LICENSE-BSD`.
The application configuration, dashboard and microphone wrapper use
`LICENSE-APACHE`.
