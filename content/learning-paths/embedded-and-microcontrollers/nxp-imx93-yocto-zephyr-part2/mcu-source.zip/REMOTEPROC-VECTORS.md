# NXP remoteproc reset vectors

The pinned NXP Linux driver locates the i.MX93 M33 and i.MX95 M7 vector base
by the ELF section name `.interrupts`. Zephyr calls that section `rom_start`.
The updated build helper renames it after linking, then inspects the result.
The rename preserves all loadable code, data and addresses. The i.MX93 vector
base is `0x0ffe0000`; the i.MX95 vector base is zero. Without the named section,
the driver returns zero, which is wrong for this i.MX93 image.

Source: [NXP Linux imx_rproc_get_boot_addr](https://github.com/nxp-imx/linux-imx/blob/df24f9428e38740256a410b983003a478e72a7c0/drivers/remoteproc/imx_rproc.c#L841-L878).

## Update an existing board

The section-name correction alone only needs an ELF rebuild. The later
i.MX93 resource-table correction also requires rebuilding/flashing Part 1 and
rebuilding the ELF: both Linux and the MCU must use DDR address `0xa4010000`. The updated firmware manager also rejects missing or
invalid vector sections before starting remoteproc and preserves the original
startup error if the stop handshake fails.

If the previous test is still running without a control endpoint, run `poweroff`
on Linux, remove board power and reconnect it. Require `nxp-mcore status` to show
`offline` before continuing. Preserve the old ownership record; the manager
recovers verified records from the previous boot automatically.

From the extracted bundle on the build host:

```bash
scp components/firmware_manager.py root@BOARD_IP:/root/firmware_manager.py
scp check-linux.py root@BOARD_IP:/root/check-linux.py
scp build/heartbeat/zephyr/zephyr.elf root@BOARD_IP:/root/heartbeat.elf
```

Then, on the board:

```bash
nxp-mcore status
install -m 0644 /root/firmware_manager.py /usr/libexec/nxp-lp/firmware_manager.py
install -m 0644 /root/check-linux.py /usr/libexec/nxp-lp/check-linux.py
nxp-mcore load /root/heartbeat.elf
journalctl -u nxp-mcore-test.service -b --no-pager -n 60
ls -l /dev/nxp-temperature /dev/nxp-mcore-control
```

For Part 3, build/stage the temperature profile and publish a new component
version with the updated manager. Existing component versions are immutable.

The earlier metadata-only vector correction preserved PT_LOAD bytes.
The current resource-table correction rebuilds the firmware and Linux DTB. It
does not establish MCU execution, RPMsg communication or stop/restart on hardware.
