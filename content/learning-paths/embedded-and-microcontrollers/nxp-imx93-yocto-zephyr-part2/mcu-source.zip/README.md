# FRDM-IMX93 application-MCU source bundle

Use the corrected Part 1 image for `imx93-11x11-lpddr4x-frdm`. In the pinned Zephyr v4.3.0
virtual environment, run the native SDK setup helper before building:

```bash
cd "$HOME/nxp-imx93-mcu"
source "$HOME/nxp-imx93-zephyr-venv/bin/activate"
export ZEPHYR_WORKSPACE="$HOME/nxp-imx93-zephyr-workspace"
export ZEPHYR_TOOLCHAIN_VARIANT=zephyr
export ZEPHYR_SDK_INSTALL_DIR="$HOME/zephyr-sdk-0.17.4"
bash setup-zephyr-sdk.sh
bash build-zephyr.sh heartbeat
python3 inspect-elf.py build/heartbeat/zephyr/zephyr.elf
```

Use your actual SDK directory. The helper checks the pinned SDK/source,
applies the resource-table no-copy and retention patches, and validates the
TCM ELF. Target: `lp_frdm_imx93/mimx9352/m33` with the supplied local FRDM `boards/` root.
Both Part 2/3 contain matching corrected transport and board sources. Heartbeat
leaves sensor peripherals/GPIO disabled; temperature adds its own overlay.
See FRDM-INTEGRATION.md for this board's startup/HAL fixes and memory map.

The corrected Part 1 boot defaults automatically prepare `clk-imx93.mcore_booted`. Verify
the actual Linux arguments and run `check-linux.py` with the application MCU
offline. A stale saved environment needs the conditional Part 1 recovery;
EVK boot firmware must be replaced as a complete image. Do not preload a demo.

Both profiles were cross-compiled and inspected on the authoring host. Physical
FRDM startup/RPMsg, BMP280 readings, stop/restart and AWS deployment have not
been tested here. The i.MX8M Plus hardware result does not qualify these boards.

## MCU ownership recovery (November 9, 2026)

The shared manager now records the Linux boot ID, recovers verified previous-boot
ownership only with the core offline, and provides explicit recovery for legacy
records. Owned files are archived and the existing lock is retained. See
[MCU-RECOVERY.md](MCU-RECOVERY.md) for updating an existing image and the host
validation limits.

## BMP280 probe diagnostics (November 9, 2026)

The firmware now reports controller readiness, per-address read errors and chip
IDs instead of hiding every discovery failure behind -19. See SENSOR-PROBE.md
for interpretation and validation limits.

## Native build-host tools

Ubuntu x86_64 and arm64/aarch64 are accepted automatically. Activate the pinned
Zephyr Python environment (Python 3.12+) and set ZEPHYR_WORKSPACE, then run
`bash setup-zephyr-sdk.sh` from this bundle. It asks Zephyr v4.3.0's installer
for SDK 0.17.4 and arm-zephyr-eabi; west selects linux-x86_64 or linux-aarch64.
Existing SDKs are checked without replacement. Set ZEPHYR_SDK_INSTALL_DIR to
the installer-reported path, or a fresh host-specific directory when changing
hosts. The build helper checks the SDK metadata, executable tools, compiler
execution and Arm target before patching source or running CMake. The SDK's
host architecture differs from the MCU target: both hosts produce the same
board-specific Arm firmware. macOS x86_64/Arm SDK detection remains available
for Zephyr/staging; Yocto requires Linux. Host-matrix tests mock external tools;
full native Ubuntu arm64 compilation remains an acceptance check.

The build also names/checks `.interrupts` for NXP remoteproc. See
[REMOTEPROC-VECTORS.md](REMOTEPROC-VECTORS.md) for updating existing ELFs/images.

The i.MX93 resource table is now reserved at `0xa4010000` in shared DDR.
Rebuild/flash Part 1 and rebuild the Part 2/3 ELFs together; earlier TCM-table
images and firmware are incompatible with this update. Reuse the existing
Yocto WORKDIR and replace the extracted bundle at its existing path.
