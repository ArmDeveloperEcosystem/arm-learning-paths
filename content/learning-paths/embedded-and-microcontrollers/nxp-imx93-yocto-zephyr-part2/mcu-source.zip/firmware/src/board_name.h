#pragma once
#define LP_BOARD_NAME "NXP FRDM i.MX 93"
