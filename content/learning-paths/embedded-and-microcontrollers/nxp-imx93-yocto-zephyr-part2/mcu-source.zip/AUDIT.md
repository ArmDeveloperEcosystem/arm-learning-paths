# FRDM-IMX93 source and validation notes

Updated November 8, 2026 for the physical FRDM developer board.
BSP: LF6.12.49_2.2.0 / Walnascar.
NXP manifest: 07d7cd3f29a18e809f6391eea1be01103b1d6e13.
meta-imx: 1cfbbb8f9ce1d6071775ea6083b79d98597c8206.
Linux: df24f9428e38740256a410b983003a478e72a7c0.
U-Boot: 4ddbad60eff308a5b356fb9ab8734ac382ddd692.
meta-aws: 5d73130967dce143f44fe2f80d65361f6b653c5e (Lite 2.3.0).
Zephyr: 3568e1b6d5cdd51a6b964a2a1d6d29200fea2056 (v4.3.0); SDK 0.17.4.

See [FRDM-INTEGRATION.md](FRDM-INTEGRATION.md) for the actual board-specific
memory/boot policy, shared fixes, source links and limits. This replaces the
previous source-only validation status: heartbeat and temperature now have real
cross-build/ELF checks. The Linux trees and the i.MX95 SM policy have source
configuration/build validation; the Yocto helper tests use simulated BitBake.

Neither board was hardware-tested here and no full BitBake image was built.
The i.MX8M Plus user's successful heartbeat is not evidence of i.MX93/i.MX95
execution. Physical BMP280, startup/stop/restart and cloud acceptance remain
outstanding. Evidence is under the learning path's validation directory.

## MCU ownership recovery (November 9, 2026)

The shared manager now records the Linux boot ID, recovers verified previous-boot
ownership only with the core offline, and provides explicit recovery for legacy
records. Owned files are archived and the existing lock is retained. See
[MCU-RECOVERY.md](MCU-RECOVERY.md) for updating an existing image and the host
validation limits.

## BMP280 probe diagnostics (November 9, 2026)

The firmware now reports controller readiness, per-address read errors and chip
IDs instead of hiding every discovery failure behind -19. See SENSOR-PROBE.md
for interpretation and validation limits.
