# Diagnose BMP280 discovery

The older acquisition code returned -ENODEV (-19) for both failed I2C reads and
an unexpected chip ID. The updated configure_sensor() prints probe v1, hardware
controller readiness/name, and the read result at each of 0x76 and 0x77. It
prints a chip ID only when register 0xd0 was actually read. If both reads fail,
the original first bus error is preserved. A BME280 response (0x60) is identified
and still rejected; BMP280 requires 0x58. A successful sample still uses the
same calibrated temperature conversion and RPMsg schema.

Interpret the new MCU DEBUG output:

- Controller not ready: investigate Zephyr device initialization/configuration.
- read_rc=0, chip_id=0x58: accepted BMP280 at that address.
- read_rc=0, another ID: the responding device does not match this app.
- Negative read_rc: the transaction failed; no chip ID was obtained. The NXP
  I2C driver maps several hardware failures to -EIO (-5), so this alone does
  not prove that a NACK, clock, wiring or power fault is the cause.

Open the MCU debug console before loading. Stop the existing owner normally,
then load the temperature diagnostic ELF. Successful temperature samples go
over RPMsg; the UART does not print every temperature.

Eight host scenarios compile and execute the actual hardware-I2C acquisition
source using emulated bus operations, including both accepted addresses,
controller-not-ready, bus errors/timeouts, wrong IDs and ambiguous devices.
Run python3 tools/test_sensor_probe.py on a host with a C compiler. These
checks do not validate physical pins, analog levels, GPIO I2C or real sensors.
Clock roots, pin routing, resource tables and transport were not changed by
this diagnostic update.
