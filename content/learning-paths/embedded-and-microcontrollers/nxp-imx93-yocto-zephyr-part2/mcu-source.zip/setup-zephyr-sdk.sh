#!/usr/bin/env bash
set -Eeuo pipefail
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source "$HERE/host-platform.sh"
lp_detect_host
mode=${1:-install}
[[ $mode == install || $mode == --check ]] || { echo 'Usage: setup-zephyr-sdk.sh [--check]' >&2; exit 2; }
export ZEPHYR_SDK_INSTALL_DIR=${ZEPHYR_SDK_INSTALL_DIR:-$HOME/zephyr-sdk-0.17.4}
printf 'Build host: %s/%s; Zephyr SDK platform: %s\n' "$LP_HOST_OS" "$LP_HOST_ARCH" "$LP_SDK_PLATFORM"
sdk_error() {
    printf 'A runnable %s Zephyr SDK 0.17.4 with arm-zephyr-eabi is required at: %s\n' "$LP_SDK_PLATFORM" "$ZEPHYR_SDK_INSTALL_DIR" >&2
    echo 'Activate the Zephyr v4.3.0 Python environment and run: bash setup-zephyr-sdk.sh' >&2
    echo 'If west reuses an SDK elsewhere, set ZEPHYR_SDK_INSTALL_DIR to its reported directory.' >&2
    echo 'For an incompatible existing SDK, select a fresh host-specific installation directory.' >&2
    exit 1
}
if [[ ! -e $ZEPHYR_SDK_INSTALL_DIR && $mode == install ]]; then
    : "${ZEPHYR_WORKSPACE:?Set ZEPHYR_WORKSPACE to your west workspace}"
    ZEPHYR="$ZEPHYR_WORKSPACE/zephyr"
    [[ $(git -C "$ZEPHYR" rev-parse HEAD) == 3568e1b6d5cdd51a6b964a2a1d6d29200fea2056 ]] || { echo 'Use the pinned Zephyr v4.3.0 checkout.' >&2; exit 1; }
    # Zephyr's installer uses platform.system()/machine() to select native assets.
    (cd "$ZEPHYR" && python3 -m west sdk install --version 0.17.4 \
        --toolchains arm-zephyr-eabi --install-dir "$ZEPHYR_SDK_INSTALL_DIR")
fi
[[ -r "$ZEPHYR_SDK_INSTALL_DIR/sdk_version" &&
   -r "$ZEPHYR_SDK_INSTALL_DIR/cmake/Zephyr-sdkConfig.cmake" &&
   -r "$ZEPHYR_SDK_INSTALL_DIR/cmake/Zephyr-sdkConfigVersion.cmake" &&
   -x "$ZEPHYR_SDK_INSTALL_DIR/arm-zephyr-eabi/bin/arm-zephyr-eabi-gcc" &&
   -x "$ZEPHYR_SDK_INSTALL_DIR/arm-zephyr-eabi/bin/arm-zephyr-eabi-readelf" &&
   -x "$ZEPHYR_SDK_INSTALL_DIR/arm-zephyr-eabi/bin/arm-zephyr-eabi-objcopy" &&
   -x "$ZEPHYR_SDK_INSTALL_DIR/arm-zephyr-eabi/bin/arm-zephyr-eabi-objdump" ]] || sdk_error
[[ $(cat "$ZEPHYR_SDK_INSTALL_DIR/sdk_version") == 0.17.4 ]] || sdk_error
compiler="$ZEPHYR_SDK_INSTALL_DIR/arm-zephyr-eabi/bin/arm-zephyr-eabi-gcc"
"$compiler" --version >/dev/null 2>&1 || sdk_error
[[ $("$compiler" -dumpmachine) == arm-zephyr-eabi ]] || sdk_error
printf 'Using Zephyr SDK 0.17.4: %s\n' "$ZEPHYR_SDK_INSTALL_DIR"
