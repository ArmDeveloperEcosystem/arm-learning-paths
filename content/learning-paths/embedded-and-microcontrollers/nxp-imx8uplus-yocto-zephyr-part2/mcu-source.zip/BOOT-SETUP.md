# FRDM boot setup and the resolved heartbeat hang

## Current working configuration

The user reported continuous heartbeat sequences 60–82 after rebuilding the
corrected Part 1 FRDM image and running the corrected Part 2 ELF. The Linux
preflight passed, remoteproc start returned and the control HELLO/READY exchange
completed. The tested ELF SHA256 is
`5f6e8ff0c1b3c6596b13bb49c8e22a16f3e73a56a5431cf111742f2730abb27c`.
See `../validation/BOARD-RESULT.md` for the supplied evidence and limits.

The required M7 boot preparation is still necessary. **The corrected Part 1
image performs it automatically**, using these compiled defaults:

```text
bootcmd=run prepare_mcore; run bsp_bootcmd
fdtfile=imx8mp-frdm.dtb
prepare_mcore=setenv mcore_clk clk-imx8mp.mcore_booted
```

No additional manual U-Boot settings are needed for the already-working image.
Before the first test of a new image, verify the bootloader's actual control DT:

```text
fdt addr ${fdtcontroladdr}
fdt print / model
fdt print / compatible
printenv bootcmd fdtfile prepare_mcore
```

Require FRDM identity. After Linux boots, with M7 offline, run:

```bash
cat /proc/device-tree/model
cat /proc/cmdline
python3 check-linux.py
```

Require `clk-imx8mp.mcore_booted` in the running Linux command line and passing
preflight. The manager and `nxp-mcore load` run the same check before starting
M7. Run it before loading, not while an already-started core is running.
`collect-linux.py` can capture a read-only JSON report.

## Recover only when a saved environment overrides the defaults

A saved environment can survive a new image and replace the compiled boot
command. If U-Boot's control DT is FRDM but the active boot path or Linux
argument is wrong, test this temporary boot without saving changes:

```text
setenv fdtfile imx8mp-frdm.dtb
run prepare_mcore
run bsp_bootcmd
```

Recheck Linux identity, arguments and preflight. Part 1's setup guide describes
the conditional one-time `saveenv` repair if persistence is needed. Do not reset
the entire environment or change settings on a boot already passing these checks.
The BSP path is explicit because a prior `bootflow scan -lb` can bypass the
`mmcargs` expansion of `mcore_clk`. `prepare_mcore` sets a Linux clock-driver
flag; it does not directly initialize TCM through register writes.

## Earlier failure: EVK boot firmware on FRDM

The ELF-only retry still hung. The supplied U-Boot was
`2025.04-g4ddbad60eff3`; its control model was
`NXP i.MX8MPlus LPDDR4 EVK board`, compatible `fsl,imx8mp-evk`. Its environment
selected `imx8mp-evk.dtb`, and did not show `mcore_clk`. FRDM DTBs were present
on the FAT partition, but that did not establish their use.

Read-only inspection of the supplied
`nxp-lp-dev-image-imx8mpevk.rootfs.wic.zst` confirmed EVK bootloader DTs at
`0x20e90` and `0x18a5c8`, before the first partition at 8 MiB. Changing only
`fdtfile` cannot replace EVK SPL/DDR setup, U-Boot control DT or secure firmware.
The original WIC and failing ELF remain preserved.

The corrected Part 1 build uses:

```text
MACHINE=imx8mp-lpddr4-frdm
UBOOT_CONFIG_BASENAME=imx8mp_frdm
UBOOT_DTB_NAME=imx8mp-frdm.dtb
```

It defaults to `build-frdm` within the existing WORKDIR, explicitly selects
FRDM, checks resolved U-Boot configuration, patches the boot defaults above,
and inspects the finished WIC's raw boot area. Reuse the existing WORKDIR's
sources/downloads; an old EVK `build/` directory is left untouched.
The shared `flash_evk` container target name alone does not identify the board.

Write the complete verified FRDM WIC to SD. With power off, select SD using
FRDM SW5 positions 1–4 = `0 0 1 1`, then boot that card's firmware. If the
control DT still identifies EVK, correct the image or boot device selection
before loading M7. Do not hide the mismatch by changing `board_name`.

This path modifies `imx8mp-frdm.dtb` directly. NXP's stock control demo instead
uses `imx8mp-frdm-rpmsg.dtb` with its matching TCM demo ELF; it is a separate
integration. Keep M7 offline at boot for the Linux manager and do not run
`bootaux` first.

## Evidence limits

The corrected image plus heartbeat now has user-reported startup/RPMsg success.
The exact instruction or kernel operation causing the original freeze remains
unidentified. Temperature hardware readings, stop/restart and AWS deployment
need separate acceptance. The optional `diagnostics/tcm-spin.S` diagnostic was
cross-built but has not been hardware-tested and is unnecessary for this
working heartbeat configuration.

## Primary sources

- [Pinned FRDM Yocto machine](https://github.com/nxp-imx/meta-imx/blob/1cfbbb8f9ce1d6071775ea6083b79d98597c8206/meta-imx-bsp/conf/machine/imx8mp-lpddr4-frdm.conf)
- [NXP FRDM U-Boot config](https://github.com/nxp-imx/uboot-imx/blob/lf_v2025.04/configs/imx8mp_frdm_defconfig)
- [NXP FRDM U-Boot control DT](https://github.com/nxp-imx/uboot-imx/blob/lf_v2025.04/arch/arm/dts/imx8mp-frdm.dts)
- [NXP FRDM U-Boot boot commands](https://github.com/nxp-imx/uboot-imx/blob/lf_v2025.04/board/freescale/imx8mp_frdm/imx8mp_frdm.env)
- [NXP FRDM guide: boot switches and M7 prerequisites](https://www.nxp.com/document/guide/getting-started-with-frdm-imx8mplus:GS-FRDM-IMX8MPLUS)
