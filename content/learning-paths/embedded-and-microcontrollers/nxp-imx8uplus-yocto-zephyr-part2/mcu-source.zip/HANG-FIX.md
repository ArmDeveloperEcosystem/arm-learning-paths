# FRDM-IMX8MPLUS: M7 startup hangs Linux

**November 8 result:** after rebuilding the corrected Part 1 FRDM image, the
user reported a successful control handshake and continuous heartbeat sequences
60–82 with the corrected ELF. Linux remained responsive. The earlier ELF-only
retry still hung with EVK boot firmware. See [BOOT-SETUP.md](BOOT-SETUP.md) for
the current normal boot and conditional stale-environment recovery.

This board is **FRDM-IMX8MPLUS**, not the EVK and not i.MX 8ULP. The directory's
`imx8uplus` spelling is a learning-path identifier. The reusable Zephyr SoC target
is `imx8mp_evk/mimx8ml8/m7`; the FRDM application must override its startup and
limit peripheral ownership. Merely changing a board name does not fix this.

## Findings

1. The old Linux-owned-table patch removes the `memcpy()` reference to a static
   `resource_table` object, leaving only `sizeof(resource_table)`. At optimization,
   GCC removes the object entirely. **Both a baseline build and the supplied failing ELF
   have no `.resource_table` section.** Linux therefore has no RPMsg virtio template
   to process, while firmware expects Linux to populate the table at `0x550ff000`.
   `0002-keep-resource-table.patch` adds `__used`, preserving the ELF template
   without overwriting Linux's runtime table. Linker `KEEP()` alone cannot retain
   an object that the compiler never emitted. The helper handles an already
   applied old patch and applies the retention fix separately.

2. Zephyr v4.3.0 `soc/nxp/imx/imx8m/m7/soc.c` provides a **weak**
   `SOC_ClockInit()` which switches the shared AHB root through the 24 MHz
   oscillator and then sets it to SYS_PLL1/6. It also switches the M7 root.
   This runs before `main()`, while Linux is already using the SoC. The source
   warns against reinitializing system PLLs, but this version does not actually
   reinitialize them; its shared root writes are the concern. The new strong
   `src/frdm_clock.c` leaves AHB, AXI, M7, DRAM roots and PLL configuration to
   U-Boot/ATF/Linux. It configures only the M7-owned UART4 root (and I2C3 in
   temperature mode), retaining the upstream clock gate enables.
3. The original Part 1 policy called the ring nodes `vring@55000000` and
   `vring@55008000`. Linux registers those **node names** as carveout names,
   then looks for `vdev0vring0` and `vdev0vring1`. Labels such as `lp_vring0`
   do not supply those names. With a host-allocated resource table (`da=-1`),
   Linux can allocate different vrings from its DMA allocator instead of the
   intended reservations. The M7's declared shared-memory window cannot safely
   describe arbitrary Linux RAM. The corrected Part 1 ZIP uses
   `vdev0vring0@55000000`, `vdev0vring1@55008000`, and `vdev0buffer@55400000`.
   The firmware now rejects unexpected ring addresses before initializing them.
4. MU **hardware register 1** is the Linux mailbox channel in this DT. The old
   application used the vring notification ID as the hardware register and
   polled a hardcoded notification ID. The corrected transport always sends via
   MU register 1, encodes the notification in the upper 16 payload bits, and
   services both vrings using the host-populated notification IDs.
5. Heartbeat inherited GPIO3 and enabled I2C3 unnecessarily. All GPIO banks and
   I2C3 are now disabled for heartbeat. Temperature has a separate overlay.
   `CACHE_MANAGEMENT=y` also makes the requested `OPENAMP_WITH_DCACHE=y` effective;
   previously Kconfig dropped it because its dependency was absent.
6. The FRDM boot preparation was missing from Part 2. NXP requires
   `run prepare_mcore` before booting Linux for remoteproc use. A visible
   `/sys/class/remoteproc` entry alone does not establish a prepared boot.

The supplied failing `elf/nxp-imx8uplus-heartbeat.elf` has now been inspected.
Its SHA256 is `12ea3bb760af10680028114dd75cd5ebefdf24a7a15f1b1e174fc2e94278a0af`.
It confirms the missing ELF resource table, weak `SOC_ClockInit`, GPIO support,
and old mailbox handling. Its load destinations fit TCM. Disassembly confirms
writes to the live AHB root at `0x30389000` and M7 root at `0x30388080` before
`main()`. The clock writes are the strongest firmware-side lead for a board-wide
hang; the missing table is independently a confirmed RPMsg startup defect.
The exact original freeze instruction remains unknown. The corrected heartbeat
subsequently ran successfully with the rebuilt FRDM image, as reported by the
user; this does not isolate which earlier defect triggered the hard hang.

## Repair the Linux side first

For this learning path, re-extract the **updated Part 1 `yocto-build.zip`** and
rebuild/boot its image for `imx8mp-lpddr4-frdm`. The corrected policy modifies
`imx8mp-frdm.dts`, so select **`imx8mp-frdm.dtb`** from that rebuilt image.
Existing deployed DTBs do not change when the Zephyr ELF is rebuilt.

If maintaining an already-patched Linux checkout manually, the supplemental
`patches/linux-vring-names.patch` makes the same three node-name corrections.
Update the Yocto layer's original patch too, so a clean rebuild retains them.
Do not add this migration patch to the Zephyr source. Do not apply both Linux
patch variants to the same tree.

The corrected Part 1 boot defaults automatically run `prepare_mcore`, then
`bsp_bootcmd`, using `imx8mp-frdm.dtb`. No repeated manual U-Boot commands are
needed if Linux receives `clk-imx8mp.mcore_booted`. An old saved environment
can override these defaults; follow the conditional recovery in BOOT-SETUP.md
and Part 1's setup guide. Do not preload an M7 demo with `bootaux`.

For comparison, NXP's **stock** FRDM guide uses `imx8mp-frdm-rpmsg.dtb` with
`prepare_mcore`. That stock DT also assigns additional peripherals to NXP's
demonstration firmware. It is a separate integration from this path's minimal
custom DT. Never select an EVK Linux DTB for the FRDM board.

Once the corrected Linux image boots, copy `check-linux.py` to the board and run:

```bash
python3 check-linux.py
```

This read-only check verifies FRDM identity, the running M7 boot argument, the four
named memory reservations, UART4 release, driver binding, and an offline M7. The
U-Boot control-tree identity must be verified separately. For early isolation, NXP's matching TCM `hello_world.elf`, if
installed in `/lib/firmware`, can establish whether the Linux/bootloader setup
can start any M7 firmware. Use its real filename and do not load two owners.

## Rebuild and inspect the corrected firmware

From the newly extracted Part 2 bundle in the activated Zephyr Python environment:

```bash
export ZEPHYR_WORKSPACE="$HOME/nxp-imx8uplus-zephyr-workspace"
export ZEPHYR_TOOLCHAIN_VARIANT=zephyr
export ZEPHYR_SDK_INSTALL_DIR="$HOME/zephyr-sdk-0.17.4"
bash build-zephyr.sh heartbeat
```

The helper now runs `inspect-elf.py` after compilation. It rejects the old weak
clock initializer, non-TCM load segments, invalid reset vectors, and an unexpected
resource table. For an existing artifact, inspect it separately:

```bash
python3 inspect-elf.py build/heartbeat/zephyr/zephyr.elf
"$ZEPHYR_SDK_INSTALL_DIR/arm-zephyr-eabi/bin/arm-zephyr-eabi-nm" \
    build/heartbeat/zephyr/zephyr.elf | grep SOC_ClockInit
"$ZEPHYR_SDK_INSTALL_DIR/arm-zephyr-eabi/bin/arm-zephyr-eabi-objdump" \
    -d --disassemble=SOC_ClockInit build/heartbeat/zephyr/zephyr.elf
```

Require `T SOC_ClockInit`, not `W SOC_ClockInit`, and disassembly from the new
FRDM implementation. The checker establishes layout and symbol linkage; review
the disassembly to establish what the linked code writes. M7 device addresses
`0x00000000..0x0001ffff` map to A53 ITCM `0x007e0000..0x007fffff`;
M7 DTCM `0x20000000..0x2001ffff` maps to A53 `0x00800000..0x0081ffff`.
Keep the ELF's **M7 addresses**; do not relink at the A53 aliases or use `.bin`
with Linux remoteproc. The fixed runtime resource table is at `0x550ff000`;
Linux patches it using the ELF's resource-table template.

## Controlled FRDM test

Connect USB debug at **J19**, not J23. NXP identifies the first serial interface
as A53/Linux and the second as M7/UART4. Capture both at 115200 8N1. Keep the A53
serial log running as well as SSH, so console loss can be distinguished from a
kernel failure. First load only heartbeat using the documented `nxp-mcore load`
owner, after Linux preflight passes. Require Linux uptime/SSH and M7 heartbeat
to remain healthy before testing temperature or Part 3.

If it still hangs, preserve the exact failing ELF, `zephyr.map`, `zephyr.dts`,
`.config`, both serial logs, `cat /proc/cmdline`, the running DT
(`/sys/firmware/fdt` where available), U-Boot `printenv prepare_mcore`, and kernel
version. Determine whether the last event was ELF segment loading, M7 release,
or RPMsg announcement. A hang before M7 release points toward TCM accessibility,
boot firmware, or loading rather than the application's clock function.

NXP describes Linux-driven stopping of the i.MX8MP M7 as a debug feature, not a
recommended production lifecycle. The existing STOP/QUIESCED exchange reduces
application activity but does not establish that reset is production-safe.
Treat repeated load/stop cycles as development acceptance only.

## Primary references

- [NXP FRDM getting-started guide: M7 enablement and J19](https://www.nxp.com/document/guide/getting-started-with-frdm-imx8mplus:GS-FRDM-IMX8MPLUS)
- [Pinned Zephyr M7 initialization](https://github.com/zephyrproject-rtos/zephyr/blob/v4.3.0/soc/nxp/imx/imx8m/m7/soc.c)
- [Pinned NXP remoteproc driver](https://github.com/nxp-imx/linux-imx/blob/df24f9428e38740256a410b983003a478e72a7c0/drivers/remoteproc/imx_rproc.c)
- [Pinned Linux vring allocator](https://github.com/nxp-imx/linux-imx/blob/df24f9428e38740256a410b983003a478e72a7c0/drivers/remoteproc/remoteproc_core.c)
- [NXP FRDM RPMsg reference DT](https://github.com/nxp-imx/linux-imx/blob/df24f9428e38740256a410b983003a478e72a7c0/arch/arm64/boot/dts/freescale/imx8mp-frdm-rpmsg.dts)
