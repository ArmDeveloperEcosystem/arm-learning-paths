# NXP FRDM i.MX 8M Plus source and validation notes

Current status (November 8, 2026): the user reported successful heartbeat/control
communication after rebuilding the corrected Part 1 FRDM image. Part 3 has
since been aligned and cross-compiled; see the final series-alignment section.
Earlier dated notes retain the prior failure and validation history.


Research date: October 29, 2026. BSP: LF6.12.49_2.2.0 / Walnascar.
NXP manifest commit: 07d7cd3f29a18e809f6391eea1be01103b1d6e13.
meta-imx: 1cfbbb8f9ce1d6071775ea6083b79d98597c8206.
Linux: df24f9428e38740256a410b983003a478e72a7c0.
meta-aws: 5d73130967dce143f44fe2f80d65361f6b653c5e (Lite 2.3.0).
Zephyr v4.3.0: 3568e1b6d5cdd51a6b964a2a1d6d29200fea2056; SDK 0.17.4.

Build setup correction: November 7, 2026. The helper now selects SDK 0.17.4
explicitly (default `$HOME/zephyr-sdk-0.17.4`, override with
`ZEPHYR_SDK_INSTALL_DIR`), validates its version, CMake package files and Arm
compiler executable before patching, and omits the unused local `BOARD_ROOT`.
The build instructions install only the required Arm toolchain and explain SDK
discovery recovery. Validation covered Bash syntax, real CMake discovery using
the official SDK 0.17.4 package files, simulated missing/incomplete/wrong SDKs,
heartbeat/temperature command forwarding, paths containing spaces, patch
idempotence against the pinned upstream source, preservation of conflicting
edits, and failure propagation without inspecting an absent ELF. These checks
did not compile or run firmware.

Authoring checks cover syntax, source/patch consistency, recipes, compensation,
and simulated lifecycle behavior. Full Yocto compilation, Zephyr cross-compilation,
physical sensor routing, power sequencing, and AWS deployment were not executed
in the authoring environment. The FRDM i.MX 8M Plus profile reuses upstream i.MX 8M Plus M7 SoC support
with its supplied application overlay; the upstream target identifier is retained for build compatibility.
Run the documented image/MCU builds and deploy-remove-deploy-remove acceptance
on the actual board. Do not treat a model of remoteproc or a successful recipe
registration as proof of hardware operation.

November 7, 2026 FRDM M7 hang correction:
- Rebuilt the original source ZIP with v4.3.0 and SDK 0.17.4. Its ELF has no
  .resource_table section: removing memcpy made the static template unused and
  GCC omitted it. Its clock initializer is weak, and GPIO support is enabled.
- Added a separate __used retention patch, a strong FRDM SOC_ClockInit which
  leaves shared AHB/M7 roots and PLL configuration alone, disabled heartbeat
  GPIO/I2C3, enabled the cache-management dependency, separated the temperature
  overlay, and fixed MU channel/notification handling. Unexpected runtime vring
  addresses now fail before ring initialization.
- Corrected Part 1 Linux reserved-memory node names and provided a migration
  patch. The old policy plus migration and the corrected policy both applied to
  the pinned NXP DTS and produced identical source.
- Cross-compiled corrected heartbeat and temperature using the official source
  archives and exactly the required manifest module revisions, through CMake
  directly on the macOS Arm host with SDK 0.17.4. Both builds passed. Each ELF
  has an 88-byte resource table, valid ITCM/DTCM vectors/segments and a strong
  SOC_ClockInit. The helper's west/commit gate was not exercised by this direct
  CMake build. Its patches were tested on pristine and old-patched source and
  for repeat application.
- The ELF inspector accepts both corrected artifacts and rejects the original,
  wrong architecture, DDR load addresses, invalid vectors, wrong ring count and
  a weak clock initializer. Linux preflight was exercised against a synthetic
  FRDM sysfs tree and rejected EVK identity, old names, wrong ranges, Linux-owned
  UART4 and an already-running M7. Bash and Python syntax checks passed.
- Corrected J19 debug-USB routing and documented NXP's prepare_mcore prerequisite.
  Updated source ZIPs and checksums accompany these changes. Artifact evidence
  is in the learning path's validation directory.
No physical FRDM test, full Yocto build/boot, or production reset qualification
was performed. The specific hard-hang trigger therefore remains unconfirmed.

Supplied-ELF follow-up: the user identified elf/nxp-imx8uplus-heartbeat.elf.
SHA256: 12ea3bb760af10680028114dd75cd5ebefdf24a7a15f1b1e174fc2e94278a0af.
The exact binary confirms the missing resource table; rsc_table_get returns the
fixed 0x550ff000/88-byte runtime table without providing its ELF template.
It contains the weak clock initializer at 0x940, writes the AHB root at
0x30389000 and M7 root at 0x30388080, enables GPIO, and retains the old mailbox
handling. Its segments and vectors fit the expected TCM layout. The artifact
checker rejects it. Original binary preserved; disassembly and findings saved
under validation/failing-elf and validation/FAILING-ELF.md. No live DT or A53/M7
crash log was supplied, so clock initialization remains a leading hypothesis
for the board-wide hang rather than a hardware-confirmed diagnosis.

November 8, 2026 persistent-hang and boot-setup correction:
The user reports that the first corrected ELF still hangs when used as an ELF-only
update. Supplied U-Boot environment and control-tree commands show U-Boot
2025.04-g4ddbad60eff3 with EVK model/compatible, EVK board values and EVK fdtfile.
FRDM DTBs are present on mmc 1:1, but the live Linux DT remains uncollected.
prepare_mcore is defined but mcore_clk is absent in the provided environment.
bootflow runs before the BSP path and may bypass mmcargs. These establish a
boot-image mismatch and unverified M7 argument delivery; they do not identify
the exact hardware operation that freezes Linux.
BOOT-SETUP.md now prioritizes a matching FRDM boot image/device before any new
M7 attempt. The Linux preflight now requires the running clock-driver boot flag,
recognizes both NXP FRDM compatible spellings, and is installed/invoked by the
Part 1 load wrapper and manager before firmware/sysfs changes. Stage logs bracket
the kernel start call. A new Part 1 BitBake guard rejects reused EVK machine,
U-Boot base/DTB or explicit defconfig selections; it was checked against pinned
machine defaults and synthetic mismatch environments, not a full Yocto build.
The read-only collect-linux.py captures live DT/arguments/remoteproc configuration.
A 72-byte ITCM-only diagnostic loop was built/disassembled. It accesses no shared
peripheral registers or DDR and is for later loader/start isolation after the
boot setup is corrected. It has not been run on hardware and is not a new fix.
Preflight positive/negative fixture checks, early-abort manager checks, source
syntax, archive equality and checksum checks passed. No further heartbeat firmware
change, physical-board operation or reflash was performed during this follow-up.

## November 8, 2026: working image and series alignment

The user rebuilt Part 1 for `imx8mp-lpddr4-frdm`, booted the new SD image and
reported the corrected heartbeat running with Linux responsive. The journal
confirms the M7 clock argument, named carveouts, return from remoteproc start
and HELLO/READY control handshake. Sequences 60–82 advanced continuously using
one open RPMsg descriptor. Tested heartbeat SHA256:
`5f6e8ff0c1b3c6596b13bb49c8e22a16f3e73a56a5431cf111742f2730abb27c`.
See Part 2's `validation/BOARD-RESULT.md` for the user-reported evidence.

Part 3 now shares corrected Part 2 firmware/build sources, both table patches,
strong FRDM clock initializer, separate temperature overlay and ELF inspector.
Its manager and staged recipe include the same Linux preflight as Part 1/2.
The build and packaging validation results are recorded in Part 3's validation
directory. Compiled Part 1 defaults perform the M7 preparation automatically;
manual U-Boot recovery is conditional on an old saved environment overriding
them. Earlier chronological failure notes describe the prior EVK-image setup.

Physical BMP280 acquisition, stop/restart qualification and AWS deployment
remain unreported. No full BitBake build was run on this macOS authoring host.

## MCU ownership recovery (November 9, 2026)

The shared manager now records the Linux boot ID, recovers verified previous-boot
ownership only with the core offline, and provides explicit recovery for legacy
records. Owned files are archived and the existing lock is retained. See
[MCU-RECOVERY.md](MCU-RECOVERY.md) for updating an existing image and the host
validation limits.

## BMP280 probe diagnostics (November 9, 2026)

The firmware now reports controller readiness, per-address read errors and chip
IDs instead of hiding every discovery failure behind -19. See SENSOR-PROBE.md
for interpretation and validation limits.
