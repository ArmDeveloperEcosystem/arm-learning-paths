# Diagnostic ITCM spin probe

This probe is a diagnostic, not a replacement heartbeat or a fix. First establish
a matching FRDM bootloader and Linux DTB and run the Linux preflight. The user's
November 8 U-Boot control tree identifies an **EVK**, so the next action for that
setup is correcting the board image, not running this probe.

`tcm-spin.elf` has one 72-byte ITCM load segment at M7 address zero. Its reset code
executes `cpsid i` and loops in ITCM. It does not initialize Zephyr, change RDC or
clocks, access UART/GPIO/DDR, or start RPMsg. The initial SP points into DTCM, but
the reset loop does not use the stack. No output or heartbeat is expected.

Build on the host with SDK 0.17.4 selected:

```bash
bash diagnostics/build-probe.sh
```

If later used for isolation on an established FRDM setup, load it through Linux
remoteproc directly with the exact offline M7 selected. Do not use `nxp-mcore
load`: its manager requires the RPMsg control handshake, which this probe lacks.
The kernel's `No resource table in elf` message is expected for this probe.
Capture the A53 serial console throughout. Do not read TCM through `devmem` after
starting M7; secure-firmware permissions can change at M7 release.

Interpretation:

- A whole-board hang with this probe occurs without application peripheral or
  RPMsg initialization. Investigate Linux's ITCM load, secure-firmware start,
  bootloader/clock setup and board image before modifying the application again.
- A returned start with Linux still responsive narrows the later failure to
  code/resources absent from this probe. A returned start alone does not prove
  that the M7 is executing the loop.

No physical-board execution of this probe has been performed. It is intentionally
not offered as another blind retry for the currently mismatched EVK boot setup.
