ENTRY(Reset_Handler)
MEMORY { ITCM (rx) : ORIGIN = 0, LENGTH = 128K }
PHDRS { itcm PT_LOAD FLAGS(5); }
SECTIONS {
    .vectors 0 : { KEEP(*(.vectors)) } > ITCM :itcm
    .text : { *(.text*) } > ITCM :itcm
    /DISCARD/ : { *(.comment) *(.note*) }
}
