#!/usr/bin/env bash
set -Eeuo pipefail
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
: "${ZEPHYR_SDK_INSTALL_DIR:?Set ZEPHYR_SDK_INSTALL_DIR to SDK 0.17.4}"
bash "$HERE/../setup-zephyr-sdk.sh" --check
prefix="$ZEPHYR_SDK_INSTALL_DIR/arm-zephyr-eabi/bin/arm-zephyr-eabi-"
mkdir -p "$HERE/build"
"${prefix}gcc" -mcpu=cortex-m7 -mthumb -nostdlib -nostartfiles \
    -Wl,--build-id=none -Wl,-T,"$HERE/tcm.ld" \
    "$HERE/tcm-spin.S" -o "$HERE/build/tcm-spin.elf"
"${prefix}readelf" -h -l "$HERE/build/tcm-spin.elf"
"${prefix}objdump" -d "$HERE/build/tcm-spin.elf"
