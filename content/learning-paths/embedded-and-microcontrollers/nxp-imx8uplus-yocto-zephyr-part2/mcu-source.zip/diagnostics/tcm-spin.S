/* SPDX-License-Identifier: Apache-2.0
 * Loader/start probe: ITCM instruction fetch only, no peripheral or DDR access.
 */
.syntax unified
.cpu cortex-m7
.thumb

.section .vectors,"a",%progbits
.balign 128
.word 0x20020000
.word Reset_Handler
.rept 14
.word Fault_Handler
.endr

.section .text,"ax",%progbits
.global Reset_Handler
.type Reset_Handler,%function
.thumb_func
Reset_Handler:
    cpsid i
1:  b 1b
.size Reset_Handler, .-Reset_Handler

.type Fault_Handler,%function
.thumb_func
Fault_Handler:
    cpsid i
2:  b 2b
.size Fault_Handler, .-Fault_Handler
