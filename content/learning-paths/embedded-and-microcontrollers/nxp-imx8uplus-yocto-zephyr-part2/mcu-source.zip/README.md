# NXP FRDM i.MX 8M Plus MCU source bundle

The user reported successful heartbeat execution after rebuilding and booting
the corrected Part 1 FRDM image. The control handshake completed and sequences
60 through 82 advanced continuously while Linux remained responsive. The tested
ELF SHA256 is `5f6e8ff0c1b3c6596b13bb49c8e22a16f3e73a56a5431cf111742f2730abb27c`.
See `../validation/BOARD-RESULT.md` for evidence and limits.

[BOOT-SETUP.md](BOOT-SETUP.md) explains the earlier EVK boot-image mismatch.
The first corrected ELF still locked that old setup; an ELF-only update was
insufficient.
[HANG-FIX.md](HANG-FIX.md) records the separate ELF/RPMsg defects.
The correction requires the updated Part 1 Linux DTB, FRDM U-Boot
`prepare_mcore`, and rebuilt Zephyr firmware. Run `check-linux.py` on Linux
before loading; `build-zephyr.sh` runs `inspect-elf.py` on the host ELF.

Build with the pinned Zephyr v4.3.0 workspace and SDK 0.17.4. From the
extracted MCU bundle, activate its Python environment and run SDK setup before
building:

```bash
cd "$HOME/nxp-imx8uplus-mcu"
source "$HOME/nxp-imx8uplus-zephyr-venv/bin/activate"
export ZEPHYR_WORKSPACE="$HOME/nxp-imx8uplus-zephyr-workspace"
export ZEPHYR_TOOLCHAIN_VARIANT=zephyr
export ZEPHYR_SDK_INSTALL_DIR="$HOME/zephyr-sdk-0.17.4"
bash setup-zephyr-sdk.sh
bash build-zephyr.sh heartbeat
bash build-zephyr.sh temperature
```

Use the SDK directory reported by west if it differs from the default above.
The helper checks the SDK version, CMake package and Arm compiler before patching
or building. Selecting `ZEPHYR_TOOLCHAIN_VARIANT=zephyr` alone does not install
the SDK. An SDK discovery failure prevents creation of `zephyr.elf`.

Target: `imx8mp_evk/mimx8ml8/m7`. This profile reuses the upstream i.MX 8M Plus SoC target with the supplied FRDM application
overlay and resource-table integration patch. The `evk` in the upstream target identifier
is retained for build compatibility; the physical board is FRDM-IMX8MPLUS.
The strong `src/frdm_clock.c` initializer preserves Linux-owned shared clock roots.
Heartbeat does not initialize GPIO or I2C3; temperature enables I2C3 separately.
The board definition comes from Zephyr; this bundle does not need `BOARD_ROOT`.
The resource-table patches retain the ELF template and preserve the runtime table
populated by Linux remoteproc.
Part 2 uses heartbeat. Part 3 uses compensated BMP280 sensing and two RPMsg TTY
endpoints. The control endpoint quiesces the app before Linux powers down the core.
The corrected heartbeat and temperature were cross-compiled and their ELF layouts
inspected with Zephyr v4.3.0 and SDK 0.17.4. The user then rebuilt the FRDM
Yocto image and reported the heartbeat result above. No physical BMP280,
stop/restart qualification or AWS deployment has been reported. Complete those
acceptance checks before using the temperature application.

The corrected Part 1 boot defaults run `prepare_mcore` automatically. No repeated
manual U-Boot adjustment is needed if Linux receives `clk-imx8mp.mcore_booted`.
An old saved environment requires the conditional recovery in Part 1's setup
page. Do not preload an M7 demo before Linux.

## MCU ownership recovery (November 9, 2026)

The shared manager now records the Linux boot ID, recovers verified previous-boot
ownership only with the core offline, and provides explicit recovery for legacy
records. Owned files are archived and the existing lock is retained. See
[MCU-RECOVERY.md](MCU-RECOVERY.md) for updating an existing image and the host
validation limits.

## BMP280 probe diagnostics (November 9, 2026)

The firmware now reports controller readiness, per-address read errors and chip
IDs instead of hiding every discovery failure behind -19. See SENSOR-PROBE.md
for interpretation and validation limits.

## Native build-host tools

Ubuntu x86_64 and arm64/aarch64 are accepted automatically. Activate the pinned
Zephyr Python environment (Python 3.12+) and set ZEPHYR_WORKSPACE, then run
`bash setup-zephyr-sdk.sh` from this bundle. It asks Zephyr v4.3.0's installer
for SDK 0.17.4 and arm-zephyr-eabi; west selects linux-x86_64 or linux-aarch64.
Existing SDKs are checked without replacement. Set ZEPHYR_SDK_INSTALL_DIR to
the installer-reported path, or a fresh host-specific directory when changing
hosts. The build helper checks the SDK metadata, executable tools, compiler
execution and Arm target before patching source or running CMake. The SDK's
host architecture differs from the MCU target: both hosts produce the same
board-specific Arm firmware. macOS x86_64/Arm SDK detection remains available
for Zephyr/staging; Yocto requires Linux. Host-matrix tests mock external tools;
full native Ubuntu arm64 compilation remains an acceptance check.
