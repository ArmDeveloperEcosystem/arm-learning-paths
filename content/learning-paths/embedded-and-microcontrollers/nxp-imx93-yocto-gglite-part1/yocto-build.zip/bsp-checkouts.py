#!/usr/bin/env python3
"""Protect BSP edits while preserving the pinned NXP setup's file overrides."""

import json
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET


PINS = {
    'sources/meta-imx': '1cfbbb8f9ce1d6071775ea6083b79d98597c8206',
    'sources/meta-freescale': '3d2781ad200846183ee3f3391f49512d0ef1b529',
}
MANIFEST_REVISION = '07d7cd3f29a18e809f6391eea1be01103b1d6e13'
# The release tag currently resolves here. Its two setup replacements were
# verified byte-for-byte against the pinned BSP. Accept only its known setup
# deletions before sync; reapply still requires the exact PINS revisions.
PRE_SYNC_META_IMX_REVISIONS = {'21bca6b58f2bedefdfa4a58c66c8f512fd504351'}
UPSTREAM = 'sources/meta-freescale'
OVERLAY = 'sources/meta-imx/meta-imx-bsp'
# setup-utils.sh:hook_in_layer removes these upstream duplicates, even for i.MX8.
OVERRIDES = {
    'conf/machine/imx95-19x19-verdin.conf',
    'conf/machine/include/imx95-evk.inc',
}


def command(*args, cwd=None):
    return subprocess.run(args, cwd=cwd, check=True, stdout=subprocess.PIPE,
                          text=True, errors='surrogateescape').stdout


def git(root, *args):
    return command('git', '-C', str(root), *args)


def status(root, *paths):
    fields = iter(git(root, 'status', '--porcelain=v1', '-z',
                      '--untracked-files=all', '--ignore-submodules=none',
                      '--', *paths).split('\0'))
    entries = []
    for field in fields:
        if not field:
            continue
        state, path = field[:2], field[3:]
        entries.append((state, path))
        if 'R' in state or 'C' in state:
            next(fields)  # The original name follows a renamed/copied path.
    return entries


def has_clean_replacement(workdir, path, allow_release_tag=False):
    if path not in OVERRIDES:
        return False
    for project, revision in PINS.items():
        actual = git(workdir / project, 'rev-parse', 'HEAD').strip()
        allowed = {revision}
        if allow_release_tag and project == 'sources/meta-imx':
            allowed |= PRE_SYNC_META_IMX_REVISIONS
        if actual not in allowed:
            return False
    overlay = workdir / OVERLAY
    replacement = overlay / path
    if not replacement.is_file() or replacement.is_symlink():
        return False
    # Require a tracked, unchanged replacement; mere existence is insufficient.
    tracked = git(overlay, 'ls-files', '--', path).strip()
    return tracked == path and not status(overlay, path)


def inspect(workdir, projects):
    generated, dirty = [], []
    for project in projects:
        root = workdir / project
        if not (root / '.git').exists():
            if root.exists() and any(root.iterdir()):
                dirty.append(f'{project}: uninitialized checkout contains files')
            continue  # Initial/partial sync: absent checkouts have no edits to lose.
        for state, path in status(root):
            if (project == UPSTREAM and state == ' D'
                    and has_clean_replacement(workdir, path, allow_release_tag=True)):
                generated.append(path)
            else:
                dirty.append(f'{project}: {state} {path!r}')
    if dirty:
        raise RuntimeError('BSP checkouts contain local changes:\n'
                           + '\n'.join(dirty)
                           + '\nPreserve BSP checkout edits before syncing. '
                           'Commit or copy them outside WORKDIR, then resolve '
                           'the listed changes and retry.')
    return sorted(generated)


def pin_release(workdir):
    """Make repo select the same immutable revision checked after sync."""
    actual = git(workdir / '.repo/manifests', 'rev-parse', 'HEAD').strip()
    if actual != MANIFEST_REVISION:
        raise RuntimeError(f'Manifest revision mismatch: expected {MANIFEST_REVISION}, found {actual}')
    revision = PINS['sources/meta-imx']
    content = ('<?xml version="1.0" encoding="UTF-8"?>\n<manifest>\n'
               f'  <extend-project name="meta-imx" path="sources/meta-imx" revision="{revision}" />\n'
               '</manifest>\n')
    directory = workdir / '.repo/local_manifests'
    if directory.is_symlink():
        raise RuntimeError('Preserve the symlinked local_manifests directory; select a regular directory for the release pin')
    directory.mkdir(exist_ok=True)
    target = directory / 'nxp-lp-release.xml'
    if target.is_symlink() or (target.exists() and target.read_text() != content):
        raise RuntimeError(f'Preserving conflicting local manifest: {target}')
    if not target.exists():
        with target.open('x') as output:
            output.write(content)
    resolved = ET.fromstring(command('repo', 'manifest', cwd=workdir))
    matches = [p for p in resolved.iter('project')
               if p.get('name') == 'meta-imx' and p.get('path') == 'sources/meta-imx']
    if len(matches) != 1 or matches[0].get('revision') != revision:
        raise RuntimeError('Another manifest overrides the meta-imx pin; preserve local manifests and resolve the conflict before syncing')
    return revision


def reapply(workdir, generated):
    # Sync may restore these files. Retain only deletions accepted before sync;
    # never remove a new or edited file, or a file from a different BSP release.
    upstream = workdir / UPSTREAM
    for path in generated:
        if not has_clean_replacement(workdir, path):
            raise RuntimeError(f'NXP replacement changed; refusing to remove {path!r}')
        if status(upstream, path) not in ([], [(' D', path)]):
            raise RuntimeError(f'BSP file changed during sync; preserving {path!r}')
        if git(upstream, 'ls-files', '--', path).strip() != path:
            raise RuntimeError(f'BSP file is not tracked; preserving {path!r}')
    for path in generated:
        target = upstream / path
        if target.exists():
            target.unlink()
            print(f'Preserved NXP setup override: {UPSTREAM}/{path}', file=sys.stderr)


def main():
    mode, directory = sys.argv[1:]
    workdir = Path(directory).resolve()
    if mode == 'check':
        projects = command('repo', 'list', '-p', cwd=workdir).splitlines()
        print(json.dumps(inspect(workdir, projects)))
    elif mode == 'reapply':
        reapply(workdir, json.load(sys.stdin))
    elif mode == 'pin':
        print(pin_release(workdir))
    else:
        raise ValueError(f'Unknown operation: {mode}')


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, ValueError, ET.ParseError, subprocess.CalledProcessError, OSError) as error:
        print(f'BSP checkout check failed: {error}', file=sys.stderr)
        sys.exit(1)
