#!/usr/bin/env python3
"""Check resolved Greengrass recipe metadata and the completed image audit."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys

CONTRACT = Path(__file__).resolve().parent / 'meta-nxp-lp/recipes-core/nxp-lp-tools/files/greengrass-runtime.json'


def environment(text):
    result = {}
    for line in text.splitlines():
        match = re.fullmatch(r'(?:export )?([^=\s]+)=(".*")', line)
        if match:
            # BitBake escapes quotes and dollars for shell output, not Python.
            # Keep other backslashes literal (for example regexes and paths).
            result[match[1]] = match[2][1:-1].replace(r'\"', '"').replace(r'\$', '$')
    return result


def verify_config(values, contract):
    for key, expected in [('PN', contract['recipe']), ('PV', contract['version']),
                          ('SRCREV_ggl', contract['source_revision'])]:
        if values.get(key) != expected:
            raise ValueError(f'Greengrass {key}={values.get(key)!r}; expected {expected!r}')
    if 'systemd' not in values.get('DISTRO_FEATURES', '').split():
        raise ValueError('Greengrass Lite requires the systemd distro feature')
    options = shlex.split(values.get('EXTRA_OECMAKE', ''))
    service_options = [v.split('=', 1)[1].upper() for v in options
                       if v.startswith('-DGGL_SYSTEMD_SERVICE_BUILD=')]
    if not service_options or service_options[-1] not in ('ON', 'TRUE', '1'):
        raise ValueError('GGL_SYSTEMD_SERVICE_BUILD must explicitly be ON')
    services = values.get('SYSTEMD_SERVICE:greengrass-lite', values.get('SYSTEMD_SERVICE', '')).split()
    missing = set(contract['units']) - set(services)
    if missing:
        raise ValueError('Greengrass recipe omits systemd units: ' + ', '.join(sorted(missing)))
    for field, required in [('DEPENDS', contract['build_dependencies']),
                            ('RDEPENDS:greengrass-lite', contract['runtime_dependencies'])]:
        missing = set(required) - set(values.get(field, '').split())
        if missing:
            raise ValueError(field + ' is missing: ' + ', '.join(sorted(missing)))
    auto = values.get('SYSTEMD_AUTO_ENABLE:greengrass-lite', values.get('SYSTEMD_AUTO_ENABLE'))
    if auto != 'disable':
        raise ValueError('Keep the unprovisioned Greengrass services disabled until device credentials are installed')
    return {'result': 'pass', 'recipe': contract['recipe'], 'version': contract['version'],
            'source_revision': contract['source_revision'], 'systemd_service_build': True,
            'systemd_auto_enable': auto, 'units': sorted(services),
            'build_dependencies': contract['build_dependencies'],
            'runtime_dependencies': contract['runtime_dependencies']}


def verify_image(directory, machine, contract):
    path = directory / f'nxp-lp-dev-image-{machine}.greengrass.json'
    report = json.loads(path.read_text())
    if report.get('result') != 'pass' or report.get('machine') != machine:
        raise ValueError('Missing successful Greengrass image audit for this machine')
    for key in ('version', 'source_revision'):
        if report.get(key) != contract[key]:
            raise ValueError('Image audit uses a different Greengrass ' + key)
    for key in ('units', 'executables', 'packages', 'users', 'groups', 'support_files'):
        missing = set(contract[key]) - set(report.get(key, []))
        if missing:
            raise ValueError('Incomplete image audit ' + key + ': ' + ', '.join(sorted(missing)))
    time_sync = report.get('time_sync', {})
    if (time_sync.get('configuration') != contract['time_sync']['configuration']
            or time_sync.get('unit') != contract['time_sync']['unit'] or not time_sync.get('sources')):
        raise ValueError('Image audit is missing the external NTP configuration check')
    manifest = directory / report['manifest_file']
    if manifest.name != report['manifest_file']:
        raise ValueError('Invalid image manifest filename in audit')
    if hashlib.sha256(manifest.read_bytes()).hexdigest() != report['manifest_sha256']:
        raise ValueError('Greengrass image audit does not match the deployed package manifest')
    packages = {line.split()[0] for line in manifest.read_text().splitlines() if line.strip()}
    if set(contract['packages']) - packages:
        raise ValueError('Required Greengrass packages are missing from the deployed image manifest')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['config', 'image'])
    parser.add_argument('--contract', type=Path, default=CONTRACT)
    parser.add_argument('--deploy-dir', type=Path)
    parser.add_argument('--machine')
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    try:
        contract = json.loads(args.contract.read_text())
        if args.mode == 'config':
            result = subprocess.run(['bitbake', '-e', 'greengrass-lite'], text=True, capture_output=True)
            if result.returncode:
                sys.stderr.write(result.stderr)
                raise ValueError('Could not resolve the required Greengrass Lite recipe')
            report = verify_config(environment(result.stdout), contract)
        else:
            if not args.deploy_dir or not args.machine:
                parser.error('image mode needs --deploy-dir and --machine')
            report = verify_image(args.deploy_dir, args.machine, contract)
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + '\n')
        print(f"PASS: Greengrass Lite {args.mode} audit: {contract['version']}, "
              f"{len(contract['executables'])} executables, {len(contract['units'])} units")
    except (OSError, ValueError, KeyError) as error:
        sys.exit('Greengrass build rejected: ' + str(error))


if __name__ == '__main__':
    main()
