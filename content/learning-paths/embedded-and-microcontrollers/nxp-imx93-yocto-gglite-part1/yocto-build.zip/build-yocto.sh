#!/usr/bin/env bash
set -Eeuo pipefail
usage() {
 echo 'Usage: build-yocto.sh [--install-deps] [--configure-only] [--no-sdk]'
 echo 'FRDM build directory: WORKDIR/build-frdm (override the directory name with LP_BUILD_DIR).'
}
install_deps=0; configure_only=0; sdk=1
for arg in "$@"; do case "$arg" in
 --install-deps) install_deps=1;; --configure-only) configure_only=1;; --no-sdk) sdk=0;;
 -h|--help) usage; exit 0;; *) usage >&2; exit 2;; esac; done
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source "$HERE/board.env"
: "${MACHINE:?board.env must define MACHINE (imx93-11x11-lpddr4x-frdm for this board)}"
[[ $MACHINE == imx93-11x11-lpddr4x-frdm ]] || { echo 'This FRDM bundle requires MACHINE=imx93-11x11-lpddr4x-frdm.' >&2; exit 1; }
# BSP setup deliberately unsets MACHINE; retain the board selection for reporting.
readonly LP_MACHINE="$MACHINE"
LP_BUILD_DIR=${LP_BUILD_DIR:-build-frdm}
[[ $LP_BUILD_DIR =~ ^[[:alnum:]][[:alnum:]_.-]*$ ]] || { echo 'LP_BUILD_DIR must be a single relative directory name.' >&2; exit 2; }
readonly LP_BUILD_DIR
source "$HERE/host-platform.sh"
lp_detect_host
[[ $LP_HOST_OS == Linux && $EUID != 0 ]] || { echo 'Use a non-root Ubuntu 22.04/24.04 x86_64 or arm64 Linux host.' >&2; exit 1; }
readonly LP_HOST_OS LP_HOST_ARCH
printf 'Build host: %s/%s; SDKMACHINE=%s\n' "$LP_HOST_OS" "$LP_HOST_ARCH" "$LP_HOST_ARCH"
[[ ${ACCEPT_FSL_EULA:-0} == 1 ]] || { echo 'Read NXP EULA first, then explicitly set ACCEPT_FSL_EULA=1 if you accept.' >&2; exit 1; }
JOBS=${JOBS:-4}; [[ $JOBS =~ ^[1-9][0-9]*$ ]] || exit 2
WORKDIR=${WORKDIR:-$HOME/yocto-$LP_ID}
[[ $HERE != *[[:space:]]* && $WORKDIR != *[[:space:]]* ]] || { echo 'Use Linux filesystem paths without spaces.' >&2; exit 1; }
if ((install_deps)); then
 sudo apt-get update
 sudo apt-get install -y build-essential chrpath cpio diffstat gawk gcc git iputils-ping libacl1 liblz4-tool locales python3 python3-git python3-jinja2 python3-pexpect python3-pip python3-subunit repo socat texinfo unzip wget xz-utils zstd bzip2 rsync ca-certificates bc flex bison libssl-dev libncurses-dev util-linux
 sudo locale-gen en_US.UTF-8
fi
export LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8
for tool in repo git python3 gcc g++ make chrpath cpio diffstat gawk wget zstd flock unshare; do command -v "$tool" >/dev/null || { echo "Missing $tool" >&2; exit 1; }; done
unshare --user --map-root-user --net true || { echo 'Host namespace policy blocks BitBake; ask the host administrator to configure supported namespaces.' >&2; exit 1; }
mkdir -p "$WORKDIR"; WORKDIR=$(cd "$WORKDIR" && pwd)
exec 9>"$WORKDIR/.lp-build.lock"; flock -n 9 || { echo 'Build already running.' >&2; exit 1; }
cd "$WORKDIR"
host_record="$WORKDIR/$LP_BUILD_DIR/.nxp-lp-build-host"
if [[ -e $host_record && $(cat "$host_record") != "$LP_HOST_OS/$LP_HOST_ARCH" ]]; then
 echo 'This build directory belongs to another host architecture. Use a separate WORKDIR or LP_BUILD_DIR.' >&2
 exit 1
fi
if [[ ! -d .repo ]]; then repo init -u https://github.com/nxp-imx/imx-manifest -b 07d7cd3f29a18e809f6391eea1be01103b1d6e13 -m imx-6.12.49-2.2.0.xml; fi
# Accept only the pinned NXP setup's two known, unstaged file removals.
# All other BSP edits stop the build before syncing.
bsp_overrides=$(python3 "$HERE/bsp-checkouts.py" check "$WORKDIR") || exit 1
expected_revision=$(python3 "$HERE/bsp-checkouts.py" pin "$WORKDIR") || exit 1
printf 'Pinned NXP meta-imx revision: %s\n' "$expected_revision"
repo sync -d -j"$JOBS"
actual_revision=$(git -C sources/meta-imx rev-parse HEAD)
if [[ $actual_revision != "$expected_revision" ]]; then
 printf 'NXP meta-imx revision mismatch.\nExpected: %s\nActual:   %s\nInspect WORKDIR/.repo/local_manifests before retrying.\n' "$expected_revision" "$actual_revision" >&2
 exit 1
fi
python3 "$HERE/bsp-checkouts.py" reapply "$WORKDIR" <<< "$bsp_overrides"
AWS_DIR="$WORKDIR/sources/meta-aws"
if [[ ! -d $AWS_DIR/.git ]]; then git clone https://github.com/aws4embeddedlinux/meta-aws.git "$AWS_DIR"; fi
[[ -z $(git -C "$AWS_DIR" status --porcelain) ]] || { echo 'meta-aws contains edits.' >&2; exit 1; }
git -C "$AWS_DIR" fetch origin 5d73130967dce143f44fe2f80d65361f6b653c5e
git -C "$AWS_DIR" checkout --detach 5d73130967dce143f44fe2f80d65361f6b653c5e
export MACHINE SDKMACHINE="$LP_HOST_ARCH" DISTRO=fsl-imx-wayland ACCEPT_FSL_EULA
set +u
if [[ -f $LP_BUILD_DIR/conf/local.conf ]]; then
 source ./setup-environment "$LP_BUILD_DIR"
else
 source ./imx-setup-release.sh -b "$LP_BUILD_DIR"
fi
set -u
printf '%s/%s\n' "$LP_HOST_OS" "$LP_HOST_ARCH" > .nxp-lp-build-host
for layer in "$AWS_DIR" "$HERE/meta-nxp-lp"; do
 if ! bitbake-layers show-layers | grep -Fq "$layer"; then bitbake-layers add-layer "$layer"; fi
done
export LP_JOBS="$JOBS" LP_MACHINE LP_HOST_ARCH
python3 - <<'CONFIG'
from pathlib import Path
import os,re
p=Path('conf/local.conf');s=p.read_text()
s=re.sub(r'\n# BEGIN NXP LP\n.*?# END NXP LP\n','\n',s,flags=re.S)
s+='\n# BEGIN NXP LP\nMACHINE = "'+os.environ['LP_MACHINE']+'"\nSDKMACHINE = "'+os.environ['LP_HOST_ARCH']+'"\nINIT_MANAGER = "systemd"\nBB_NUMBER_THREADS = "'+os.environ['LP_JOBS']+'"\nPARALLEL_MAKE = "-j'+os.environ['LP_JOBS']+'"\n# END NXP LP\n'
p.write_text(s)
CONFIG
# Resolve BitBake values after setup; a reused local.conf can still select EVK.
python3 "$HERE/verify-machine.py" "$LP_MACHINE" "$WORKDIR/validation/boot-config.json"
python3 "$HERE/verify-greengrass.py" config --report "$WORKDIR/validation/greengrass-config.json"
repo manifest -r > "$WORKDIR/sources.lock.xml"
git -C "$AWS_DIR" rev-parse HEAD > "$WORKDIR/meta-aws.lock"
mkdir -p "$WORKDIR/validation/image"
if ((configure_only)); then
 bitbake -p
 bitbake -g nxp-lp-dev-image
 for graph in pn-buildlist recipe-depends.dot task-depends.dot; do [[ ! -f $graph ]] || cp "$graph" "$WORKDIR/validation/image/"; done
 if ((sdk)); then mkdir -p "$WORKDIR/validation/sdk"; bitbake -g -c populate_sdk nxp-lp-dev-image; for graph in pn-buildlist recipe-depends.dot task-depends.dot; do [[ ! -f $graph ]] || cp "$graph" "$WORKDIR/validation/sdk/"; done; fi
else
 # Build the patched fakeroot provider before any image packaging runs.
 echo 'Preparing pseudo-native with the host tar/openat2 compatibility backport.'
 bitbake pseudo-native
 bitbake nxp-lp-dev-image
 python3 "$HERE/inspect-boot-image.py" --deploy-dir "$WORKDIR/$LP_BUILD_DIR/tmp/deploy/images/$LP_MACHINE" \
     --machine "$LP_MACHINE" --require-frdm --require-mcore-boot --report "$WORKDIR/validation/boot-image.json"
 python3 "$HERE/verify-greengrass.py" image --deploy-dir "$WORKDIR/$LP_BUILD_DIR/tmp/deploy/images/$LP_MACHINE" \
     --machine "$LP_MACHINE" --report "$WORKDIR/validation/greengrass-image.json"
 if ((sdk)); then bitbake -c populate_sdk nxp-lp-dev-image; fi
fi
printf 'Image artifacts: %s\n' "$WORKDIR/$LP_BUILD_DIR/tmp/deploy/images/$LP_MACHINE"
