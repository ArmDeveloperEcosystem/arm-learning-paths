# FRDM-IMX93 Yocto build bundle

Build machine `imx93-11x11-lpddr4x-frdm` with the documented NXP EULA/Ubuntu prerequisites:

```bash
WORKDIR="$HOME/yocto-nxp-imx93" JOBS=4 bash build-yocto.sh --no-sdk
```

The helper defaults to `$WORKDIR/build-frdm`, retains an old `build/`, explicitly
sets the FRDM machine, checks resolved SD/U-Boot settings and inspects the actual
finished WIC raw boot area. Reports: `$WORKDIR/validation/boot-config.json` and
`boot-image.json`. Artifacts: `build-frdm/tmp/deploy/images/imx93-11x11-lpddr4x-frdm/`.
Keep the full bundle at its fixed path and reuse WORKDIR for sources/downloads.
The helper pins `meta-imx` in a generated local manifest before synchronizing,
so the checkout and revision check use the same exact BSP commit.
The pseudo/openat2 backport and edit-preserving BSP guard remain included.

The corrected FRDM boot defaults prepare `clk-imx93.mcore_booted` automatically and select
`imx93-11x11-frdm.dtb` through the BSP boot path, leaving the application MCU offline.
An old saved environment can override these defaults; see Part 1's setup page.

The installed manager and load wrapper run the FRDM Linux preflight before
selecting firmware or starting the core. Full Yocto compilation and board boot
must still be performed on the documented Ubuntu/FRDM setup. Host tests are
under `../tests/`; provenance and limits are in FRDM-INTEGRATION.md.

## Complete Greengrass Lite installation

This bundle now installs `packagegroup-nxp-lp-greengrass`, forces systemd-unit
installation and fails if the completed image lacks any audited runtime
executable, core unit or required package. The pinned services are
`ggl.core.tesd.service` and `ggl.core.gg-fleet-statusd.service`. See
[GREENGRASS-RUNTIME.md](GREENGRASS-RUNTIME.md) for all recipes/components,
metadata/rootfs checks and the corrected activation procedure. Update the full
bundle and rerun with the same WORKDIR; require both new Greengrass validation
reports before flashing.

## MCU ownership recovery (November 9, 2026)

The shared manager now records the Linux boot ID, recovers verified previous-boot
ownership only with the core offline, and provides explicit recovery for legacy
records. Owned files are archived and the existing lock is retained. See
[MCU-RECOVERY.md](MCU-RECOVERY.md) for updating an existing image and the host
validation limits.

## External time servers (November 10, 2026)

The image now installs ntp/ntpq explicitly and replaces the upstream LOCAL-only
ntp.conf with external servers. Its completed-rootfs audit rejects the old
configuration. Follow [the UTC repair procedure](GREENGRASS-RUNTIME.md#external-utc-synchronization)
for a running older image; verify real UTC before provisioning/deployment.
The live board's S3 diagnostic identified RequestTimeTooSkewed despite
`timedatectl` previously reporting synchronized. The MCU ELF is unchanged.

## Build host architecture

The helper detects Ubuntu/Linux x86_64 or arm64/aarch64 automatically and sets
SDKMACHINE to the detected host. The target MACHINE remains this FRDM board.
Run as a non-root user on Ubuntu 22.04/24.04 or a compatible Ubuntu-based system.
The dependency installer uses native apt packages on either architecture.
A recorded host architecture protects new build directories against reuse by
another architecture. Use a separate WORKDIR or LP_BUILD_DIR when switching
hosts; keep existing tmp trees, Python environments and SDKs on their own host.
The pinned NXP Arm GNU native-toolchain recipe and Yocto uninative metadata
already provide x86_64 and aarch64 downloads/checksums. No BSP revision change
or emulation is required by this helper. Script/fixture tests cover both hosts;
a full native Ubuntu arm64 image/SDK build has not been performed here.

The i.MX93 resource table is now reserved at `0xa4010000` in shared DDR.
Rebuild/flash Part 1 and rebuild the Part 2/3 ELFs together; earlier TCM-table
images and firmware are incompatible with this update. Reuse the existing
Yocto WORKDIR and replace the extracted bundle at its existing path.
