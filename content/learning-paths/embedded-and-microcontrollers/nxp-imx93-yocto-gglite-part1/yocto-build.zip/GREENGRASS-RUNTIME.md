# Complete Greengrass Lite runtime — November 8, 2026

## Audited recipe and service names

All three FRDM learning paths pin meta-aws at
`5d73130967dce143f44fe2f80d65361f6b653c5e`. Its
`greengrass-lite_2.3.0.bb` recipe pins the C runtime at
`584b9dadc5446e400f53ffa7d1b2c15dcc6b9e4f` and fetches/builds the matching SDK,
coreMQTT, backoff and SigV4 sources. The single runtime recipe installs all core
modules. The existing images already selected that recipe; no separate TES or
fleet-status recipe is needed.

The correct service names are `ggl.core.tesd.service` and
`ggl.core.gg-fleet-statusd.service`. The guide's prior `ggtesd`/`ggfleetstatusd`
spellings were wrong. Both the names and incomplete manual activation sequence
have been corrected. Absence of the former spelling alone does not establish
that the actual `tesd` executable or canonical service is missing from a board.
No live rootfs or completed new WIC was provided for this report.

## Required recipes and dependencies

The new `packagegroup-nxp-lp-greengrass` explicitly requires:

- `greengrass-lite`: the full pinned runtime, services and sockets.
- `libcgroup`: control-group library and tools.
- `sudo`: runtime process privilege/user changes.
- `ca-certificates`: TLS trust roots.
- `ntp` and `ntpq`: external UTC synchronization and its query tool.

The upstream recipe also requires `bash` and its compiled libraries through
`curl`, `libevent`, `libyaml`, `openssl`, `sdbus-c++-libsystemd`, `sqlite3`,
`util-linux-libuuid`, `uriparser` and `libzip`. The layer already includes these
providers. Metadata checks require all those dependencies; shared-library
runtime dependencies remain the package manager's responsibility. Python/pip,
OpenSSL tools, coreutils, util-linux and the other learning-path tools remain in
the image.

## Required runtime products

The 12 installed Greengrass executables are:

- `fleet-provisioning`
- `gg-fleet-statusd`
- `ggconfigd`
- `ggdeploymentd`
- `gghealthd`
- `ggipcd`
- `ggl-cli`
- `ggpubsubd`
- `iotcored`
- `recipe-runner`
- `tes-serverd`
- `tesd`

The core systemd set contains nine services, nine sockets and one target:

- `ggl.aws.greengrass.TokenExchangeService.service`
- `ggl.aws_iot_mqtt.socket`
- `ggl.aws_iot_tes.socket`
- `ggl.core.gg-fleet-statusd.service`
- `ggl.core.ggconfigd.service`
- `ggl.core.ggdeploymentd.service`
- `ggl.core.gghealthd.service`
- `ggl.core.ggipcd.service`
- `ggl.core.ggpubsubd.service`
- `ggl.core.iotcored.service`
- `ggl.core.tesd.service`
- `ggl.gg-ipc.socket.socket`
- `ggl.gg_config.socket`
- `ggl.gg_deployment.socket`
- `ggl.gg_fleet_status.socket`
- `ggl.gg_health.socket`
- `ggl.gg_pubsub.socket`
- `ggl.ipc_component.socket`
- `greengrass-lite.target`

Cloud/connection-kit provisioning and cloud component deployment use these core
units. Optional fleet-provisioning and image-local-deployment services are not
required for this learning path's manual provisioning flow; their executables
and recipe feature switches are separate from core unit installation.

## Checks in the updated build

The bbappend forces `GGL_SYSTEMD_SERVICE_BUILD=ON`, retains disabled services
until provisioning, and installs a marker with the version/source actually
packaged. The target checker compares that marker against the audited contract.

`verify-greengrass.py config` resolves BitBake's real Greengrass environment and
rejects version/source drift, systemd builds switched off, omitted units or
missing dependencies. The image's postprocess hook runs the installed read-only
checker against the completed rootfs and verifies the actual package manifest.
It writes its report into `IMGDEPLOYDIR`, which participates in the image
sstate deployment. The build helper verifies that report, its machine and the
package manifest SHA256 before reporting success.

Missing `tesd`, `gg-fleet-statusd`, any other required executable/unit, user or
support file fails the build. The deployed report is
`nxp-lp-dev-image-MACHINE.greengrass.json`; WORKDIR retains
`validation/greengrass-config.json` and `validation/greengrass-image.json`.
This preserves the existing FRDM bootloader, DTB, MCU and pseudo/openat2 fixes.

Update the complete bundle in place and rerun the documented build command
with the same WORKDIR. Normal BitBake dependency tracking rebuilds the changed
packages/image; no blanket clean or new source checkout is required. Reflash
the resulting verified complete WIC, keeping provisioned credentials/config
backups available as described in the setup guide.

On the new board image, before provisioning:

```bash
python3 /usr/libexec/nxp-lp/check-greengrass.py
```

After installing credentials, the guide and provisioning helper add the entire
validated core unit set as wants of `greengrass-lite.target` and start that
target. This avoids an empty target appearing active while daemons remain off.

## External UTC synchronization

The pinned NXP base image installs ntpd, but the upstream OpenEmbedded ntp.conf
enables only `server 127.127.1.0` and `fudge ... stratum 14`. That LOCAL reference
can mark a wrong clock synchronized. The November 10 board diagnostic confirmed
S3 RequestTimeTooSkewed with the board approximately 6,391 seconds behind AWS;
its ntp.conf contained this exact local-clock-only configuration.

The layer now replaces that default with four external pool servers and iburst,
keeps ntpd enabled, and explicitly installs the separate ntpq package. The
completed-rootfs audit requires the configuration, binaries and ntpd unit and
rejects a LOCAL/orphan fallback or no external source. These static checks do
not establish live synchronization or server reachability. Greengrass startup
is not gated by this audit; check live UTC before provisioning or deployment.

For an existing board, run as root. This preserves the original configuration.
Use your organization's approved NTP servers instead of the public pool if
required. The network must permit DNS and NTP traffic (UDP port 123).

```sh
cp -an /etc/ntp.conf /etc/ntp.conf.before-external-ntp
cat > /etc/ntp.conf <<'EOF'
driftfile /var/lib/ntp/drift
server 0.pool.ntp.org iburst
server 1.pool.ntp.org iburst
server 2.pool.ntp.org iburst
server 3.pool.ntp.org iburst
restrict -4 default kod notrap nomodify nopeer noquery
restrict -6 default kod notrap nomodify nopeer noquery
restrict 127.0.0.1
restrict ::1
EOF
systemctl disable --now systemd-timesyncd.service
systemctl stop ntpd.service
if timeout 60 ntpd -gq -n -c /etc/ntp.conf; then
    systemctl enable --now ntpd.service
    date -u
else
    systemctl enable --now ntpd.service
    echo 'Time correction failed: check DNS, reachable NTP servers and UDP 123 before retrying AWS.'
fi
```

The pinned ntpd service already uses -g, which permits one initial large clock
correction. The one-shot -gq command performs that correction immediately when
an external server is reachable; it must finish successfully. A timeout is a
failure. Do not run it alongside a different clock-setting daemon. Leave
systemd-timesyncd disabled when using this image's ntpd.

On updated images, inspect `ntpq -pn` and `ntpq -c rv`: require a selected
external server (`*`), a nonzero reach register, a recent sample, a small offset
(the peer table uses milliseconds), and leap_none/stratum below 16. Allow a few
polls after restarting ntpd. Verify UTC against a trusted synchronized clock.
`timedatectl` saying yes/active, or an ntpd process running, is insufficient.
Older images may lack ntpq; the new image installs it explicitly. Once UTC is
correct, retry the Part 3 S3 diagnostic for HTTP 200/206 and retry the failed
deployment. A clock-only repair does not require another component version or
ELF. Write the RTC with `hwclock --systohc --utc` only after accurate UTC is
confirmed and if the board has a working retained RTC.

Pinned sources:
- https://github.com/nxp-imx/meta-imx/blob/1cfbbb8f9ce1d6071775ea6083b79d98597c8206/meta-imx-sdk/recipes-fsl/packagegroup/packagegroup-imx-core-tools.bb
- https://github.com/openembedded/meta-openembedded/blob/07330a98cf93806b7a4e0170a541b94962ff3960/meta-networking/recipes-support/ntp/ntp/ntp.conf
- https://github.com/openembedded/meta-openembedded/blob/07330a98cf93806b7a4e0170a541b94962ff3960/meta-networking/recipes-support/ntp/ntp_4.2.8p18.bb
- https://www.ntp.org/documentation/4.2.8-series/ntpd/

## Validation limits and sources

Authoring checks use the exact upstream unit templates and recipe, synthetic
executables/rootfs fixtures, the real image-audit Python hook, and simulated
BitBake build flows. They check both complete images and intentionally missing
units/binaries, failed metadata selection, activation and manifest mismatch.
These are host checks, not a full Yocto image compilation or AWS/board test.
A build on the documented Ubuntu host runs the actual metadata/rootfs audits.

- [Pinned meta-aws recipe](https://github.com/aws4embeddedlinux/meta-aws/blob/5d73130967dce143f44fe2f80d65361f6b653c5e/recipes-iot/aws-iot-greengrass/greengrass-lite_2.3.0.bb)
- [Pinned runtime install logic](https://github.com/aws-greengrass/aws-greengrass-lite/blob/584b9dadc5446e400f53ffa7d1b2c15dcc6b9e4f/CMakeLists.txt)
- [Token exchange unit](https://github.com/aws-greengrass/aws-greengrass-lite/blob/584b9dadc5446e400f53ffa7d1b2c15dcc6b9e4f/modules/tesd/unit/ggl.core.tesd.service.in)
- [Pinned OpenEmbedded image task](https://github.com/yoctoproject/poky/blob/d0b46a6624ec9c61c47270745dd0b2d5abbe6ac1/meta/classes-recipe/image.bbclass)
