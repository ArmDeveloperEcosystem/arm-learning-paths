FILESEXTRAPATHS:prepend := "${THISDIR}/files:"
SRC_URI:append = " file://0001-lp-mcore.patch file://nxp-lp.cfg"
# NXP replaces .config in do_copy_defconfig, so merge in its later delta task.
DELTA_KERNEL_DEFCONFIG:append = " nxp-lp.cfg"
do_configure:append() {
    for setting in $(sed -n '/^CONFIG_/p' ${UNPACKDIR}/nxp-lp.cfg); do
        grep -qx "$setting" ${B}/.config || bbfatal "Missing MCU setting: $setting"
    done
}
