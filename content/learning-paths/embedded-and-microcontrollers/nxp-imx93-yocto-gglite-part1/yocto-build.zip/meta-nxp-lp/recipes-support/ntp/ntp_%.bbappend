FILESEXTRAPATHS:prepend := "${THISDIR}/files:"

# The upstream default synchronizes only to LOCAL(0). AWS requests need real UTC.
SRC_URI:append = " file://nxp-lp-ntp.conf"
SYSTEMD_AUTO_ENABLE:${PN} = "enable"

do_install:append() {
    install -m 0644 ${UNPACKDIR}/nxp-lp-ntp.conf ${D}${sysconfdir}/ntp.conf
}
