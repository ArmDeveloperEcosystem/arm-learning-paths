FILESEXTRAPATHS:prepend := "${THISDIR}/files:"
SRC_URI:append:imx93-11x11-lpddr4x-frdm = " file://0001-frdm-linux-mcore-boot-policy.patch"
