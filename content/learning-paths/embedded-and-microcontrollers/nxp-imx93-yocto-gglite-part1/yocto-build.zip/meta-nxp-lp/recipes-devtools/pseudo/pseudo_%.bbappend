# Host tar security updates use openat2, which the pinned pseudo did not track.
# Keep the BSP source revision; backport the upstream compatibility fixes.
FILESEXTRAPATHS:prepend := "${THISDIR}/files:"
SRC_URI:append = " \
    file://0001-pseudo-avoid-openat2-syscall.patch \
    file://0002-pseudo-ensure-SYS_openat2.patch \
"
