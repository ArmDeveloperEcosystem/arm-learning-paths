SUMMARY = "Complete Greengrass Lite runtime for the NXP learning paths"
LICENSE = "MIT"
PACKAGE_ARCH = "${MACHINE_ARCH}"
inherit packagegroup
RDEPENDS:${PN} = "greengrass-lite libcgroup sudo ca-certificates ntp ntpq"
