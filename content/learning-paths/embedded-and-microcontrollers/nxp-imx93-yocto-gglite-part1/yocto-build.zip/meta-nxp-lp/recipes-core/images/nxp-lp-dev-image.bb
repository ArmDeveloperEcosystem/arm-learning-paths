require recipes-fsl/images/imx-image-core.bb
SUMMARY = "NXP learning-path development image"
IMAGE_BASENAME = "nxp-lp-dev-image"
IMAGE_INSTALL:append = " packagegroup-nxp-lp-greengrass nxp-lp-tools python3 python3-modules python3-pip python3-setuptools ca-certificates openssl openssl-bin curl unzip util-linux coreutils libgpiod-tools i2c-tools kernel-modules kernel-devicetree"
IMAGE_ROOTFS_EXTRA_SPACE = "1048576"

# Audit the actual completed rootfs and package manifest before image deployment.
# IMGDEPLOYDIR is part of do_image_complete sstate, so the report follows the WIC.
IMAGE_POSTPROCESS_COMMAND:append = " nxp_lp_audit_greengrass; "
python nxp_lp_audit_greengrass() {
    import hashlib
    import json
    from pathlib import Path
    import runpy

    rootfs = Path(d.getVar('IMAGE_ROOTFS'))
    checker = rootfs / 'usr/libexec/nxp-lp/check-greengrass.py'
    try:
        audit = runpy.run_path(str(checker))
        contract = audit['load_contract'](rootfs)
        report = audit['check_rootfs'](rootfs, contract)
        manifest = Path(d.getVar('IMAGE_MANIFEST'))
        report['packages'] = audit['check_packages'](manifest, contract)
        report['machine'] = d.getVar('MACHINE')
        report['image_name'] = d.getVar('IMAGE_NAME')
        report['manifest_file'] = manifest.name
        report['manifest_sha256'] = hashlib.sha256(manifest.read_bytes()).hexdigest()
        output = Path(d.getVar('IMGDEPLOYDIR')) / ('nxp-lp-dev-image-' + d.getVar('MACHINE') + '.greengrass.json')
        output.write_text(json.dumps(report, indent=2) + '\n')
    except (OSError, ValueError, KeyError) as error:
        bb.fatal('Greengrass Lite image is incomplete: ' + str(error))
}
