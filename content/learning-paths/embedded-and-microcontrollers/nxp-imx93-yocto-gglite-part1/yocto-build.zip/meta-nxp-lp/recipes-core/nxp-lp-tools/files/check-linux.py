#!/usr/bin/env python3
"""Read-only FRDM application-MCU preflight; run on the Linux board as root."""
import struct
import sys
from pathlib import Path

BOARD_COMPATIBLE = 'fsl,frdm-imx93'
CORE_COMPATIBLE = 'fsl,imx93-cm33'
BOOT_ARGUMENTS = ['clk-imx93.mcore_booted']
REGIONS = [('vdev0buffer', 2751594496, 1048576), ('vdev0vring0', 2751463424, 32768), ('vdev0vring1', 2751496192, 32768), ('rsc-table', 2751528960, 4096)]
RELEASED_NODES = ['serial@44390000', 'i2c@42540000', 'gpio@43810000', 'spi@42550000']


def strings(path):
    return path.read_bytes().rstrip(b"\0").decode().split("\0") if path.exists() else []


def cells(path):
    data = path.read_bytes()
    return struct.unpack(f">{len(data) // 4}I", data)


def enabled(node):
    return not (node / "status").exists() or strings(node / "status") in (["okay"], ["ok"])


def check():
    root = Path("/sys/firmware/devicetree/base")
    assert BOARD_COMPATIBLE in strings(root / "compatible"), "running Linux DT is not this FRDM board"
    cmdline = Path("/proc/cmdline").read_text().split()
    for argument in BOOT_ARGUMENTS:
        assert any(p in cmdline for p in (argument, argument + "=1")), (
            f"missing {argument} in running Linux command line; check the FRDM prepare_mcore/BSP boot path")
        print(f"PASS: Linux received {argument}")
    cores = [p.parent for p in root.rglob("compatible")
             if CORE_COMPATIBLE in strings(p) and enabled(p.parent)]
    assert len(cores) == 1, "need exactly one enabled matching application-MCU remoteproc node"
    core = cores[0]
    assert not (core / "fsl,auto-boot").exists(), "MCU auto-boot must be disabled"
    phandles = {cells(p)[0]: p.parent for p in root.rglob("phandle")}
    regions = [phandles[h] for h in cells(core / "memory-region")]
    assert len(regions) == len(REGIONS), "expected the learning path's four memory-region entries"
    for region, (name, address, size) in zip(regions, REGIONS):
        assert region.name.split("@")[0] == name, f"unexpected carveout {region.name}; rebuild corrected Part 1 DTB"
        assert cells(region / "reg") == (0, address, 0, size), (
            "resource table must use shared DDR at 0xa4010000; rebuild/flash the matching Part 1 image"
            if name=="rsc-table" else f"incorrect range: {region.name}")
        assert (region / "no-map").exists(), f"missing no-map: {region.name}"
        print(f"PASS: {region.name} size={size:#x}")
    # The former second-vdev rings must not overlap the relocated table.
    table_node=regions[-1]
    table_start,table_size=REGIONS[-1][1:]
    for node in table_node.parent.iterdir():
        if not node.is_dir() or node==table_node or not enabled(node) or not (node/"reg").exists():
            continue
        values=cells(node/"reg")
        assert len(values)%4==0, f"unsupported reserved-memory range: {node.name}"
        for index in range(0,len(values),4):
            high,low,size_high,size_low=values[index:index+4]
            start=(high<<32)|low;size=(size_high<<32)|size_low
            assert not (start<table_start+table_size and table_start<start+size), f"resource table overlaps {node.name}; install the matched DDR-table DTB"
    print("PASS: shared-DDR resource table has no overlapping reservations")
    for name in RELEASED_NODES:
        nodes = list(root.rglob(name))
        assert nodes and all(not enabled(p) for p in nodes), f"Linux must release {name} to the application MCU"
    if CORE_COMPATIBLE == "fsl,imx93-cm33":
        assert not (root / "ethosu").exists() or not enabled(root / "ethosu"), "ethosu must not own M33"
    if CORE_COMPATIBLE == "fsl,imx95-cm7":
        assert cells(core / "fsl,cpu-id") == (1,), "wrong application CPU; never target System Manager M33"
        assert cells(core / "fsl,lmm-id") == (1,), "M7 logical-machine ID must match mx95frdmlp System Manager policy"
    processors = [p for p in Path("/sys/class/remoteproc").glob("remoteproc*")
                  if (p / "device/of_node").resolve() == core.resolve()]
    assert len(processors) == 1, "application-MCU remoteproc driver is missing or ambiguous"
    state = (processors[0] / "state").read_text().strip()
    assert state == "offline", f"application MCU must be offline, found {state}"
    print(f"PASS: FRDM Linux DT, boot arguments and {processors[0].name} preflight passed.")
    print("Verify FRDM U-Boot control-tree identity and the Part 1 boot-image report separately.")
    print("This checks configuration; it does not qualify TCM access, firmware execution or stop/restart.")


if __name__ == "__main__":
    try:
        check()
    except (AssertionError, OSError, KeyError, ValueError, struct.error) as error:
        sys.exit(f"FAIL: {error}")
