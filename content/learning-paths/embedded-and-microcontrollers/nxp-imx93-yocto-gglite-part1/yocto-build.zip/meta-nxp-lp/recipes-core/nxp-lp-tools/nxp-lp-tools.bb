SUMMARY = "Application MCU lifecycle and RPMsg device aliases"
LICENSE = "CLOSED"
SRC_URI = "file://nxp-provision-greengrass file://check-greengrass.py file://greengrass-runtime.json file://board.json file://nxp-mcore file://firmware_manager.py file://check-linux.py file://80-nxp-lp-rpmsg.rules"
S = "${UNPACKDIR}"
RDEPENDS:${PN} = "python3-core python3-modules systemd"
do_install() {
    install -d ${D}${sysconfdir}/nxp-lp ${D}${bindir} ${D}${libexecdir}/nxp-lp ${D}${sysconfdir}/udev/rules.d
    install -m 0644 ${UNPACKDIR}/board.json ${D}${sysconfdir}/nxp-lp/
    install -m 0755 ${UNPACKDIR}/nxp-mcore ${UNPACKDIR}/nxp-provision-greengrass ${D}${bindir}/
    install -m 0644 ${UNPACKDIR}/check-greengrass.py ${D}${libexecdir}/nxp-lp/
    install -d ${D}${datadir}/nxp-lp
    install -m 0644 ${UNPACKDIR}/greengrass-runtime.json ${D}${datadir}/nxp-lp/
    install -m 0644 ${UNPACKDIR}/firmware_manager.py ${UNPACKDIR}/check-linux.py ${D}${libexecdir}/nxp-lp/
    install -m 0644 ${UNPACKDIR}/80-nxp-lp-rpmsg.rules ${D}${sysconfdir}/udev/rules.d/
}
FILES:${PN} += "${libexecdir}/nxp-lp ${sysconfdir}/udev/rules.d"

FILES:${PN} += "${datadir}/nxp-lp"
