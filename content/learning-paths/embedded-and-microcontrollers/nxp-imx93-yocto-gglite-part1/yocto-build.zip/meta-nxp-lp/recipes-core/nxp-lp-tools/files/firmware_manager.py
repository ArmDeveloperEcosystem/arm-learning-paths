#!/usr/bin/env python3
"""Foreground remoteproc owner with a separate RPMsg quiescence endpoint."""
import argparse, fcntl, hashlib, json, os, select, shutil, signal, struct, subprocess, sys, tempfile, termios, threading, time, uuid
from pathlib import Path
PROFILE=Path('/etc/nxp-lp/board.json')
BOOT_ID_FILE=Path('/proc/sys/kernel/random/boot_id')
def boot_id():
    return str(uuid.UUID(BOOT_ID_FILE.read_text().strip()))
def profile():
    return json.loads(PROFILE.read_text())
def preflight():
    if profile().get('id')!='nxp-imx93':raise RuntimeError('Firmware manager requires the FRDM-IMX93 profile')
    here=Path(__file__).resolve()
    candidates=(here.with_name('check-linux.py'),here.parent.parent/'check-linux.py')
    helper=next((p for p in candidates if p.is_file()),None)
    if helper is None:raise RuntimeError('FRDM preflight helper is missing; install the updated Part 1 tools')
    subprocess.run([sys.executable,str(helper)],check=True)
def find_mcore(root=Path('/sys/class/remoteproc')):
    expected=profile()['compatible'].encode()
    matches=[]
    for p in root.glob('remoteproc*'):
        node=p/'device/of_node/compatible'
        if node.exists() and expected in node.read_bytes().split(b'\0'): matches.append(p)
    if len(matches)!=1: raise RuntimeError(f'Expected one {expected!r} application core; found {matches}')
    return matches[0]
def validate_elf(path):
    data=path.read_bytes()
    if len(data)<20 or data[:6]!=b'\x7fELF\x01\x01' or struct.unpack_from('<H',data,18)[0]!=40:
        raise ValueError('Expected an unstripped little-endian 32-bit Arm ELF')
    vector_base={'nxp-imx93':0x0ffe0000,'nxp-imx95':0}.get(profile().get('id'))
    if vector_base is None:return
    # These NXP drivers use .interrupts, not e_entry, as the reset-vector base.
    def unpack(fmt,offset):
        if offset<0 or offset+struct.calcsize(fmt)>len(data):raise ValueError('Truncated ELF metadata')
        return struct.unpack_from(fmt,data,offset)
    header=unpack('<16sHHIIIIIHHHHHH',0)
    _,kind,_,_,_,phoff,shoff,_,ehsize,phsize,phnum,shsize,shnum,shstr=header
    if kind!=2 or ehsize!=52 or phsize!=32 or not phnum or shsize!=40 or not 0<shstr<shnum:
        raise ValueError('Expected ELF32 executable headers and section names')
    def section(index):return unpack('<10I',shoff+index*shsize)
    def contents(offset,size):
        if offset<0 or offset+size>len(data):raise ValueError('Truncated ELF section')
        return data[offset:offset+size]
    names=section(shstr);names=contents(names[4],names[5])
    matches=[]
    for index in range(shnum):
        item=section(index)
        if item[0]>=len(names):raise ValueError('Invalid ELF section name')
        if names[item[0]:].split(b'\0',1)[0]==b'.interrupts':matches.append(item)
    if len(matches)!=1:raise ValueError('Missing .interrupts reset-vector section; rebuild with the updated build-zephyr.sh')
    _,kind,flags,address,offset,size,_,_,_,_=matches[0]
    tcm_size=0x20000 if vector_base else 0x40000
    if kind!=1 or not flags&2 or address!=vector_base or not 8<=size<=tcm_size:
        raise ValueError('Invalid .interrupts reset-vector section')
    vectors=contents(offset,size)
    loads=[unpack('<8I',phoff+i*phsize) for i in range(phnum)]
    if profile().get('id')=='nxp-imx93' and not any(p[0]==1 and b'NXP-IMX93-RSC-DDR:a4010000' in contents(p[1],p[4]) for p in loads):
        raise ValueError('ELF lacks the i.MX93 shared-DDR resource-table contract; rebuild from the updated Part 2/3 bundle')
    if not any(p[0]==1 and p[1]==offset and p[3]==address and size<=p[4]<=p[5] for p in loads):
        raise ValueError('.interrupts must describe loaded reset vectors')
    sp,reset=struct.unpack_from('<II',vectors)
    stack_end=0x2001e000 if vector_base else 0x20040000
    if not (0x20000000<sp<=stack_end and sp%8==0 and reset&1 and vector_base<=reset&~1<vector_base+tcm_size):
        raise ValueError('Invalid initial stack or Thumb reset vector')
def stage(artifact,work):
    validate_elf(artifact); d=work/'installed';d.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(artifact,d/'zephyr.elf');return d/'zephyr.elf'
def recover_locked(core,work):
    """Archive recorded files only while the caller holds mcore.lock."""
    if (core/'state').read_text().strip()!='offline':
        raise RuntimeError('Recovery requires an offline application MCU')
    owner_file=work/'owner.json'
    if not owner_file.exists():return None
    if owner_file.is_symlink():raise RuntimeError('Refusing a symlinked owner record')
    record=json.loads(owner_file.read_text())
    digest=record.get('sha256','')
    if not isinstance(digest,str) or len(digest)!=64 or any(c not in '0123456789abcdef' for c in digest):
        raise RuntimeError('Invalid firmware digest in owner record; preserve files for inspection')
    name=profile()['id']+'-gg-'+digest[:16]+'.elf'
    if record.get('core')!=str(core) or record.get('firmware')!=name:
        raise RuntimeError('Owner record does not match this core and firmware profile')
    firmware=Path('/lib/firmware')/name
    if firmware.is_symlink():raise RuntimeError('Refusing a symlinked firmware file')
    if firmware.exists() and (not firmware.is_file() or hashlib.sha256(firmware.read_bytes()).hexdigest()!=digest):
        raise RuntimeError('Recorded firmware has changed; preserve files for inspection')
    restore=(core/'firmware').read_text().strip()==name
    previous=record.get('previous','')
    if restore and (not isinstance(previous,str) or not previous or any(c in previous for c in '\x00\r\n')):
        raise RuntimeError('Invalid previous firmware selection in owner record')
    recovery=work/'recovery';recovery.mkdir(mode=0o700,exist_ok=True)
    archive=recovery/os.path.basename(tempfile.mkdtemp(prefix='owner-',dir=recovery))
    if firmware.exists():firmware.rename(archive/name)
    installed=work/'installed'
    if installed.exists() or installed.is_symlink():installed.rename(archive/'installed')
    if restore:(core/'firmware').write_text(previous)
    owner_file.rename(archive/'owner.json')
    print(f'MCore: archived stale ownership and owned files in {archive}',flush=True)
    return archive
def recover(work):
    work.mkdir(parents=True,exist_ok=True)
    with (work/'mcore.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        result=recover_locked(find_mcore(),work)
        if result is None:print('MCore: no stale owner record',flush=True)
        return result
def exchange(command,expected,timeout=8):
    deadline=time.monotonic()+timeout
    port=Path('/dev/nxp-mcore-control')
    while not port.exists():
        if time.monotonic()>deadline:raise TimeoutError('RPMsg control endpoint did not appear')
        time.sleep(.1)
    fd=os.open(port,os.O_RDWR|os.O_NOCTTY|os.O_NONBLOCK)
    try:
        fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
        attrs=termios.tcgetattr(fd);attrs[0]=0;attrs[1]=0;attrs[3]=0
        termios.tcsetattr(fd,termios.TCSANOW,attrs);termios.tcflush(fd,termios.TCIFLUSH)
        os.write(fd,command+b'\n');received=b''
        while time.monotonic()<deadline:
            if select.select([fd],[],[],.1)[0]:
                received+=os.read(fd,1024)
                if expected in received.splitlines():return
                if len(received)>4096:raise RuntimeError('Invalid control response')
        raise TimeoutError(f'No {expected!r} acknowledgment')
    finally:os.close(fd)
def run(artifact,work):
    preflight()
    stopping=threading.Event()
    for sig in (signal.SIGTERM,signal.SIGINT):signal.signal(sig,lambda *_:stopping.set())
    work.mkdir(parents=True,exist_ok=True)
    with (work/'mcore.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        core=find_mcore();state=lambda:(core/'state').read_text().strip()
        owner_file=work/'owner.json'
        if state()!='offline':raise RuntimeError('Application MCU must be offline')
        current_boot=boot_id()
        if owner_file.exists():
            record=json.loads(owner_file.read_text())
            try:previous_boot=str(uuid.UUID(record.get('boot_id','')))
            except (ValueError,TypeError,AttributeError):previous_boot=None
            if previous_boot is None or previous_boot==current_boot:
                raise RuntimeError('Stale owner record: with the MCU offline, run firmware_manager.py recover --work '+str(work))
            recover_locked(core,work)
        elf=stage(artifact,work);digest=hashlib.sha256(elf.read_bytes()).hexdigest()
        name=profile()['id']+'-gg-'+digest[:16]+'.elf';dest=Path('/lib/firmware')/name
        previous=(core/'firmware').read_text().strip();copied=False;selected=False;started=False
        owner_file.write_text(json.dumps({'core':str(core),'firmware':name,'previous':previous,'sha256':digest,'boot_id':current_boot})+'\n')
        failure=None
        try:
            print(f'MCore: installing firmware={name}',flush=True)
            with dest.open('xb') as output,elf.open('rb') as source:
                copied=True;shutil.copyfileobj(source,output)
            os.chmod(dest,0o644);(core/'firmware').write_text(name);selected=True
            print('MCore: entering Linux remoteproc start (ELF load and application MCU release)',flush=True)
            started=True;(core/'state').write_text('start')
            print('MCore: Linux remoteproc start returned',flush=True)
            if state()!='running':raise RuntimeError('Application MCU did not start')
            exchange(b'HELLO',b'READY')
            print(f'MCore started firmware={name} sha256={digest}',flush=True)
            while not stopping.wait(1):
                if state()!='running':raise RuntimeError('Unexpected MCU state')
        except BaseException as error:
            failure=error
            raise
        finally:
            try:
                if started and state()=='running':
                    if (core/'firmware').read_text().strip()!=name:raise RuntimeError('MCU ownership changed')
                    exchange(b'STOP',b'QUIESCED')
                    time.sleep(.05)
                    (core/'state').write_text('stop')
                if state()!='offline':raise RuntimeError('MCU not offline; preserve owner record')
                if selected:(core/'firmware').write_text(previous)
                if copied:dest.unlink(missing_ok=True)
                shutil.rmtree(work/'installed',ignore_errors=True);owner_file.unlink()
                print('MCore offline; firmware selection restored; installed files removed',flush=True)
            except Exception as cleanup_error:
                if failure is None:raise
                print(f'MCore: cleanup failed: {cleanup_error}; retaining remaining ownership and firmware files.',file=sys.stderr,flush=True)
                print('MCore: if the MCU remains running, power-cycle the board before retrying.',file=sys.stderr,flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('phase',choices=['install','run','recover']);p.add_argument('--artifact',type=Path);p.add_argument('--work',type=Path,required=True)
    a=p.parse_args();a.work.mkdir(parents=True,exist_ok=True)
    if a.phase!='recover' and a.artifact is None:p.error('--artifact is required for install/run')
    if a.phase=='recover':recover(a.work)
    elif a.phase=='install':stage(a.artifact,a.work)
    else:run(a.artifact,a.work)
