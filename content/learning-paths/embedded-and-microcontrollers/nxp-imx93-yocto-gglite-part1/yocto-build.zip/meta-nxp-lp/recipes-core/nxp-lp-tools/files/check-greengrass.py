#!/usr/bin/env python3
"""Read-only audit of the pinned Greengrass Lite runtime, on target or in a rootfs."""
import argparse
import ipaddress
import json
import os
from pathlib import Path, PurePosixPath
import shlex
import sys

CONTRACT = '/usr/share/nxp-lp/greengrass-runtime.json'
UNIT_DIRS = ('/etc/systemd/system', '/usr/lib/systemd/system', '/lib/systemd/system')


def in_root(root, name):
    """Resolve target symlinks inside root, including absolute /usr links."""
    pending = list(PurePosixPath('/' + str(name).lstrip('/')).parts[1:])
    parts = []
    links = 0
    while pending:
        item = pending.pop(0)
        if item in ('', '.'):
            continue
        if item == '..':
            if parts:
                parts.pop()
            continue
        candidate = root.joinpath(*parts, item)
        if candidate.is_symlink():
            links += 1
            if links > 40:
                raise ValueError('Symlink loop: ' + name)
            target = os.readlink(candidate)
            if target.startswith('/'):
                parts = []
            pending = list(PurePosixPath(target).parts) + pending
            if pending and pending[0] == '/':
                pending.pop(0)
        else:
            parts.append(item)
    return root.joinpath(*parts)


def load_contract(root=Path('/'), path=None):
    return json.loads((Path(path) if path else in_root(root, CONTRACT)).read_text())


def check_time_configuration(root, settings):
    """Audit installed prerequisites; this does not test live synchronization."""
    for filename in settings['executables']:
        path = in_root(root, filename)
        if not path.is_file() or not path.stat().st_mode & 0o111:
            raise ValueError('Missing time-sync executable: ' + filename)
    unit = settings['unit']
    if not any(in_root(root, folder + '/' + unit).is_file() for folder in UNIT_DIRS):
        raise ValueError('Missing time-sync unit: ' + unit)
    sources = []
    for line in in_root(root, settings['configuration']).read_text().splitlines():
        fields = shlex.split(line, comments=True)
        if not fields:
            continue
        if fields[0] in ('includefile', 'confdir', 'refclock', 'fudge') or (
                fields[0] == 'tos' and any(x.startswith('orphan') for x in fields[1:])):
            raise ValueError('NTP configuration must use explicit external servers without LOCAL/orphan fallback')
        if fields[0] not in ('server', 'pool', 'peer'):
            continue
        if len(fields) < 2:
            raise ValueError('Missing NTP server address')
        source = fields[1].lower().rstrip('.')
        local = source in ('localhost', 'localhost.localdomain')
        try:
            address = ipaddress.ip_address(source)
            local |= address.is_loopback or address.is_unspecified
        except ValueError:
            pass
        if local:
            raise ValueError('NTP source trusts the local clock: ' + source)
        sources.append(source)
    if not sources:
        raise ValueError('NTP configuration has no external time source')
    return {'configuration': settings['configuration'], 'unit': unit, 'sources': sources,
            'scope': 'Installed configuration only; verify a selected reachable server and UTC on the board.'}


def check_rootfs(root=Path('/'), contract=None):
    root = Path(root).resolve()
    contract = contract or load_contract(root)
    failures = []
    binaries = {}
    for name in contract['executables']:
        filename = '/usr/bin/' + name
        path = in_root(root, filename)
        if not path.is_file() or not path.stat().st_mode & 0o111:
            failures.append('missing executable: ' + filename)
        else:
            binaries[name] = filename
    units = {}
    for name in contract['units']:
        path = None
        for directory in UNIT_DIRS:
            candidate = root / directory.lstrip('/') / name
            if candidate.exists() or candidate.is_symlink():
                path = in_root(root, directory + '/' + name)
                break
        if path is None or not path.is_file():
            failures.append('missing or masked systemd unit: ' + name)
            continue
        text = path.read_text()
        if '@CMAKE_' in text or '@GGL_' in text:
            failures.append('unconfigured systemd template: ' + name)
        expected = contract['unit_executables'].get(name)
        if expected:
            commands = [line.split('=', 1)[1] for line in text.splitlines()
                        if line.startswith('ExecStart=') and line.split('=', 1)[1]]
            if not commands or shlex.split(commands[-1])[0] != '/usr/bin/' + expected:
                failures.append('unexpected ExecStart in ' + name)
        units[name] = '/' + str(path.relative_to(root))
    for filename in contract['support_files']:
        if not in_root(root, filename).is_file():
            failures.append('missing runtime support file: ' + filename)
    version_file = in_root(root, '/usr/share/nxp-lp/greengrass-version.json')
    if version_file.is_file():
        actual = json.loads(version_file.read_text())
        for key in ('version', 'source_revision'):
            if actual.get(key) != contract[key]:
                failures.append('installed Greengrass package has a different ' + key)
    for filename, required in [('/etc/passwd', contract['users']), ('/etc/group', contract['groups'])]:
        path = in_root(root, filename)
        found = {line.split(':', 1)[0] for line in path.read_text().splitlines()} if path.is_file() else set()
        failures += [f'missing {filename} entry: {name}' for name in required if name not in found]
    time_sync = None
    try:
        time_sync = check_time_configuration(root, contract['time_sync'])
    except (OSError, ValueError) as error:
        failures.append(str(error))
    if failures:
        raise ValueError('Greengrass Lite runtime is incomplete:\n  ' + '\n  '.join(failures))
    return {'schema': 1, 'result': 'pass', 'recipe': contract['recipe'],
            'version': contract['version'], 'source_revision': contract['source_revision'],
            'executables': binaries, 'units': units, 'support_files': contract['support_files'],
            'users': contract['users'], 'groups': contract['groups'], 'time_sync': time_sync}


def check_packages(manifest, contract):
    installed = {line.split()[0] for line in Path(manifest).read_text().splitlines() if line.strip()}
    missing = set(contract['packages']) - installed
    if missing:
        raise ValueError('Image manifest is missing required packages: ' + ', '.join(sorted(missing)))
    return sorted(set(contract['packages']) & installed)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path('/'))
    parser.add_argument('--contract', type=Path)
    parser.add_argument('--json', action='store_true')
    parser.add_argument('--units', action='store_true', help='Print validated service/socket names for target activation')
    args = parser.parse_args()
    try:
        contract = load_contract(args.root.resolve(), args.contract)
        report = check_rootfs(args.root, contract)
        if args.units:
            print('\n'.join(name for name in report['units'] if name != 'greengrass-lite.target'))
        elif args.json:
            print(json.dumps(report, indent=2))
        else:
            print(f"PASS: Greengrass Lite {report['version']}: {len(report['executables'])} executables, "
                  f"{len(report['units'])} units, runtime support files and users present.")
            print('Token exchange: ggl.core.tesd.service; fleet status: ggl.core.gg-fleet-statusd.service')
            print('NTP configuration uses external servers; verify live sync with ntpq -pn before AWS requests.')
    except (OSError, ValueError, KeyError) as error:
        sys.exit(str(error))


if __name__ == '__main__':
    main()
