# The pinned recipe builds all runtime modules in one package.
# Require unit installation even if an inherited CMake setting disabled it.
EXTRA_OECMAKE:append = " -DGGL_SYSTEMD_SERVICE_BUILD=ON"
RDEPENDS:${PN}:append = " libcgroup sudo ca-certificates"
SYSTEMD_AUTO_ENABLE = "disable"
FILES:${PN}:append = " ${datadir}/nxp-lp/greengrass-version.json"
do_install:append() {
    sed -i 's/ggcore:ggcore/gg_component:gg_component/g' ${D}${sysconfdir}/greengrass/config.d/greengrass-lite.yaml
    install -d ${D}${datadir}/nxp-lp
    printf '{"version":"%s","source_revision":"%s"}\n' '${PV}' '${SRCREV_ggl}' > ${D}${datadir}/nxp-lp/greengrass-version.json
}
