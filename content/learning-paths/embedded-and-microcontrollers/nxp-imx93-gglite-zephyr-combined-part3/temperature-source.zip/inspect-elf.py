#!/usr/bin/env python3
"""Reject incompatible remoteproc artifacts before copying them to the board."""
import argparse
import struct
import sys
from pathlib import Path

from elftools.elf.elffile import ELFFile


def require(condition, message):
    if not condition:
        raise ValueError(message)


def in_tcm(address, size):
    return any(base <= address and address + size <= base + (0x1e000 if base == 0x20000000 else 0x20000)
               for base in (0x0ffe0000, 0x20000000))


def inspect(path, require_temperature=False):
    with path.open("rb") as stream:
        elf = ELFFile(stream)
        require(elf.elfclass == 32 and elf.little_endian and
                elf["e_machine"] == "EM_ARM", "expected ELF32 little-endian ARM")
        require(elf["e_type"] == "ET_EXEC", "expected an executable ELF")
        require(in_tcm(elf["e_entry"] & ~1, 2), "entry point is outside TCM")
        loads = [s for s in elf.iter_segments() if s["p_type"] == "PT_LOAD" and s["p_memsz"]]
        require(loads, "no loadable segments")
        for segment in loads:
            address, size = segment["p_paddr"], segment["p_memsz"]
            require(segment["p_filesz"] <= size, "invalid segment sizes")
            require(in_tcm(address, size), f"PT_LOAD outside TCM: {address:#x}+{size:#x}")
            print(f"PT_LOAD da={address:#010x} filesz={segment['p_filesz']:#x} memsz={size:#x}")
        vectors = next((s for s in loads if s["p_paddr"] == 0x0ffe0000 and s["p_filesz"] >= 8), None)
        require(vectors is not None, "missing reset vectors at FRDM M33 ITCM base")
        interrupts = elf.get_section_by_name(".interrupts")
        require(interrupts is not None,
                "missing .interrupts reset-vector section; rebuild with build-zephyr.sh")
        require(interrupts["sh_type"] == "SHT_PROGBITS" and interrupts["sh_flags"] & 2 and
                interrupts["sh_addr"] == 0x0ffe0000 and 8 <= interrupts["sh_size"] <= vectors["p_filesz"],
                "invalid .interrupts reset-vector section")
        require(interrupts["sh_offset"] == vectors["p_offset"] and
                interrupts.data() == vectors.data()[:interrupts["sh_size"]],
                ".interrupts must describe the loaded reset vectors")
        sp, reset = struct.unpack_from("<II", vectors.data())
        require(0x20000000 < sp <= 0x2001e000 and sp % 8 == 0, "invalid DTCM initial stack")
        require(reset & 1 and in_tcm(reset & ~1, 2), "invalid Thumb reset vector")
        table = elf.get_section_by_name(".resource_table")
        require(table is not None and in_tcm(table["sh_addr"], table["sh_size"]),
                "missing TCM resource table")
        data = table.data()
        require(len(data) >= 20, "truncated resource table")
        require(struct.unpack_from("<4I", data) == (1, 1, 0, 0), "unexpected resource-table header")
        offset, = struct.unpack_from("<I", data, 16)
        require(offset >= 20 and offset + 68 <= len(data), "truncated RPMsg resource")
        require(struct.unpack_from("<2I", data, offset) == (3, 7), "expected RPMsg virtio device")
        require(data[offset + 25] == 2, "expected two vrings")
        for index in range(2):
            da, align, count, _, reserved = struct.unpack_from("<5I", data, offset + 28 + 20 * index)
            require(da == 0xffffffff and align == 16 and count == 8 and reserved == 0,
                    "expected host-allocated eight-entry vrings aligned to 16 bytes")
        symbols = elf.get_section_by_name(".symtab")
        require(symbols is not None, "retain the unstripped ELF for inspection")
        expected_board = b"NXP FRDM i.MX 93\0"
        allocated = [s for s in elf.iter_sections()
                     if s["sh_type"] == "SHT_PROGBITS" and s["sh_flags"] & 2]
        require(any(expected_board in s.data() for s in allocated),
                "ELF does not identify this FRDM application; select the correct board source bundle")
        require(any(b"NXP-IMX93-RSC-DDR:a4010000" in s.data() for s in allocated),
                "ELF predates the shared-DDR resource-table fix; rebuild with the updated bundle")
        if require_temperature:
            require(symbols.get_symbol_by_name("lp_sensor_sample"),
                    "Part 3 requires the temperature application; run bash build-zephyr.sh temperature")
            for marker in (b"BMP280 probe v4: software I2C GPIO2",
                           b"BMP280 GPIO2 clock:", b"BMP280 GPIO2 identity:"):
                require(any(marker in s.data() for s in allocated),
                        "temperature ELF predates the GPIO2 clock/input fixes; rebuild from the updated Part 3 bundle")
            print("PASS: Part 3 temperature application includes the v4 GPIO2 clock/input setup.")
        print(f"Vectors SP={sp:#010x} reset={reset:#010x}; ELF table template={table['sh_addr']:#x}; runtime table DDR=0xa4010000")
        print("PASS: FRDM i.MX93 TCM ELF and shared-DDR table contract; board execution still requires verification.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--require-temperature", action="store_true",
                        help="require the current Part 3 BMP280 application and GPIO2 fixes")
    parser.add_argument("elf", type=Path)
    args = parser.parse_args()
    try:
        inspect(args.elf, require_temperature=args.require_temperature)
    except (ValueError, OSError, struct.error) as error:
        sys.exit(f"FAIL: {error}")
