#!/usr/bin/env python3
"""Exercise the real software-I2C path with GPIO wires and queued slave bits."""
from pathlib import Path
import shutil
import subprocess
import tempfile

HERE=Path(__file__).resolve().parent
compiler=shutil.which('cc')
if not compiler:raise SystemExit('A host C compiler is required')
with tempfile.TemporaryDirectory(prefix='imx93-soft-i2c-') as directory:
    root=Path(directory)
    (root/'test-platform.h').write_text('''#ifndef TEST_PLATFORM_H
#define TEST_PLATFORM_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#define CONFIG_LP_SOFT_I2C 1
#define BIT(n) (1U << (n))
#define GPIO_INPUT BIT(0)
#define GPIO_OUTPUT_LOW BIT(1)
#define GPIO_PULL_UP BIT(2)
#define GPIO_OUTPUT_HIGH BIT(3)
struct device { const char *name; };
extern struct device test_gpio;
#define DT_NODELABEL(name) 0
#define DEVICE_DT_GET(node) (&test_gpio)
typedef struct {
    volatile uint32_t VERID, PARAM, LOCK, PCNS, ICNS, PCNP, ICNP, PIDR, PDDR, PDIR;
} RGPIO_Type;
extern RGPIO_Type test_port;
#define DT_REG_ADDR(node) ((uintptr_t)&test_port)
#define RGPIO_LOCK_PCNS_MASK 1U
#define DT_PHANDLE_BY_IDX(node, prop, idx) (idx)
#define DT_PROP_BY_IDX(node, prop, idx) ((idx)==0 ? 0x443c0010U+4U*(node) : 0x443c01c0U+4U*(node))
#define IOMUXC1_SW_MUX_CTL_PAD_MUX_MODE_MASK 7U
#define IOMUXC1_SW_MUX_CTL_PAD_SION_MASK 0x10U
#define IOMUXC1_SW_PAD_CTL_PAD_PU_MASK 0x200U
#define IOMUXC1_SW_PAD_CTL_PAD_PD_MASK 0x400U
typedef struct { uint32_t AUTHEN, LPM_CUR; } test_gate_t;
typedef struct { test_gate_t LPCG[36]; } test_ccm_t;
extern test_ccm_t test_ccm;
#define CCM_CTRL (&test_ccm)
#define kCLOCK_Gpio2 35U
#define kCLOCK_On 4U
#define CCM_LPCG_LPM_CUR_LPM_SETTING_CUR_MASK 7U
#define CCM_LPCG_LPM_CUR_LPM_SETTING_CUR(value) ((value)&7U)
void CLOCK_EnableClock(unsigned int);
uint32_t sys_read32(uintptr_t);
void sys_write32(uint32_t, uintptr_t);
bool device_is_ready(const struct device *);
void k_msleep(int);
void k_busy_wait(int);
int printk(const char *, ...);
int gpio_pin_configure(const struct device *, unsigned int, unsigned int);
int gpio_pin_get(const struct device *, unsigned int);
#endif
''')
    for name in ('soc.h','fsl_clock.h','zephyr/kernel.h','zephyr/drivers/gpio.h','zephyr/drivers/i2c.h','zephyr/sys/printk.h','zephyr/sys/sys_io.h'):
        header=root/name;header.parent.mkdir(parents=True,exist_ok=True)
        header.write_text('#include "test-platform.h"\n')
    binary=root/'soft-i2c-check'
    subprocess.run([compiler,'-std=c99','-Wall','-Wextra','-Werror','-fsanitize=undefined',
                    '-I',str(root),str(HERE/'check_soft_i2c.c'),'-o',str(binary)],check=True)
    subprocess.run([str(binary)],check=True)
