#!/usr/bin/env python3
"""Artifact workflow regressions using local files and mocked AWS responses."""
import base64
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import artifact_utils as util
import make_recipes as recipes
import upload
import check_artifact_access as access


class ArtifactTests(unittest.TestCase):
    def setUp(self):
        area = tempfile.TemporaryDirectory()
        self.addCleanup(area.cleanup)
        self.root = Path(area.name)
        self.staging = self.root / 'staging'
        for component, names in (
            (recipes.FIRMWARE, ['zephyr.elf', 'firmware_manager.py', 'check-linux.py']),
            (recipes.BRIDGE, ['bridge.py', 'bridge_lifecycle.sh', 'awsiotsdk-1.26.0-py3-none-any.whl',
                              'awscrt-0.28.1-cp311-abi3-manylinux2014_aarch64.whl']),
        ):
            folder = self.staging / component / recipes.VERSION
            folder.mkdir(parents=True)
            for name in names:
                (folder / name).write_bytes(('fixture-' + name).encode())
        self.plan = recipes.write_recipes(self.staging, self.root / 'recipes', 'private-bucket',
                                         '/nested/nxp/', region='us-east-1')
        self.data = util.load_plan(self.plan)

    def remote(self, artifact):
        return {'ContentLength': artifact['size'],
                'ChecksumSHA256': base64.b64encode(bytes.fromhex(artifact['sha256'])).decode()}

    def test_exact_upload_recipe_and_policy_paths(self):
        self.assertEqual(len(self.data['artifacts']), 7)
        self.assertEqual(self.data['prefix'], 'nested/nxp')
        policy = json.loads((self.root / 'artifact-access.json').read_text())
        resources = policy['Statement'][0]['Resource']
        self.assertEqual(set(resources), {f'arn:aws:s3:::private-bucket/nested/nxp/{c}/*' for c in self.data['components']})
        for artifact in self.data['artifacts']:
            self.assertIn('/' + recipes.VERSION + '/', artifact['uri'])

    def test_placeholder_region_and_unsafe_prefix_rejected(self):
        for bucket, prefix, region in [('replace-with-your-private-bucket', 'nxp', 'us-east-1'),
                                       ('private-bucket', '../nxp', 'us-east-1'),
                                       ('private-bucket', 'nxp//bad', 'us-east-1'),
                                       ('private-bucket', 'nxp', None)]:
            with self.assertRaises(ValueError):
                util.location(bucket, prefix, region)

    def test_bucket_prefix_or_region_drift_rejected_before_aws(self):
        with patch.object(upload, 'check_region') as call:
            for field, value in [('bucket', 'different-bucket'), ('prefix', 'other'), ('region', 'eu-west-1')]:
                with self.assertRaisesRegex(ValueError, 'does not match'):
                    upload.upload(self.plan, **{field: value})
            call.assert_not_called()

    def test_staged_or_recipe_bytes_cannot_change_after_generation(self):
        source = self.root / self.data['artifacts'][0]['source']
        saved = source.read_bytes()
        source.write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError, 'Staged bytes changed'):
            util.load_plan(self.plan)
        source.write_bytes(saved)
        recipe = self.root / self.data['recipes'][0]['path']
        recipe.write_text(recipe.read_text() + ' ')
        with self.assertRaisesRegex(ValueError, 'Recipe changed'):
            util.load_plan(self.plan)

    def test_wrong_bucket_region_rejected(self):
        with patch.object(util, 'aws', return_value={'LocationConstraint': 'eu-west-1'}):
            with self.assertRaisesRegex(ValueError, 'Bucket Region is eu-west-1'):
                util.check_region(self.data)

    def test_old_plan_after_release_change_is_rejected(self):
        with patch.object(util, 'version', return_value='2.0.0'):
            with self.assertRaisesRegex(ValueError, 'does not match release.json'):
                util.load_plan(self.plan)

    def test_extra_bridge_artifact_is_rejected(self):
        (self.staging / recipes.BRIDGE / recipes.VERSION / 'unexpected.txt').write_bytes(b'extra')
        with self.assertRaisesRegex(ValueError, 'exactly'):
            recipes.write_recipes(self.staging, self.root / 'other-recipes', 'private-bucket', 'nxp', region='us-east-1')

    def test_upload_uses_only_plan_and_can_resume_identical_objects(self):
        (self.staging / 'unrelated.txt').write_bytes(b'never upload')
        with patch.object(upload, 'check_region'), \
             patch.object(upload, 'head', side_effect=lambda _, a: self.remote(a)), \
             patch.object(upload, 'aws') as put:
            upload.upload(self.plan)
            put.assert_not_called()

    def test_missing_objects_uploaded_conditionally_with_checksum(self):
        absent = subprocess.CalledProcessError(254, ['aws'], stderr='An error occurred (404): Not Found')
        sequence = []
        for artifact in self.data['artifacts']:
            sequence.extend([absent, self.remote(artifact)])
        with patch.object(upload, 'check_region'), patch.object(upload, 'head', side_effect=sequence), \
             patch.object(upload, 'aws', return_value={}) as put:
            upload.upload(self.plan)
            self.assertEqual(put.call_count, 7)
            for call in put.call_args_list:
                self.assertIn('--if-none-match', call.args)
                self.assertIn('--checksum-sha256', call.args)

    def test_conflicting_existing_object_never_overwritten(self):
        with patch.object(upload, 'check_region'), patch.object(upload, 'head', return_value={'ContentLength': 0}), \
             patch.object(upload, 'aws') as put:
            with self.assertRaisesRegex(ValueError, 'Remote bytes'):
                upload.upload(self.plan)
            put.assert_not_called()

    def test_head_403_never_triggers_upload(self):
        denied = subprocess.CalledProcessError(254, ['aws'], stderr='An error occurred (403): Forbidden')
        with patch.object(upload, 'check_region'), patch.object(upload, 'head', side_effect=denied), \
             patch.object(upload, 'aws') as put:
            with self.assertRaises(subprocess.CalledProcessError):
                upload.upload(self.plan)
            put.assert_not_called()

    def test_conditional_write_race_verifies_winner_bytes(self):
        absent = subprocess.CalledProcessError(254, ['aws'], stderr='An error occurred (404): Not Found')
        race = subprocess.CalledProcessError(254, ['aws'], stderr='An error occurred (412): PreconditionFailed')
        sequence = []
        for artifact in self.data['artifacts']:
            sequence.extend([absent, self.remote(artifact)])
        with patch.object(upload, 'check_region'), patch.object(upload, 'head', side_effect=sequence), \
             patch.object(upload, 'aws', side_effect=race):
            upload.upload(self.plan)

    def fake_aws(self, region, service, operation, *args):
        self.assertEqual(region, 'us-east-1')
        if operation == 'describe-role-alias':
            self.assertEqual(args, ('--role-alias', 'BoardAlias'))
            return {'roleAliasDescription': {'roleArn': 'arn:aws:iam::123456789012:role/ActualDeviceRole'}}
        self.assertEqual(operation, 'simulate-principal-policy')
        self.assertIn('arn:aws:iam::123456789012:role/ActualDeviceRole', args)
        return {'EvaluationResults': [{'EvalActionName': 's3:GetObject',
                                       'EvalResourceName': 'arn:aws:s3:::' + a['bucket'] + '/' + a['key'],
                                       'EvalDecision': self.decision} for a in self.data['artifacts']]}

    def current_simulation(self):
        return {'EvaluationResults': [{
            'EvalActionName': 's3:GetObject', 'EvalDecision': 'allowed',
            'EvalResourceName': 'arn:${Partition}:s3:::${BucketName}/${KeyName}',
            'ResourceSpecificResults': [
                {'EvalResourceName': 'arn:aws:s3:::' + a['bucket'] + '/' + a['key'],
                 'EvalResourceDecision': 'allowed'} for a in self.data['artifacts']
            ],
        }]}

    def aws_with_simulation(self, simulation):
        alias = {'roleAliasDescription': {'roleArn': 'arn:aws:iam::123456789012:role/ActualDeviceRole'}}
        return patch.object(access, 'aws', side_effect=[alias, simulation])

    def test_current_aggregate_response_checks_individual_object_decisions(self):
        simulation = self.current_simulation()
        with patch.object(access, 'check_region'), self.aws_with_simulation(simulation), \
             patch.object(access, 'head', side_effect=lambda _, a: self.remote(a)) as head:
            result = access.check(self.plan, 'BoardAlias')
        self.assertEqual(result['result'], 'pass')
        self.assertEqual(head.call_count, 7)
        self.assertTrue(all(r['EvalResourceDecision'] == 'allowed' for r in result['resource_results']))
        self.assertEqual(result['iam_simulation'], simulation)

    def test_current_denial_keeps_context_boundary_and_matched_policy_details(self):
        simulation = self.current_simulation()
        aggregate = simulation['EvaluationResults'][0]
        aggregate['EvalDecision'] = 'explicitDeny'
        denied = aggregate['ResourceSpecificResults'][1]
        denied.update(EvalResourceDecision='explicitDeny', MissingContextValues=['aws:SourceVpce'],
                      PermissionsBoundaryDecisionDetail={'AllowedByPermissionsBoundary': False},
                      MatchedStatements=[{'SourcePolicyId': 'RestrictArtifacts'}])
        with patch.object(access, 'check_region'), self.aws_with_simulation(simulation), \
             patch.object(access, 'head') as head:
            with self.assertRaises(access.IAMSimulationError) as caught:
                access.check(self.plan, 'BoardAlias')
        head.assert_not_called()
        self.assertEqual(caught.exception.report['iam_simulation'], simulation)
        message = str(caught.exception)
        for detail in (denied['EvalResourceName'], 'explicitDeny', 'aws:SourceVpce',
                       'permissions boundary', 'RestrictArtifacts'):
            self.assertIn(detail, message)
        self.assertNotIn(aggregate['ResourceSpecificResults'][0]['EvalResourceName'], message)

    def test_missing_object_result_never_passes_on_aggregate_allow(self):
        simulation = self.current_simulation()
        missing = simulation['EvaluationResults'][0]['ResourceSpecificResults'].pop()
        with patch.object(access, 'check_region'), self.aws_with_simulation(simulation), \
             patch.object(access, 'head') as head:
            with self.assertRaisesRegex(access.IAMSimulationError, 'notEvaluated') as caught:
                access.check(self.plan, 'BoardAlias')
        head.assert_not_called()
        self.assertIn(missing['EvalResourceName'], str(caught.exception))

    def test_empty_wrong_action_and_unexpected_objects_do_not_grant_access(self):
        for variant in ('empty', 'wrong-action', 'unexpected-object', 'empty-resources'):
            with self.subTest(variant=variant):
                simulation = self.current_simulation()
                aggregate = simulation['EvaluationResults'][0]
                if variant == 'empty':
                    simulation['EvaluationResults'] = []
                elif variant == 'wrong-action':
                    aggregate['EvalActionName'] = 's3:PutObject'
                elif variant == 'unexpected-object':
                    aggregate['ResourceSpecificResults'][0]['EvalResourceName'] = 'arn:aws:s3:::other-bucket/object'
                else:
                    aggregate['ResourceSpecificResults'] = []
                with patch.object(access, 'check_region'), self.aws_with_simulation(simulation), \
                     patch.object(access, 'head') as head:
                    with self.assertRaisesRegex(access.IAMSimulationError, 'notEvaluated'):
                        access.check(self.plan, 'BoardAlias')
                head.assert_not_called()

    def test_duplicate_allow_does_not_override_denied_resource(self):
        simulation = self.current_simulation()
        entries = simulation['EvaluationResults'][0]['ResourceSpecificResults']
        entries.append({**entries[0], 'EvalResourceDecision': 'implicitDeny'})
        with patch.object(access, 'check_region'), self.aws_with_simulation(simulation), \
             patch.object(access, 'head') as head:
            with self.assertRaisesRegex(access.IAMSimulationError, 'implicitDeny'):
                access.check(self.plan, 'BoardAlias')
        head.assert_not_called()

    def test_aggregate_deny_cannot_be_hidden_by_individual_allows(self):
        simulation = self.current_simulation()
        simulation['EvaluationResults'][0]['EvalDecision'] = 'implicitDeny'
        with patch.object(access, 'check_region'), self.aws_with_simulation(simulation), \
             patch.object(access, 'head') as head:
            with self.assertRaisesRegex(access.IAMSimulationError, 'Aggregate s3:GetObject'):
                access.check(self.plan, 'BoardAlias')
        head.assert_not_called()

    def test_failed_cli_overwrites_stale_pass_with_raw_simulation_report(self):
        simulation = self.current_simulation()
        simulation['EvaluationResults'][0]['EvalDecision'] = 'implicitDeny'
        simulation['EvaluationResults'][0]['ResourceSpecificResults'][0]['EvalResourceDecision'] = 'implicitDeny'
        report_file = self.root / 'preflight.json'
        report_file.write_text('{"result":"pass"}')
        with patch.object(access, 'check_region'), self.aws_with_simulation(simulation), \
             patch.object(access, 'head') as head:
            with self.assertRaisesRegex(SystemExit, 'Simulation report:'):
                access.main(['--plan', str(self.plan), '--role-alias', 'BoardAlias', '--report', str(report_file)])
        head.assert_not_called()
        report = json.loads(report_file.read_text())
        self.assertEqual(report['result'], 'fail')
        self.assertEqual(report['iam_simulation'], simulation)

    def test_preflight_resolves_actual_alias_role_and_checks_all_objects(self):
        self.decision = 'allowed'
        with patch.object(access, 'check_region'), patch.object(access, 'aws', side_effect=self.fake_aws), \
             patch.object(access, 'head', side_effect=lambda _, a: self.remote(a)):
            result = access.check(self.plan, 'BoardAlias')
            self.assertEqual(result['artifacts'], 7)
            self.assertIn('ActualDeviceRole', result['role_arn'])

    def test_preflight_denied_role_stops_before_object_checks(self):
        self.decision = 'implicitDeny'
        with patch.object(access, 'check_region'), patch.object(access, 'aws', side_effect=self.fake_aws), \
             patch.object(access, 'head') as head:
            with self.assertRaisesRegex(ValueError, 'IAM simulation did not allow'):
                access.check(self.plan, 'BoardAlias')
            head.assert_not_called()

    def test_kms_requires_explicit_verification(self):
        self.decision = 'allowed'
        with patch.object(access, 'check_region'), patch.object(access, 'aws', side_effect=self.fake_aws), \
             patch.object(access, 'head', side_effect=lambda _, a: {**self.remote(a), 'ServerSideEncryption': 'aws:kms'}):
            with self.assertRaisesRegex(ValueError, 'SSE-KMS'):
                access.check(self.plan, 'BoardAlias')


if __name__ == '__main__':
    unittest.main(verbosity=2)
