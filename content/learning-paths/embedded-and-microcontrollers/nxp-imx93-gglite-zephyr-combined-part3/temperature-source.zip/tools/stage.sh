#!/bin/sh
set -eu
elf=${1:?Usage: stage.sh path/to/zephyr.elf [python-version]}
python_version=${2:-313}
here=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
. "$here/host-platform.sh"
lp_detect_host
printf 'Build host: %s/%s; staging target: linux/aarch64\n' "$LP_HOST_OS" "$LP_HOST_ARCH"
# Refuse an old or malformed ELF before creating deployment artifacts.
python3 "$here/inspect-elf.py" --require-temperature "$elf"
firmware=com.arm.NXPIMX93.ZephyrExternalTemperature
bridge=com.arm.NXPIMX93.ExternalTemperatureBridge
version=$(python3 "$here/tools/artifact_utils.py")
mkdir -p "staging/$firmware/$version" "staging/$bridge/$version"
cp "$elf" "staging/$firmware/$version/zephyr.elf"
cp "$here/components/firmware_manager.py" "$here/check-linux.py" "staging/$firmware/$version/"
cp "$here/components/bridge.py" "$here/components/bridge_lifecycle.sh" "staging/$bridge/$version/"
python3 -m pip download --only-binary=:all: \
    --platform manylinux2014_aarch64 --implementation cp \
    --python-version "$python_version" --abi "cp$python_version" --abi abi3 --abi none \
    --dest "staging/$bridge/$version" awsiotsdk==1.26.0
