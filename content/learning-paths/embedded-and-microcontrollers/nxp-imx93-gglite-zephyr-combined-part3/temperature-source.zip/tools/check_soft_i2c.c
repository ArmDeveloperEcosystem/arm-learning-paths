/* Model GPIO pull-ups, open-drain wires and slave ACK/data for the real app. */
#include <assert.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include "test-platform.h"
#ifndef SENSOR_SOURCE
#define SENSOR_SOURCE "../firmware/src/sensor.c"
#endif
#include SENSOR_SOURCE

struct device test_gpio={.name="gpio@43810000"};
RGPIO_Type test_port;
test_ccm_t test_ccm;
static bool clock_enabled,clock_denied,mux_denied,pad_denied,direction_denied;
static uint32_t mux_values[4],pad_values[4];
static bool ready=true,short_scl,short_sda;
static unsigned int flags[4],edges,stretch_reads,release_after;
static int configure_error,read_error;
static unsigned int queued[1024],head,tail;
static unsigned int transmitted[1024],tx_count;
static char output[16384];
static size_t used;

bool device_is_ready(const struct device *dev){assert(dev==&test_gpio);return ready;}
void k_msleep(int ms){(void)ms;}
void k_busy_wait(int us){assert(us>0);}
void CLOCK_EnableClock(unsigned int name)
{
    assert(name==kCLOCK_Gpio2);
    if(clock_denied)return;
    clock_enabled=true;test_ccm.LPCG[name].LPM_CUR=kCLOCK_On;
}
uint32_t sys_read32(uintptr_t address)
{
    if(address==SENSOR_MUX_REG(SDA_PIN))return mux_values[2];
    if(address==SENSOR_MUX_REG(SCL_PIN))return mux_values[3];
    if(address==SENSOR_PAD_REG(SDA_PIN))return pad_values[2];
    if(address==SENSOR_PAD_REG(SCL_PIN))return pad_values[3];
    assert(!"unexpected pad register");return 0;
}
void sys_write32(uint32_t value,uintptr_t address)
{
    assert(address==SENSOR_MUX_REG(SDA_PIN) || address==SENSOR_MUX_REG(SCL_PIN));
    if(!mux_denied)mux_values[address==SENSOR_MUX_REG(SDA_PIN)?2:3]=value;
}
int printk(const char *format,...)
{
    va_list args;va_start(args,format);
    int n=vsnprintf(output+used,sizeof(output)-used,format,args);va_end(args);
    assert(n>=0 && (size_t)n<sizeof(output)-used);used+=(size_t)n;return n;
}
int gpio_pin_configure(const struct device *dev,unsigned int pin,unsigned int value)
{
    assert(dev==&test_gpio && (pin==2 || pin==3));
    assert(!(value&GPIO_OUTPUT_HIGH)); /* No push-pull HIGH, including recovery. */
    if(configure_error)return configure_error;
    if(!clock_enabled)return 0;
    if(!mux_denied)mux_values[pin]=0;
    if(!pad_denied)pad_values[pin]=(value&GPIO_PULL_UP)?IOMUXC1_SW_PAD_CTL_PAD_PU_MASK:0;
    if(test_port.PCNS&BIT(pin))return 0; /* Secure writes to an NS pin are ignored. */
    if(pin==3 && (flags[pin]&GPIO_OUTPUT_LOW) && (value&GPIO_INPUT)) {
        edges++;
        if(release_after && edges>=release_after)short_sda=false;
        assert(tx_count<sizeof(transmitted)/sizeof(transmitted[0]));
        transmitted[tx_count++]=(flags[2]&GPIO_OUTPUT_LOW)?0:1;
    }
    flags[pin]=value;
    if(!direction_denied){
        if(value&GPIO_OUTPUT_LOW)test_port.PDDR|=BIT(pin);
        else test_port.PDDR&=~BIT(pin);
    }
    return 0;
}
int gpio_pin_get(const struct device *dev,unsigned int pin)
{
    assert(dev==&test_gpio && (pin==2 || pin==3));
    if(read_error)return read_error;
    if(!clock_enabled || !(mux_values[pin]&IOMUXC1_SW_MUX_CTL_PAD_SION_MASK))return 0;
    if((test_port.PCNS|test_port.PIDR)&BIT(pin))return 0;
    if(flags[pin]&GPIO_OUTPUT_LOW)return 0;
    if(pin==3 && stretch_reads){stretch_reads--;return 0;}
    if((pin==3 && short_scl) || (pin==2 && short_sda))return 0;
    /* No external pull-up in this model. Floating wires do not read HIGH.
     * This reproduces the original SCL timeout when configure drops pull-ups. */
    if(!(flags[pin]&GPIO_PULL_UP))return 0;
    if(pin==2 && head<tail)return (int)queued[head++];
    return 1;
}
static void bit(unsigned int value){assert(tail<1024);queued[tail++]=value;}
static void byte(uint8_t value){for(int n=7;n>=0;n--)bit((value>>n)&1);}
static void reset(void)
{
    configured=false;sensor_address=0;ready=true;short_scl=short_sda=false;
    memset(flags,0,sizeof(flags));edges=stretch_reads=release_after=0;
    configure_error=read_error=0;head=tail=tx_count=0;used=0;output[0]=0;
    memset(&test_port,0,sizeof(test_port));
    test_port.VERID=0x01000001;test_port.PARAM=2;
    memset(&test_ccm,0,sizeof(test_ccm));
    memset(mux_values,0,sizeof(mux_values));memset(pad_values,0,sizeof(pad_values));
    clock_enabled=true;clock_denied=mux_denied=pad_denied=direction_denied=false;
}
static void response(const uint8_t *data,size_t count)
{
    bit(1);bit(0);bit(0);bit(1);bit(0); /* START, ACKs, repeated START, ACK. */
    for(size_t n=0;n<count;n++)byte(data[n]);
}
static void write_ack(void){bit(1);bit(0);bit(0);bit(0);}
static void missing(void){bit(1);bit(1);} /* START succeeds, address NACK. */
static void sample_response(unsigned int slot)
{
    const uint8_t id[]={0x58},status[]={0},cal[]={0x70,0x6b,0x43,0x67,0x18,0xfc};
    const uint32_t raw=519888;
    uint8_t adc[]={(uint8_t)(raw>>12),(uint8_t)(raw>>4),(uint8_t)(raw<<4)};
    bit(1); /* Initial idle SDA check. */
    if(slot){missing();response(id,1);}else{response(id,1);missing();}
    write_ack();response(status,1);response(cal,sizeof(cal));write_ack();
    write_ack();response(status,1);response(adc,sizeof(adc));
}
int main(void)
{
    int32_t value=0;
    reset();clock_enabled=false;assert(gpio_pin_get(gpio,SCL_PIN)==0);
    test_ccm.LPCG[1].LPM_CUR=0x1234;
    assert(prepare_gpio_access()==0 && clock_enabled);
    assert(test_ccm.LPCG[kCLOCK_Gpio2].LPM_CUR==kCLOCK_On && test_ccm.LPCG[1].LPM_CUR==0x1234);
    assert(prepare_bus()==0);
    puts("PASS: GPIO2 clock enabled before use without touching another gate");

    reset();clock_enabled=false;clock_denied=true;
    assert(lp_sensor_sample(&value)==-EACCES && flags[2]==0 && flags[3]==0);
    assert(strstr(output,"clock enable did not take effect"));
    puts("PASS: rejected clock setup aborts before GPIO pin access");

    for(int invalid=0;invalid<2;invalid++){
        reset();test_port.VERID=invalid?UINT32_MAX:0;
        test_port.PCNS=UINT32_MAX;test_port.PIDR=UINT32_MAX;
        assert(lp_sensor_sample(&value)==-ENODEV && flags[2]==0 && flags[3]==0);
        assert(test_port.PCNS==UINT32_MAX && test_port.PIDR==UINT32_MAX);
        assert(strstr(output,"identity is unreadable"));
    }
    puts("PASS: zero/all-ones GPIO identity is rejected before sensor or security writes");

    reset();mux_denied=true;mux_values[2]=1;
    assert(line(SDA_PIN,true)==-EIO && strstr(output,"pad setup did not latch"));
    reset();pad_denied=true;
    assert(line(SDA_PIN,true)==-EIO);
    puts("PASS: ignored mux or pad writes are diagnosed rather than reported as a low wire");

    reset();direction_denied=true;
    assert(line(SCL_PIN,false)==-EACCES && strstr(output,"direction write did not latch"));
    puts("PASS: ignored GPIO direction writes cause an explicit access error");

    reset();assert(prepare_bus()==0);
    assert(mux_values[2]==IOMUXC1_SW_MUX_CTL_PAD_SION_MASK && mux_values[3]==IOMUXC1_SW_MUX_CTL_PAD_SION_MASK);
    puts("PASS: both sensor pads select GPIO mode with SION input readback enabled");

    reset();test_port.PCNS=0xffffffff;test_port.PIDR=0xffffffff;
    test_port.ICNS=0x12345678;test_port.PCNP=0xabcdef01;test_port.ICNP=0x87654321;
    assert(prepare_bus()<0 && gpio_pin_get(gpio,SCL_PIN)==0);
    assert(prepare_gpio_access()==0);
    assert(test_port.PCNS==0xfffffff3 && test_port.PIDR==0xfffffff3);
    assert(test_port.ICNS==0x12345678 && test_port.PCNP==0xabcdef01 && test_port.ICNP==0x87654321);
    assert(prepare_bus()==0);
    puts("PASS: secure access and digital input restored only for GPIO2 bits 2/3; other policies unchanged");

    reset();test_port.PCNS=0xffffffff;test_port.LOCK=RGPIO_LOCK_PCNS_MASK;
    assert(lp_sensor_sample(&value)==-EACCES && test_port.PCNS==0xffffffff);
    assert(flags[2]==0 && flags[3]==0 && strstr(output,"is locked"));
    puts("PASS: locked non-secure pins fail explicitly without GPIO drive attempts");

    reset();test_port.PCNS=0xfffffff3;test_port.LOCK=RGPIO_LOCK_PCNS_MASK;
    assert(prepare_gpio_access()==0 && test_port.PCNS==0xfffffff3);
    puts("PASS: a locked but already compatible pin policy remains usable");

    reset();assert(prepare_bus()==0);
    assert((flags[2]&(GPIO_INPUT|GPIO_PULL_UP))==(GPIO_INPUT|GPIO_PULL_UP));
    assert((flags[3]&(GPIO_INPUT|GPIO_PULL_UP))==(GPIO_INPUT|GPIO_PULL_UP));
    puts("PASS: idle bus rises without external pull-ups; both pads retain pull-ups");

    reset();short_scl=true;assert(prepare_bus()==-ETIMEDOUT);
    assert(strstr(output,"SCL cannot rise"));
    puts("PASS: a physically held-low clock times out with the SCL diagnostic");

    reset();stretch_reads=3;assert(prepare_bus()==0 && stretch_reads==0);
    puts("PASS: bounded clock stretching is accepted");

    reset();short_sda=true;assert(prepare_bus()==-EBUSY && edges==10);
    assert(strstr(output,"SDA remains low"));
    puts("PASS: nine recovery clocks and STOP preserve a real SDA fault");

    reset();short_sda=true;release_after=3;assert(prepare_bus()==0 && edges==4);
    puts("PASS: interrupted slave transaction recovers and releases the bus");

    reset();configure_error=-EIO;assert(prepare_bus()==-EIO);
    reset();read_error=-EACCES;assert(prepare_bus()==-EACCES);
    puts("PASS: GPIO configuration/read errors are preserved");

    reset();assert(prepare_bus()==0);assert(line(SCL_PIN,false)==0);tx_count=0;bit(0);assert(write_byte(0xa5)==0);
    assert(tx_count==9);
    for(int n=0;n<8;n++)assert(transmitted[n]==((0xa5U>>(7-n))&1));
    assert((flags[2]&GPIO_INPUT) && (flags[3]&GPIO_OUTPUT_LOW));
    puts("PASS: write bits are MSB-first and SDA is released for the slave ACK");

    for(int last=0;last<2;last++){
        reset();assert(prepare_bus()==0);assert(line(SCL_PIN,false)==0);tx_count=0;byte(0x58);uint8_t id=0;
        assert(read_byte(&id,last)==0 && id==0x58 && tx_count==9);
        assert(transmitted[8]==(unsigned int)last && (flags[2]&GPIO_INPUT));
    }
    puts("PASS: read bytes ACK intermediate data and NACK the final byte");

    reset();ready=false;assert(lp_sensor_sample(&value)==-ENODEV && flags[2]==0 && flags[3]==0);
    puts("PASS: an unready controller causes no pin writes");

    for(unsigned int slot=0;slot<2;slot++){
        reset();sample_response(slot);
        test_port.PCNS=0xffffffff;test_port.PIDR=0xffffffff;
        assert(lp_sensor_sample(&value)==0 && value==25080000 && sensor_address==0x76+slot);
        assert(test_port.PCNS==0xfffffff3 && test_port.PIDR==0xfffffff3);
        assert(head==tail && (flags[2]&GPIO_INPUT) && (flags[3]&GPIO_INPUT));
        printf("PASS: full software-I2C BMP280 acquisition at 0x%02x produces 25.08 C\n",sensor_address);
    }
    reset();bit(1);missing();missing();assert(lp_sensor_sample(&value)==-ENXIO);
    assert((flags[2]&GPIO_INPUT) && (flags[3]&GPIO_INPUT));
    puts("PASS: missing devices return address NACK and leave both lines released");
    return 0;
}
