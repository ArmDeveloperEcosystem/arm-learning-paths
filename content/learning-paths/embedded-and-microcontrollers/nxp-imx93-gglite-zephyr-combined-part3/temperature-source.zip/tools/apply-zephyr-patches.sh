#!/usr/bin/env bash
# Recognize the complete expected patch set before changing the worktree.
set -Eeuo pipefail
[[ $# == 2 ]] || { echo 'Usage: apply-zephyr-patches.sh ZEPHYR_SOURCE PATCH_DIRECTORY' >&2; exit 2; }
source_tree=$(cd -- "$1" && pwd)
patch_dir=$(cd -- "$2" && pwd)
patches=(
    "$patch_dir/0001-linux-resource-table.patch"
    "$patch_dir/0002-keep-resource-table.patch"
    "$patch_dir/0003-frdm-linux-startup.patch"
)
states=()
pending=()
for patchfile in "${patches[@]}"; do
    name=${patchfile##*/}
    [[ -r $patchfile ]] || { echo "ERROR: Missing required patch: $patchfile" >&2; exit 1; }
    if git -C "$source_tree" apply --reverse --check "$patchfile" >/dev/null 2>&1; then
        states+=("Already applied")
    elif git -C "$source_tree" apply --check "$patchfile" >/dev/null 2>&1; then
        states+=("Applied")
        pending+=("$patchfile")
    else
        echo "ERROR: Patch is not applicable and cannot be verified as already applied: $name" >&2
        echo 'No patches were applied by this invocation. Preserve your edits and inspect the patch and git diff.' >&2
        git -C "$source_tree" apply --check "$patchfile" >&2 || true
        exit 1
    fi
done

if (( ${#pending[@]} )); then
    # One git apply checks all pending patches together before writing files.
    if ! git -C "$source_tree" apply "${pending[@]}"; then
        echo 'ERROR: Patch application failed after preflight; source may have changed. Preserve edits and inspect git diff.' >&2
        exit 1
    fi
fi
for ((index=0; index<${#patches[@]}; index++)); do
    printf '%s: %s\n' "${states[index]}" "${patches[index]##*/}"
done
