#!/usr/bin/env python3
"""Real Git patch regressions; build-entry tests stub the SDK and west only."""
from contextlib import contextmanager
import itertools
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

BUNDLE=Path(__file__).resolve().parents[1]
HELPER=BUNDLE/'tools/apply-zephyr-patches.sh'
FIXTURES=BUNDLE/'tools/fixtures/zephyr-v4.3.0'
GIT=shutil.which('git')
SOURCES=('subsys/ipc/open-amp/resource_table.c','soc/nxp/imx/imx9/imx93/m33/soc.c')
NAMES=('0001-linux-resource-table.patch','0002-keep-resource-table.patch','0003-frdm-linux-startup.patch')

def git(tree,*args):
    return subprocess.run([GIT,'-C',str(tree),*args],check=True,capture_output=True,text=True)


class PatchHandling(unittest.TestCase):
    @contextmanager
    def fixture(self):
        with tempfile.TemporaryDirectory(prefix='imx93-patches-') as directory:
            root=Path(directory);tree=root/'zephyr';shutil.copytree(FIXTURES,tree)
            git(tree,'init','-q','--template=');git(tree,'add','.')
            git(tree,'-c','user.name=Test','-c','user.email=test@example.invalid','commit','-qm','Pinned source fixture')
            patches=root/'patches';shutil.copytree(BUNDLE/'patches',patches)
            yield root,tree,patches

    def run_helper(self,tree,patches,env=None):
        return subprocess.run(['bash',str(HELPER),str(tree),str(patches)],capture_output=True,text=True,env=env)

    def snapshot(self,tree):return {p:(tree/p).read_bytes() for p in SOURCES}

    def test_all_fresh_applied_and_mixed_states(self):
        for applied in itertools.product((False,True),repeat=3):
            with self.subTest(applied=applied),self.fixture() as (_,tree,patches):
                for name,present in zip(NAMES,applied):
                    if present:git(tree,'apply',str(patches/name))
                result=self.run_helper(tree,patches)
                self.assertEqual(result.returncode,0,result.stderr)
                self.assertEqual(result.stderr,'')
                self.assertEqual(result.stdout.count('Already applied:'),sum(applied))
                self.assertEqual(result.stdout.count('Applied:'),3-sum(applied))
                for name in NAMES:git(tree,'apply','--reverse','--check',str(patches/name))
                before=self.snapshot(tree);repeat=self.run_helper(tree,patches)
                self.assertEqual(repeat.returncode,0,repeat.stderr)
                self.assertEqual(repeat.stderr,'');self.assertEqual(repeat.stdout.count('Already applied:'),3)
                self.assertEqual(self.snapshot(tree),before)

    def test_later_conflict_does_not_apply_earlier_patches(self):
        with self.fixture() as (_,tree,patches):
            source=tree/SOURCES[1];source.write_text(source.read_text().replace('GPIO1->PCNS = 0x0;','GPIO1->PCNS = 0x1;'))
            before=self.snapshot(tree);result=self.run_helper(tree,patches)
            self.assertNotEqual(result.returncode,0)
            self.assertIn(NAMES[2],result.stderr);self.assertIn('not applicable',result.stderr)
            self.assertIn('No patches were applied',result.stderr)
            self.assertEqual(self.snapshot(tree),before)

    def test_malformed_patch_does_not_change_source(self):
        with self.fixture() as (_,tree,patches):
            (patches/NAMES[1]).write_text('Not a patch\n');before=self.snapshot(tree)
            result=self.run_helper(tree,patches)
            self.assertNotEqual(result.returncode,0);self.assertIn(NAMES[1],result.stderr)
            self.assertEqual(self.snapshot(tree),before)

    def test_missing_patch_is_explicit_and_source_is_untouched(self):
        with self.fixture() as (_,tree,patches):
            (patches/NAMES[2]).unlink();before=self.snapshot(tree)
            result=self.run_helper(tree,patches)
            self.assertNotEqual(result.returncode,0);self.assertIn('Missing required patch',result.stderr)
            self.assertEqual(self.snapshot(tree),before)

    def test_unrelated_source_edits_are_preserved(self):
        with self.fixture() as (_,tree,patches):
            source=tree/SOURCES[0];source.write_text(source.read_text()+'\n/* User-owned unrelated edit. */\n')
            note=tree/'user-note';note.write_text('keep\n')
            result=self.run_helper(tree,patches);self.assertEqual(result.returncode,0,result.stderr)
            self.assertIn('User-owned unrelated edit.',source.read_text());self.assertEqual(note.read_text(),'keep\n')

    def build_fixture(self,root,tree,patches):
        bundle=root/'bundle';(bundle/'tools').mkdir(parents=True)
        shutil.copy2(BUNDLE/'build-zephyr.sh',bundle/'build-zephyr.sh')
        shutil.copy2(HELPER,bundle/'tools'/HELPER.name);shutil.copytree(patches,bundle/'patches')
        (bundle/'setup-zephyr-sdk.sh').write_text('#!/bin/sh\nexit 0\n')
        (bundle/'inspect-elf.py').write_text('raise SystemExit(0)\n')
        bins=root/'bin';bins.mkdir()
        wrapper=bins/'git'
        wrapper.write_text('#!'+sys.executable+'\nimport os,sys\nargs=sys.argv[1:]\n'
                           'if args[-2:]==["rev-parse","HEAD"]:print("3568e1b6d5cdd51a6b964a2a1d6d29200fea2056")\n'
                           'else:os.execv('+repr(GIT)+',["git"]+args)\n')
        wrapper.chmod(0o755)
        west=bins/'west';west.write_text('#!'+sys.executable+'\nimport os,sys\nfrom pathlib import Path\n'
            'Path(os.environ["WEST_LOG"]).write_text("called")\n'
            'p=Path(sys.argv[sys.argv.index("-d")+1])/"zephyr";p.mkdir(parents=True)\n'
            '(p/"zephyr.elf").write_bytes(b"host-only fixture")\n');west.chmod(0o755)
        file=bins/'file';file.write_text('#!/bin/sh\nexit 0\n');file.chmod(0o755)
        sdk=root/'sdk';objcopy=sdk/'arm-zephyr-eabi/bin/arm-zephyr-eabi-objcopy'
        objcopy.parent.mkdir(parents=True);objcopy.write_text('#!/bin/sh\nexit 0\n');objcopy.chmod(0o755)
        env=dict(os.environ,PATH=str(bins)+os.pathsep+os.environ['PATH'],ZEPHYR_WORKSPACE=str(root),
                 ZEPHYR_SDK_INSTALL_DIR=str(sdk),ZEPHYR_TOOLCHAIN_VARIANT='zephyr',WEST_LOG=str(root/'west.log'))
        return bundle,env

    def test_build_entry_stops_before_west_on_conflict(self):
        with self.fixture() as (root,tree,patches):
            source=tree/SOURCES[1];source.write_text(source.read_text().replace('GPIO1->PCNS = 0x0;','GPIO1->PCNS = 0x1;'))
            before=self.snapshot(tree);bundle,env=self.build_fixture(root,tree,patches)
            result=subprocess.run(['bash',str(bundle/'build-zephyr.sh'),'temperature'],env=env,capture_output=True,text=True)
            self.assertNotEqual(result.returncode,0);self.assertIn('not applicable',result.stderr)
            self.assertFalse((root/'west.log').exists());self.assertEqual(self.snapshot(tree),before)

    def test_build_entry_continues_cleanly_when_all_patches_are_present(self):
        with self.fixture() as (root,tree,patches):
            git(tree,'apply',*[str(patches/n) for n in NAMES]);before=self.snapshot(tree)
            bundle,env=self.build_fixture(root,tree,patches)
            result=subprocess.run(['bash',str(bundle/'build-zephyr.sh'),'temperature'],env=env,capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertEqual(result.stderr,'');self.assertEqual(result.stdout.count('Already applied:'),3)
            self.assertTrue((root/'west.log').exists());self.assertEqual(self.snapshot(tree),before)


if __name__=='__main__':unittest.main(verbosity=2)
