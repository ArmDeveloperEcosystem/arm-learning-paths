#!/usr/bin/env python3
"""Read-only workstation checks of generated S3 objects and the device role."""
import argparse
import json
from pathlib import Path
import subprocess
from artifact_utils import aws, check_region, check_remote, head, load_plan


class IAMSimulationError(ValueError):
    def __init__(self, message, report):
        super().__init__(message)
        self.report = report


def resource_results(simulation, resources):
    """Read current per-resource results, with a fallback for legacy responses."""
    matches = {resource: [] for resource in resources}
    for evaluation in simulation.get('EvaluationResults', []):
        if evaluation.get('EvalActionName') != 's3:GetObject':
            continue
        # AWS now aggregates EvaluationResults by action. EvalResourceName at
        # that level can be an ARN template; it is not the requested object.
        # https://docs.aws.amazon.com/IAM/latest/APIReference/API_EvaluationResult.html
        if 'ResourceSpecificResults' in evaluation:
            entries = evaluation['ResourceSpecificResults']
        else:
            entries = [{**evaluation, 'EvalResourceDecision': evaluation.get('EvalDecision')}]
        for entry in entries:
            name = entry.get('EvalResourceName')
            if name in matches:
                matches[name].append(entry)

    results = []
    for resource, entries in matches.items():
        if not entries:
            results.append({'EvalResourceName': resource, 'EvalResourceDecision': 'notEvaluated'})
            continue
        # A duplicate allow must never hide a denial for the same object.
        denied = [entry for entry in entries if entry.get('EvalResourceDecision') != 'allowed']
        results.append(denied[0] if denied else entries[0])
    return results


def denial_detail(entry):
    detail = entry['EvalResourceName'] + ': ' + str(entry.get('EvalResourceDecision', 'unknownDecision'))
    if entry.get('MissingContextValues'):
        detail += '; missing context=' + ', '.join(entry['MissingContextValues'])
    if entry.get('PermissionsBoundaryDecisionDetail', {}).get('AllowedByPermissionsBoundary') is False:
        detail += '; permissions boundary does not allow this request'
    policies = sorted({statement['SourcePolicyId'] for statement in entry.get('MatchedStatements', [])
                       if statement.get('SourcePolicyId')})
    if policies:
        detail += '; matched policies=' + ', '.join(policies)
    return detail


def check(plan_file, role_alias):
    plan = load_plan(plan_file)
    check_region(plan)
    alias = aws(plan['region'], 'iot', 'describe-role-alias', '--role-alias', role_alias)
    role = alias['roleAliasDescription']['roleArn']
    resources = ['arn:aws:s3:::' + a['bucket'] + '/' + a['key'] for a in plan['artifacts']]
    result = aws(plan['region'], 'iam', 'simulate-principal-policy', '--policy-source-arn', role,
                 '--action-names', 's3:GetObject', '--resource-arns', *resources)
    evaluated = resource_results(result, resources)
    denied = [entry for entry in evaluated if entry.get('EvalResourceDecision') != 'allowed']
    aggregate_denied = [entry for entry in result.get('EvaluationResults', [])
                        if entry.get('EvalActionName') == 's3:GetObject' and entry.get('EvalDecision') != 'allowed']
    report = {'result': 'fail', 'stage': 'iam-simulation', 'region': plan['region'],
              'role_alias': role_alias, 'role_arn': role, 'version': plan['version'],
              'artifacts': len(resources), 'resource_results': evaluated, 'iam_simulation': result}
    if denied or aggregate_denied:
        detail = '\n'.join(denial_detail(entry) for entry in denied)
        if not denied:
            detail = 'Aggregate s3:GetObject decision was not allowed; inspect the raw simulation report.'
        raise IAMSimulationError('IAM simulation did not allow ' + role + ' to read:\n' + detail +
                                 '\nInspect the reported decisions and existing policies before changing IAM permissions.', report)
    for artifact in plan['artifacts']:
        remote = head(plan, artifact)
        check_remote(artifact, remote)
        if remote.get('ServerSideEncryption') == 'aws:kms':
            raise ValueError('Artifact uses SSE-KMS: verify kms:Decrypt and the KMS key policy for ' + role +
                             '; this preflight does not qualify KMS access')
    report.update(result='pass', stage='complete',
                  limits='IAM simulation and workstation HEAD requests do not test device credentials, bucket/SCP/VPC policies or board clock/signing.')
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, default=Path('artifact-plan.json'))
    parser.add_argument('--role-alias', required=True, help='Exact iotRoleAlias configured on the board')
    parser.add_argument('--report', type=Path, default=Path('artifact-preflight.json'))
    args = parser.parse_args(argv)
    try:
        result = check(args.plan, args.role_alias)
        args.report.write_text(json.dumps(result, indent=2) + '\n')
        print(f"PASS: {result['artifacts']} artifacts, bucket Region and simulated S3 reads for {result['role_arn']}")
        print(result['limits'])
    except IAMSimulationError as error:
        args.report.write_text(json.dumps(error.report, indent=2) + '\n')
        raise SystemExit('Artifact preflight failed: ' + str(error) + '\nSimulation report: ' + str(args.report))
    except subprocess.CalledProcessError as error:
        raise SystemExit(error.stderr or str(error))
    except (OSError, ValueError, KeyError) as error:
        raise SystemExit('Artifact preflight failed: ' + str(error))


if __name__ == '__main__':
    main()
