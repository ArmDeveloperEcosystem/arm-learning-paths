#!/usr/bin/env python3
"""Create two JSON recipes from the actual staged artifact filenames."""
import argparse
import json
import os
from pathlib import Path
from artifact_utils import fingerprint, location, version, write_plan

FIRMWARE = "com.arm.NXPIMX93.ZephyrExternalTemperature"
BRIDGE = "com.arm.NXPIMX93.ExternalTemperatureBridge"
VERSION = version()
TOPIC = "nxp/imx93/temperature/external"


def make_recipe(name, files, bucket, prefix, lifecycle, release):
    return {
        "RecipeFormatVersion": "2020-01-25", "ComponentName": name,
        "ComponentVersion": release, "ComponentType": "aws.greengrass.generic",
        "ComponentPublisher": "Arm", "ComponentDescription": name.rsplit(".", 1)[1],
        "Manifests": [{
            "Platform": {"os": "linux", "architecture": "aarch64",
                         "runtime": "aws_nucleus_lite"},
            "Lifecycle": lifecycle,
            "Artifacts": [{"URI": f"s3://{bucket}/{prefix}/{name}/{release}/{f.name}"}
                          for f in files],
        }],
    }


def write_recipes(staging, output, bucket, prefix, region=None):
    bucket, prefix, region = location(bucket, prefix, region or os.environ.get('AWS_REGION'))
    release = version()
    output.mkdir(parents=True, exist_ok=True)
    a, w = "{artifacts:path}", "{work:path}"
    firmware_files = sorted((staging / FIRMWARE / release).glob("*"))
    bridge_files = sorted((staging / BRIDGE / release).glob("*"))
    if {f.name for f in firmware_files} != {"zephyr.elf", "firmware_manager.py", "check-linux.py"}:
        raise ValueError("Stage zephyr.elf, firmware_manager.py and check-linux.py first")
    if not {"bridge.py", "bridge_lifecycle.sh"}.issubset({f.name for f in bridge_files}):
        raise ValueError("Stage the bridge source files first")
    wheels = [f for f in bridge_files if f.suffix == ".whl"]
    if not any(f.name.startswith("awsiotsdk-1.26.0-") for f in wheels):
        raise ValueError("Missing pinned awsiotsdk wheel")
    if not any(f.name.startswith("awscrt-0.28.1-") and "aarch64" in f.name for f in wheels):
        raise ValueError("Missing pinned AArch64 awscrt wheel")
    if len(bridge_files) != 4 or len(wheels) != 2:
        raise ValueError("Bridge staging must contain exactly its two source files and two pinned wheels")
    for artifact in firmware_files + bridge_files:
        fingerprint(artifact)
    firmware = make_recipe(FIRMWARE, firmware_files, bucket, prefix, {
        phase: {"RequiresPrivilege": True, "Script":
                f'exec python3 -u "{a}/firmware_manager.py" {phase} '
                f'--artifact "{a}/zephyr.elf" --work "{w}"'}
        for phase in ("install", "run")
    }, release)
    bridge = make_recipe(BRIDGE, bridge_files, bucket, prefix, {
        phase: {"RequiresPrivilege": True, "Script":
                f'exec /bin/sh "{a}/bridge_lifecycle.sh" {phase} "{a}" "{w}"'
                + (' "{configuration:/serialDevice}" "{iot:thingName}"'
                   if phase == "run" else "")}
        for phase in ("install", "run")
    }, release)
    bridge["ComponentConfiguration"] = {"DefaultConfiguration": {
        "serialDevice": "/dev/nxp-temperature",
        "accessControl": {"aws.greengrass.ipc.mqttproxy": {
            f"{BRIDGE}:publish:1": {
                "policyDescription": "Publish only external temperature telemetry",
                "operations": ["aws.greengrass#PublishToIoTCore"],
                "resources": [TOPIC],
            }
        }},
    }}
    for recipe in (firmware, bridge):
        (output / (recipe["ComponentName"] + ".json")).write_text(
            json.dumps(recipe, indent=2) + "\n")
    return write_plan(staging, output, (firmware, bridge), bucket, prefix, region, release)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--staging", type=Path, default=Path("staging"))
    parser.add_argument("--output", type=Path, default=Path("recipes"))
    parser.add_argument("--bucket", required=True)
    parser.add_argument("--prefix", default="nxp-imx93-temperature")
    parser.add_argument("--region", default=os.environ.get('AWS_REGION') or os.environ.get('AWS_DEFAULT_REGION'))
    args = parser.parse_args()
    try:
        plan = write_recipes(args.staging, args.output, args.bucket, args.prefix, args.region)
        print(f'Generated two recipes, {plan} and {plan.with_name("artifact-access.json")}')
    except (OSError, ValueError, KeyError) as error:
        raise SystemExit('Recipe generation refused: ' + str(error))
