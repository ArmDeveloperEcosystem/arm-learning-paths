# FRDM-IMX93 BMP280 software-I2C diagnostics

Use P11.3 for SDA and P11.5 for SCL. P11.17 is 3.3 V; P11.20 is GND.
CSB connects to P11.17 to select I2C at power-on. SDO on P11.20 selects
address 0x76; SDO on 3.3 V selects 0x77. Both addresses are probed.
Do not swap CSB and SDO: CSB on P11.20 selects SPI and prevents I2C responses.

`BMP280 probe v4` enables the GPIO2 clock before accessing its registers and
checks the peripheral's version ID. Zero control-register values alone do not
prove the bank is accessible. It then configures only pins 2/3 for M33 access
and digital input. Each line change verifies the GPIO mux, forced input path
(SION), pull-up and direction readback. Other gates, pins, banks, interrupt
policy and TRDC settings are preserved.

The app retains pad pull-ups when releasing or pulling
either line low. The pinned RGPIO driver clears pull-ups on a configure call
that omits GPIO_PULL_UP; the earlier app therefore left an unpulled SCL floating.
High is always released as an input, never driven push-pull. External SDA/SCL
pull-ups to 3.3 V are recommended (typically 4.7 kΩ when the module has none).

Before probing, the app checks that both lines can rise. It attempts up to nine
recovery clocks and STOP if SDA is held mid-transaction. Interpret the UART:

- `idle SCL=1 SDA=1`: the bus passed its initial idle check.
- `clock enable did not take effect` or `identity is unreadable`: GPIO2
  clock/access setup failed before the app attempted any sensor transaction.
- `pad setup did not latch` or `direction write did not latch`: peripheral
  writes are not taking effect; this is not an I2C address-selection failure.
- `SCL cannot rise`: clock release timed out (`-116` in this Zephyr build).
  Review the GPIO2 register readback too. Check SCL wiring, pull-ups and sensor power; changing the address will not
  fix a low clock line.
- `SDA remains low`: recovery failed; check SDA wiring and the sensor.
- `read_rc=0 chip_id=0x58`: BMP280 found. Other IDs are reported and rejected.
- `read_rc=-6` means a byte was not acknowledged. If both addresses fail,
  measure VCC and CSB at the module relative to its own GND. CSB must remain
  at 3.3 V; a low CSB disables I2C until the sensor is fully power-cycled.
  If power/interface selection is correct, check SDA/SCL continuity and the
  physical waveform; an idle-high bus alone does not prove valid transactions.
  A BME280 (0x60) remains unsupported. Successful samples use the existing calibrated JSON.

Build with `bash build-zephyr.sh temperature` in this Part 3 bundle. No Yocto
rebuild is required for this sensor change. The component version remains
1.0.0. Restage the corrected ELF and regenerate recipes before deployment.
Stop the existing MCU owner before replacing its firmware.

Run `python3 tools/test_soft_i2c.py`, `python3 tools/test_sensor_probe.py` and
`python3 tools/check.py` on a host with a C compiler. The software-I2C tests
exercise the actual source with modeled GPIO wires, clock stretching, faults,
recovery, ACK/NACK and full samples at both addresses. These tests and the SDK
cross-build do not establish physical sensor operation on your board.

The host regressions cover a disabled GPIO clock, unreadable identity, rejected
clock/mux/direction writes, pin security and both sensor addresses. The user's
v4 hardware log confirms GPIO2's clock changed from off (`LPM_CUR=0`) to on
(`4`), its version became readable (`0x02010001`), the sensor pins were assigned
to M33 access, and both lines passed the idle-high check. RPMsg also initialized.
The remaining NACK (`-6`) was traced to CSB connected to P11.20 (GND). On
November 13, 2026, the user reported working sensor acquisition after moving
CSB to P11.17 (measured 3.2 V), SDO to GND, and resetting. Firmware v4 was
unchanged. The earlier UART log and subsequent user report are retained in
`validation/gpio-clock-fix/` in the LP directory; no successful sample frame
or i.MX93 cloud telemetry log was supplied with that report.

Sources: [NXP manual, Table 22](https://community.nxp.com/pwmxy87654/attachments/pwmxy87654/imx-processors/240994/1/UM12181.pdf),
[NXP M33 GPIO access setup](https://community.nxp.com/t5/i-MX-Processors-Knowledge-Base/GPIOs-Interrupt-i-MX93-M33/ta-p/1909424),
[Bosch BMP280 I2C connection diagram](https://www.bosch-sensortec.com/media/boschsensortec/downloads/datasheets/bst-bmp280-ds001.pdf).
