# FRDM-IMX93 integration — November 8, 2026

Physical board: **FRDM-IMX93**. Linux machine: `imx93-11x11-lpddr4x-frdm`.
Linux DTB: `imx93-11x11-frdm.dtb`. MCU target: `lp_frdm_imx93/mimx9352/m33`.
These are local FRDM MCU board definitions using the upstream SoC support;
`BOARD_ROOT` is required because the bundle really contains `boards/`.
Do not substitute an EVK machine, DTB or board port.

## Memory and RPMsg contract

| Resource | Address / size |
| --- | --- |
| ITCM MCU load addresses | `0x0ffe0000..0x0fffffff` |
| Zephyr DTCM | `0x20000000..0x2001dfff` |
| vdev0vring0 | `0xa4000000 / 0x8000` |
| vdev0vring1 | `0xa4008000 / 0x8000` |
| vdev0buffer (memory-region index 0) | `0xa4020000 / 0x100000` |
| fixed resource table, shared DDR | `0xa4010000 / 0x1000` |

The corrected Linux tree exposes one RPMsg vdev, with exactly four
`memory-region` entries: buffer, ring 0, ring 1, resource table. The buffer is
named `vdev0buffer`, matching the remoteproc driver's special handling. The
ELF retains its 88-byte template with `__used`; the no-copy patch preserves the
fixed runtime table populated by Linux. The unused second-vdev reservations
are removed to avoid overlapping the DDR table. Both rings have eight entries aligned
to 16 bytes. Firmware rejects unexpected ring addresses before using them.

MU hardware channel 1 carries the four-byte notification payload `id << 16`.
Notification IDs 0/1 are vring IDs, not hardware channel numbers. The receive
worker services both rings with `RSC_NOTIFY_ID_ANY`.

## Boot and peripheral ownership

Part 1 runs `run prepare_mcore; run bsp_bootcmd` through its corrected boot command. Linux must
receive `clk-imx93.mcore_booted`. Linux and the MCU use the same shared-DDR
resource-table address. It is outside Zephyr's TCM reset-clearing range.
Rebuild and flash Part 1, then rebuild Part 2/3 firmware from the matched bundles;
an older TCM-table image or ELF is rejected by the updated guards.

The M33 startup patch removes blanket GPIO1–4 security-policy writes. The
profile disables userspace/TRDC takeover and leaves Linux's isolation policy
intact. Heartbeat initializes no GPIO bank. Temperature enables only GPIO2 for
software I2C on GPIO_IO02/03. Linux releases GPIO2, LPI2C4, LPSPI3 (its chip
select uses GPIO2), UART2 and GPIO LEDs, and keeps the expansion 3.3 V rail on.
The ethosu client is removed so it cannot claim the application M33.

The required boot arguments are **`clk-imx93.mcore_booted`**. An older saved U-Boot environment
can replace the corrected compiled defaults. Follow Part 1's setup page for a
temporary recovery and conditional one-time persistence; no recurring manual
adjustment is needed when the correct flags arrive in Linux. Changing only
`fdtfile` cannot replace EVK boot firmware. Do not preload a demo with `bootaux`.

`check-linux.py` checks the actual Linux compatible string, boot arguments,
exact carveout names/order/ranges, released peripherals and one offline matching
remoteproc before `nxp-mcore load` or the foreground manager changes firmware
selection or starts the MCU. `collect-linux.py` captures a read-only report.
Linux cannot establish the U-Boot control-tree identity or SM binary from this
check; verify the separate Part 1 boot-image report/control DT as well.

## Build and package

Install SDK 0.17.4 with the Arm compiler in the activated Zephyr virtual
environment. Set `ZEPHYR_SDK_INSTALL_DIR` to the installed directory and
`ZEPHYR_WORKSPACE` to the pinned v4.3.0 workspace. Then run:

```bash
bash build-zephyr.sh heartbeat
bash build-zephyr.sh temperature
python3 inspect-elf.py build/temperature/zephyr/zephyr.elf
```

The ELF inspector requires this FRDM application identifier in the allocated
image as well as the expected memory layout. Part 3 stages the temperature
ELF, manager and `check-linux.py` together after inspection. Its recipe generator refuses a missing preflight artifact.
Use a new component version if an older version has already been published.
Do not overwrite immutable S3 artifacts or reuse cached old component bytes.

## Validation limits

Both firmware profiles were cross-compiled with the pinned official sources,
required manifest modules and SDK 0.17.4 on macOS Arm. The real Linux DTS patches
apply and compile, and the preflight accepts their compiled trees with modeled
boot arguments/offline remoteproc state. Host negative checks cover incorrect
board/boot/memory/peripheral settings and invalid ELF layouts. The Yocto build
driver is exercised with real Git fixtures and simulated BitBake tools; no full
Yocto image was built here. The board and transport layout match Part 2;
Part 3 now adds the software-I2C pull-up and recovery fix. Its real staging
flow and host lifecycle tests pass.

The user confirmed i.MX93 Zephyr startup, then observed invalid table reads
from the former TCM location. The corrected shared-DDR DTB/ELF pair passes
host checks and cross-builds; live RPMsg, BMP280 readings, stop/restart and
cloud deployment still require confirmation on this board.

## Primary sources

- [FRDM machine](https://github.com/nxp-imx/meta-imx/blob/1cfbbb8f9ce1d6071775ea6083b79d98597c8206/meta-imx-bsp/conf/machine/imx93-11x11-lpddr4x-frdm.conf)
- [FRDM Linux tree](https://github.com/nxp-imx/linux-imx/blob/df24f9428e38740256a410b983003a478e72a7c0/arch/arm64/boot/dts/freescale/imx93-11x11-frdm.dts)
- [Remoteproc mapping and notifications](https://github.com/nxp-imx/linux-imx/blob/df24f9428e38740256a410b983003a478e72a7c0/drivers/remoteproc/imx_rproc.c)
- [FRDM U-Boot environment](https://github.com/nxp-imx/uboot-imx/blob/4ddbad60eff308a5b356fb9ab8734ac382ddd692/board/freescale/imx93_frdm/imx93_frdm.env)
