# MCU ownership after a reboot — November 9, 2026

The foreground manager's work directory is persistent. A power interruption can
leave owner.json, installed/ and its digest-named ELF even though remoteproc is
offline after the next boot. Older managers rejected that record indefinitely.
This is a host ownership failure before ELF loading, not a BMP280 read failure.

New ownership records include Linux's boot ID. While holding the original
mcore.lock, run requires an offline core and automatically archives a verified
record from a different boot. A same-boot or legacy record without a valid boot
ID requires explicit recovery. No live core is stopped or reset by recovery.

Recovery verifies the selected board/core, exact generated filename and the
recorded SHA256 of any surviving firmware copy. It archives owner.json,
installed/ and that one owned ELF below WORK/recovery/owner-*/. It preserves the
lock inode, unrelated firmware and diagnostic evidence. If the offline core
still selects that owned filename, it restores the recorded prior selection;
a fresh boot's different selection remains unchanged. A running core, live
work-directory lock, symlinked owner/firmware or mismatched digest is rejected.

## Repair an existing image without rebuilding Yocto or the ELF

Copy this board's updated components/firmware_manager.py (or Part 1's copy in
meta-nxp-lp/recipes-core/nxp-lp-tools/files/) to /root/firmware_manager.py on the
board. Keep Greengrass MCU components stopped while recovering a manual test.
Then, as root on the board:

```bash
install -m 0755 /root/firmware_manager.py /usr/libexec/nxp-lp/firmware_manager.py
python3 /usr/libexec/nxp-lp/firmware_manager.py recover --work /var/lib/nxp-mcore-test
nxp-mcore load /root/temperature.elf
journalctl -u nxp-mcore-test.service -b --no-pager -n 80
nxp-mcore status
```

Use the actual temperature ELF path. Open the M7 debug terminal before loading.
For a Part 2 heartbeat, use its heartbeat ELF instead. Updated Part 1 images
also provide nxp-mcore recover as shorthand for recovery of the manual test
work directory. The explicit Python command works with the old nxp-mcore CLI
once its installed manager has been replaced.

For a Greengrass-managed component, first stop/remove that component through
its normal lifecycle, then use its actual recorded FW_WORK rather than
/var/lib/nxp-mcore-test. Keep the installed and component-artifact manager
versions aligned; publish a new immutable component version for an update.
Do not delete the complete work directory or mcore.lock.

For FRDM-IMX93 sensor wiring and software-I2C diagnostics, see SENSOR-PROBE.md.
A manually loaded test must be loaded again after reboot.

Host tests model filesystem ownership, locking, sysfs state and handshakes.
They are not physical board, sensor or remoteproc validation. No MCU source,
ELF or bootloader change is needed for this ownership correction.
