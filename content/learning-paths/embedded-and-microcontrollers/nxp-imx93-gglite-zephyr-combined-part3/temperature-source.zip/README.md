# FRDM-IMX93 application-MCU source bundle

Use the corrected Part 1 image for `imx93-11x11-lpddr4x-frdm`. In the pinned Zephyr v4.3.0
virtual environment, run the native SDK setup helper before building:

```bash
cd "$HOME/nxp-imx93-temperature-part3"
source "$HOME/nxp-imx93-zephyr-venv/bin/activate"
export ZEPHYR_WORKSPACE="$HOME/nxp-imx93-zephyr-workspace"
export ZEPHYR_TOOLCHAIN_VARIANT=zephyr
export ZEPHYR_SDK_INSTALL_DIR="$HOME/zephyr-sdk-0.17.4"
bash setup-zephyr-sdk.sh
bash build-zephyr.sh temperature
python3 inspect-elf.py --require-temperature build/temperature/zephyr/zephyr.elf
```

Use your actual SDK directory. The helper checks the pinned SDK/source,
applies the resource-table no-copy and retention patches, and validates the
TCM ELF. Target: `lp_frdm_imx93/mimx9352/m33` with the supplied local FRDM `boards/` root.
Part 2/3 contain matching corrected transport and board sources. Build
temperature from this Part 3 bundle to include the verified GPIO2 clock/access
and input-path fixes; do not reuse the earlier Part 2 temperature source.
Heartbeat leaves sensor peripherals/GPIO disabled; temperature adds its own overlay.
See FRDM-INTEGRATION.md for this board's startup/HAL fixes and memory map.

The corrected Part 1 boot defaults automatically prepare `clk-imx93.mcore_booted`. Verify
the actual Linux arguments and run `check-linux.py` with the application MCU
offline. A stale saved environment needs the conditional Part 1 recovery;
EVK boot firmware must be replaced as a complete image. Do not preload a demo.

Stage the temperature ELF with `sh tools/stage.sh build/temperature/zephyr/zephyr.elf 313`
using the board's actual Python version. The staged firmware component includes
ELF, manager and `check-linux.py`; recipes require all three. The script rejects
an invalid ELF, heartbeat profile, or pre-v4 temperature ELF before staging.
Run `python3 tools/check.py` for host checks.
Use new immutable component versions when updating an already-published version.
The learning path covers private S3 recipes, permissions and deployment.

Both profiles were cross-compiled and inspected on the authoring host. The user
confirmed i.MX93 RPMsg startup and working BMP280 acquisition with temperature
probe v4 after correcting CSB/SDO wiring. See SENSOR-PROBE.md and the LP's
validation/gpio-clock-fix report for the scope of that hardware result.

## MCU ownership recovery (November 9, 2026)

The shared manager now records the Linux boot ID, recovers verified previous-boot
ownership only with the core offline, and provides explicit recovery for legacy
records. Owned files are archived and the existing lock is retained. See
[MCU-RECOVERY.md](MCU-RECOVERY.md) for updating an existing image and the host
validation limits.

## BMP280 probe diagnostics (November 9, 2026)

The firmware now reports controller readiness, per-address read errors and chip
IDs instead of hiding every discovery failure behind -19. See SENSOR-PROBE.md
for interpretation and validation limits.

## Artifact delivery correction (November 9, 2026)

The release is now 1.0.0, selected once in release.json. Generate recipes with
a real bucket/prefix/board Region, then use artifact-plan.json for uploads and
the read-only role/object preflight. The generated artifact-access.json grants
the existing device role S3 reads for the two component prefixes. Reference
JSON moved to examples/recipes; regenerate any old recipes/ files after
extracting this update. See ARTIFACT-DELIVERY.md for the complete sequence and
403 interpretation. No AWS policy, bucket or deployment was modified here.

## Native build-host tools

Ubuntu x86_64 and arm64/aarch64 are accepted automatically. Activate the pinned
Zephyr Python environment (Python 3.12+) and set ZEPHYR_WORKSPACE, then run
`bash setup-zephyr-sdk.sh` from this bundle. It asks Zephyr v4.3.0's installer
for SDK 0.17.4 and arm-zephyr-eabi; west selects linux-x86_64 or linux-aarch64.
Existing SDKs are checked without replacement. Set ZEPHYR_SDK_INSTALL_DIR to
the installer-reported path, or a fresh host-specific directory when changing
hosts. The build helper checks the SDK metadata, executable tools, compiler
execution and Arm target before patching source or running CMake. The SDK's
host architecture differs from the MCU target: both hosts produce the same
board-specific Arm firmware. macOS x86_64/Arm SDK detection remains available
for Zephyr/staging; Yocto requires Linux. Host-matrix tests mock external tools;
full native Ubuntu arm64 compilation remains an acceptance check.

Staging always selects Linux AArch64 Python wheels for the FRDM board, on either host architecture.

The build also names/checks `.interrupts` for NXP remoteproc. See
[REMOTEPROC-VECTORS.md](REMOTEPROC-VECTORS.md) for updating existing ELFs/images.

The i.MX93 resource table is now reserved at `0xa4010000` in shared DDR.
Rebuild/flash Part 1 and rebuild the Part 2/3 ELFs together; earlier TCM-table
images and firmware are incompatible with this update. Reuse the existing
Yocto WORKDIR and replace the extracted bundle at its existing path.

The Part 3 temperature app retains GPIO pad pull-ups while emulating open-drain
I2C, checks bus idle and attempts bounded SDA recovery. P11.17 is 3.3 V and
P11.20 is GND: CSB goes to 17, SDO to 20 for address 0x76. See SENSOR-PROBE.md.
Build `temperature` from this bundle; Part 2 was intentionally left unchanged.

Patch setup reports `Applied: ...` or `Already applied: ...` without expected
Git error messages. A genuinely conflicting or missing patch stops before the
build and preserves source edits. Run `python3 tools/test_patch_handling.py`
for the real Git fixture checks and mocked build-entry checks.

Temperature probe v4 enables the GPIO2 clock, checks peripheral identity, and
verifies GPIO mux, input-path and direction writes on pins 2/3. Its UART output
distinguishes setup/access failures from a low wire. See SENSOR-PROBE.md.
