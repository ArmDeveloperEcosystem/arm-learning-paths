#!/usr/bin/env bash
set -Eeuo pipefail
trap 'echo "Build failed at line $LINENO" >&2' ERR
usage() {
    cat <<'EOF'
Usage: build-pocketbeagle2.sh [--install-deps] [--configure-only] [--no-sdk]
  --configure-only  Parse all recipes and generate image/SDK dependency graphs.
Environment: WORKDIR (default $HOME/yocto-pocketbeagle2), JOBS (default 4).
Run as an ordinary user on x86_64 Ubuntu 22.04/24.04 or Debian 12.
EOF
}
install_deps=0 configure_only=0 sdk=1
for arg in "$@"; do
    case "$arg" in
        --install-deps) install_deps=1 ;;
        --configure-only|--validate-only) configure_only=1 ;;
        --no-sdk) sdk=0 ;;
        -h|--help) usage; exit 0 ;;
        *) usage >&2; exit 2 ;;
    esac
done
[[ $(uname -s) == Linux && $(uname -m) == x86_64 ]] || {
    echo 'Use an x86_64 Linux host/VM; macOS is not a Yocto build host.' >&2; exit 1;
}
[[ $EUID != 0 ]] || { echo 'Run as a non-root user.' >&2; exit 1; }
JOBS=${JOBS:-4}
[[ $JOBS =~ ^[1-9][0-9]*$ ]] || { echo 'JOBS must be positive.' >&2; exit 1; }
if (( install_deps )); then
    sudo apt-get update
    sudo apt-get install -y build-essential chrpath cpio debianutils diffstat file \
        gawk gcc git iputils-ping libacl1 liblz4-tool locales python3 python3-git \
        python3-jinja2 python3-pexpect python3-pip python3-subunit socat texinfo \
        unzip wget xz-utils zstd bzip2 rsync ca-certificates bc flex bison \
        libssl-dev libncurses-dev util-linux
    sudo locale-gen en_US.UTF-8
fi
export LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8
for tool in git python3 gcc g++ make chrpath cpio diffstat gawk wget zstd rsync flock unshare; do
    command -v "$tool" >/dev/null || { echo "Missing $tool; run --install-deps." >&2; exit 1; }
done
if ! unshare --user --map-root-user --net true; then
    cat >&2 <<'EOF'
BitBake requires usable user/network namespaces on the build host.
On a dedicated Ubuntu 24.04 build host the temporary workaround is:
  sudo sysctl -w kernel.apparmor_restrict_unprivileged_userns=0
This relaxes a host-wide restriction until reboot; see ubuntu24-usernamespaces.txt.
Container policies can also block namespaces. Do not run BitBake with sudo.
EOF
    exit 1
fi
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
WORKDIR=${WORKDIR:-$HOME/yocto-pocketbeagle2}
for path in "$HERE" "$WORKDIR"; do
    [[ $path != *[[:space:]]* && $path != *\"* && $path != *\$* && $path != *\\* ]] || {
        echo 'Use bundle/work paths without whitespace, quotes, dollars or backslashes.' >&2; exit 1;
    }
done
mkdir -p "$WORKDIR"
WORKDIR=$(cd "$WORKDIR" && pwd)
exec 9>"$WORKDIR/.build.lock"
flock -n 9 || { echo 'Another build is running in WORKDIR.' >&2; exit 1; }
mkdir -p "$WORKDIR/sources"
checkout() {
    local name=$1 url=$2 ref=$3 dir="$WORKDIR/sources/$1" wanted
    if [[ ! -d $dir ]]; then
        git init "$dir"
        git -C "$dir" remote add origin "$url"
    fi
    [[ $(git -C "$dir" remote get-url origin) == "$url" ]] || {
        echo "Wrong origin in $dir" >&2; exit 1;
    }
    [[ -z $(git -C "$dir" status --porcelain) ]] || {
        echo "Refusing to overwrite changes in $dir" >&2; exit 1;
    }
    wanted=$(git -C "$dir" rev-parse "$ref^{commit}" 2>/dev/null) || {
        git -C "$dir" fetch --depth 1 origin "$ref"
        wanted=$(git -C "$dir" rev-parse FETCH_HEAD)
    }
    git -C "$dir" checkout --detach "$wanted"
}
# Scarthgap pins audited 2026-10-08; preserve the original build's revisions.
checkout poky https://git.yoctoproject.org/poky 3a3d07f625aee7b87ea1026526b756447c357652
checkout meta-openembedded https://git.openembedded.org/meta-openembedded 0f00f8b9a21950640da8c5707343e5540133f86e
checkout meta-arm https://git.yoctoproject.org/meta-arm 0a4b911d9fd63ab29c4532a907fae3282dbdcfe4
checkout meta-ti https://git.yoctoproject.org/meta-ti a28461e373c3b7c05d7eddb5067a114babcf5537
checkout meta-aws https://github.com/aws4embeddedlinux/meta-aws.git scarthgap-2026.40.0
[[ $(git -C "$WORKDIR/sources/meta-aws" rev-parse HEAD) == 75db4b489c21fe48dd6f0ff3d0f7f52ad67033fb ]] || {
    echo 'Unexpected AWS release tag commit; refusing to change the pinned build.' >&2; exit 1;
}
test -f "$WORKDIR/sources/meta-ti/meta-beagle/conf/machine/pocketbeagle2.conf"
test -f "$WORKDIR/sources/meta-ti/meta-beagle/conf/machine/pocketbeagle2-k3r5.conf"
LAYER="$HERE/meta-pocketbeagle2-dev"
test -f "$LAYER/conf/layer.conf"
unset TEMPLATECONF
set +u
source "$WORKDIR/sources/poky/oe-init-build-env" "$WORKDIR/build"
set -u
cat > conf/bblayers.conf <<EOF
POKY_BBLAYERS_CONF_VERSION = "2"
BBPATH = "\${TOPDIR}"
BBFILES ?= ""
BBLAYERS = " \\
 $WORKDIR/sources/poky/meta \\
 $WORKDIR/sources/poky/meta-poky \\
 $WORKDIR/sources/meta-openembedded/meta-oe \\
 $WORKDIR/sources/meta-openembedded/meta-python \\
 $WORKDIR/sources/meta-openembedded/meta-networking \\
 $WORKDIR/sources/meta-openembedded/meta-multimedia \\
 $WORKDIR/sources/meta-arm/meta-arm-toolchain \\
 $WORKDIR/sources/meta-arm/meta-arm \\
 $WORKDIR/sources/meta-ti/meta-ti-bsp \\
 $WORKDIR/sources/meta-ti/meta-beagle \\
 $WORKDIR/sources/meta-aws \\
 $LAYER \\
"
EOF
cat > conf/local.conf <<EOF
MACHINE = "pocketbeagle2"
DISTRO = "pocketbeagle2-dev"
PACKAGE_CLASSES = "package_rpm"
BB_NUMBER_THREADS = "$JOBS"
PARALLEL_MAKE = "-j $JOBS"
DL_DIR = "$WORKDIR/downloads"
SSTATE_DIR = "$WORKDIR/sstate-cache"
CONF_VERSION = "2"
BB_DISKMON_DIRS = "STOPTASKS,\${TMPDIR},10G,100K STOPTASKS,\${DL_DIR},10G,100K HALT,\${TMPDIR},1G,1K"
require conf/pocketbeagle2-extra.conf
EOF
touch conf/pocketbeagle2-extra.conf
{
    for repo in poky meta-openembedded meta-arm meta-ti meta-aws; do
        printf '%s %s\n' "$repo" "$(git -C "$WORKDIR/sources/$repo" rev-parse HEAD)"
    done
} > "$WORKDIR/sources.lock"
bitbake-layers show-layers
bitbake -p
graph_check() {
    local stage=$1
    shift
    bitbake -g "$@"
    mkdir -p "$WORKDIR/validation/$stage"
    for graph in pn-buildlist recipe-depends.dot task-depends.dot; do
        if [[ -f $graph ]]; then
            cp "$graph" "$WORKDIR/validation/$stage/"
        fi
    done
    if [[ $stage == image ]] && grep -qx 'weston-init' pn-buildlist; then
        echo 'weston-init conflicts with pb2-runtime-config; remove it from your image configuration.' >&2
        exit 1
    fi
}
graph_check image pocketbeagle2-dev-image
if (( sdk )); then
    graph_check sdk pocketbeagle2-dev-image -c populate_sdk
fi
if (( configure_only )); then
    echo "Recipe parsing and requested task graphs passed; compilation has not been tested."
    exit 0
fi
# Check this recipe through packaging first without pulling in all of its
# runtime dependencies. The image build subsequently runs complete package QA.
bitbake pb2-runtime-config pb2-usb-network pb2-m4-tools -c package
# Validate the external tracer against this BSP's kernel before the full image.
bitbake lttng-modules
# Configure/build the selected desktop backends and clients before the image.
bitbake weston
bitbake pocketbeagle2-dev-image
if (( sdk )); then
    bitbake pocketbeagle2-dev-image -c populate_sdk
fi
echo "Image: $WORKDIR/build/deploy-ti/images/pocketbeagle2/"
echo "SDK:   $WORKDIR/build/deploy-ti/sdk/"
echo "Layer revisions: $WORKDIR/sources.lock"
echo "Dependency graphs: $WORKDIR/validation/"
