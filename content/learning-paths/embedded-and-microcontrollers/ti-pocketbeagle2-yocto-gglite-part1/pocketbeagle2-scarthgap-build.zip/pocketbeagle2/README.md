# PocketBeagle 2 Yocto development image

Builds a microSD image for PocketBeagle 2 (the `pocketbeagle2` machine in
`meta-ti/meta-beagle`), with an optional cross-compilation SDK. The image runs
64-bit Linux on the AM6254 Cortex-A53 cores and includes:

- AWS IoT Greengrass nucleus lite 2.6.0, with its systemd units enabled
- Development tools
- USB Ethernet and SSH access over the USB-C port
- A headless Weston Wayland desktop

The image doesn't target the original PocketBeagle. It contains no device
credentials. You supply them after boot.

## Contents

| Item | Purpose |
| --- | --- |
| `build-pocketbeagle2.sh` | Fetches the pinned Yocto layers, configures the build, and builds the image |
| `meta-pocketbeagle2-dev/` | Yocto layer with the distro, image, and board-specific recipes |
| `ubuntu24-usernamespaces.txt` | Fix for BitBake namespace errors on Ubuntu 24.04 |
| `AUDIT.txt` | Pinned source revisions and what was validated |

Keep these together in a path without spaces. The script finds the layer
relative to its own location.

## Build

You need Ubuntu 24.04 on x86_64 or aarch64, a non-root user with sudo access, a
Linux filesystem such as ext4, 16 GB or more of RAM, and 250–400 GB of free disk.

```bash
chmod +x build-pocketbeagle2.sh
WORKDIR="$HOME/yocto-pocketbeagle2" ./build-pocketbeagle2.sh --install-deps --configure-only
WORKDIR="$HOME/yocto-pocketbeagle2" JOBS=4 ./build-pocketbeagle2.sh --no-sdk
```

| Option | Effect |
| --- | --- |
| `--install-deps` | Installs host packages with `sudo apt-get` and enables `en_US.UTF-8` |
| `--configure-only` | Parses recipes and writes dependency graphs. Nothing is compiled. |
| `--no-sdk` | Skips the cross-compilation SDK |

| Variable | Default | Meaning |
| --- | --- | --- |
| `WORKDIR` | `$HOME/yocto-pocketbeagle2` | Build tree. Reuse it to reuse downloads and shared state. |
| `JOBS` | `4` | Parallel BitBake tasks and make jobs. Allow about 3 GB of RAM per job. |

The first build takes several hours. The script:

- Checks that BitBake can create user and network namespaces, and stops with
  diagnostics if it can't. See `ubuntu24-usernamespaces.txt`.
- Clones the pinned layers and records their revisions in `$WORKDIR/sources.lock`.
- Regenerates `local.conf` and `bblayers.conf`. Put persistent settings in
  `$WORKDIR/build/conf/pocketbeagle2-extra.conf`.
- Packages `pb2-runtime-config`, `pb2-usb-network`, and `pb2-m4-tools`, then builds
  the LTTng modules, Weston, and the image (and the SDK unless you pass `--no-sdk`).
- Refuses to overwrite edits in upstream checkouts and rejects concurrent runs in
  one `WORKDIR`.

Run the script as a regular user. Don't use `sudo` or run BitBake as root.

Results:

| Path | Contents |
| --- | --- |
| `$WORKDIR/build/deploy-ti/images/pocketbeagle2/` | `pocketbeagle2-dev-image-pocketbeagle2*.wic.xz` and its `.wic.bmap` |
| `$WORKDIR/build/deploy-ti/sdk/` | SDK installer, if built |
| `$WORKDIR/validation/` | Dependency graphs from `--configure-only` |

Graph generation checks dependencies only. It doesn't download or compile
sources, assemble the root filesystem, or run the result.

## Image contents

The image includes GCC/G++, binutils, make, CMake, Ninja, Meson, Autotools,
pkg-config, Git, ccache, Python (with pip and PyYAML), Node.js/npm, Rust/Cargo, and
Go. Debugging and profiling tools include GDB/gdbserver, strace, ltrace, Valgrind,
and perf. It also includes Vim, Nano, tmux, htop, networking tools, OpenSSL,
GPIO/I2C/USB/device-tree tools, and RPM package management with no online feed.
The `dev-pkgs` and `dbg-pkgs` groups add development headers and debug symbols.

This is a development image. It uses `debug-tweaks`, which allows passwordless
root login. Set a password after boot, and configure accounts and remove
`debug-tweaks` before you use the image outside a controlled network. Large
native builds are limited by the board's RAM, so use the SDK for those.

## Write the image to a card

Use a microSD card of 32 GB or larger. Writing erases the card. Replace `/dev/sdX`
with the whole card device, not a partition:

```bash
sudo apt-get install bmap-tools
lsblk -o NAME,SIZE,MODEL,MOUNTPOINTS
sudo umount /dev/sdX1        # repeat for each mounted partition
cd "$HOME/yocto-pocketbeagle2/build/deploy-ti/images/pocketbeagle2"
sudo bmaptool copy --bmap pocketbeagle2-dev-image-pocketbeagle2.rootfs.wic.bmap \
  pocketbeagle2-dev-image-pocketbeagle2.rootfs.wic.xz /dev/sdX
sync
```

The image has a `boot` and a `root` partition, plus `tiboot3.bin`, `tispl.bin`,
and `u-boot.img`. Insert the card, and connect the board's USB-C port to your
computer with a data cable. A 3.3 V debug UART helps with boot diagnostics. The
serial console is 115200 8N1 on `ttyS2`. See the
[PocketBeagle 2 Quick Start Guide](https://docs.beagleboard.org/boards/pocketbeagle-2/02-quick-start.html).

## USB Ethernet and SSH

At boot, `pb2-usb-gadget.service` creates an Ethernet gadget on the USB-C device
controller. The board interface is `pb2usb0`:

| Endpoint | IPv4 address | Configuration |
| --- | --- | --- |
| PocketBeagle 2 | `192.168.7.2/24` | Static, set by networkd |
| Host computer | `192.168.7.1/24` | Offered by the board's DHCP server |

The DHCP server sends no router or DNS address, so the USB link gives local access
only and doesn't replace the host's Internet connection. The default protocol is
CDC-ECM. CDC-NCM and RNDIS are available for Windows hosts. To switch, set
`USB_NET_MODE=ncm` (or `rndis`) in `/etc/default/pb2-usb-gadget` and restart
`pb2-usb-gadget.service` from a serial console, because the restart disconnects USB
Ethernet. A USB serial console starts on `ttyGS0`. Set `USB_ACM=0` to turn it off.

Find the new interface on the host with `ip -br link`, then connect:

```bash
ssh root@192.168.7.2
```

The root password is initially empty. Run `passwd` on first login. For key-based
access, run `ssh-copy-id root@192.168.7.2` on the host. The board generates its SSH
host keys, so check the new key from the console after you reflash.

To diagnose problems on the board:

```bash
pb2-network-status
networkctl status pb2usb0
systemctl status pb2-usb-gadget.service sshd.service
journalctl -u pb2-usb-gadget.service -u systemd-networkd.service -u sshd.service -b
```

If no USB network interface appears, check the data cable, the host driver, and
the gadget log. Don't load the legacy `g_ether`, `g_multi`, or `g_serial` modules.
Only one gadget can bind the controller.

## Internet access for the board

The board needs outbound Internet access for AWS IoT. Use one of these options:

- **USB Ethernet adapter.** On a USB host port, the image includes drivers for
  common CDC, ASIX, and Realtek adapters, plus Realtek firmware. Networkd gets an
  address, gateway, and DNS server by DHCP for interfaces named `en*`, `eth*`, or
  `usb*`.
- **Sharing the host's connection** over the USB gadget, as follows for an Ubuntu
  host that uses NetworkManager.

Use a serial console for these changes. On the board, as root, keep the static
`192.168.7.2/24` address and add the host as gateway and DNS server:

```bash
mkdir -p /etc/systemd/network/20-pb2-usb.network.d
cat > /etc/systemd/network/20-pb2-usb.network.d/50-host-internet.conf <<'EOF'
[Network]
DHCP=no
DHCPServer=no
DNS=192.168.7.1

[Route]
Destination=0.0.0.0/0
Gateway=192.168.7.1
Metric=200
EOF
networkctl reload
networkctl reconfigure pb2usb0
```

On the host, set `PB2_USB_IF` to the USB interface from `ip -br link`, then create
or update the shared profile:

```bash
export PB2_USB_IF=YOUR_USB_INTERFACE
nmcli connection show pb2-usb-share || \
  sudo nmcli connection add type ethernet ifname "$PB2_USB_IF" con-name pb2-usb-share
sudo nmcli connection modify pb2-usb-share \
  connection.interface-name "$PB2_USB_IF" \
  ipv4.method shared ipv4.addresses 192.168.7.1/24 \
  ipv4.never-default yes ipv6.method disabled
sudo nmcli connection up pb2-usb-share ifname "$PB2_USB_IF"
cat "/sys/class/net/$PB2_USB_IF/carrier"    # must print 1
ping -c 3 192.168.7.2
```

If the carrier is `0`, the USB link is down. Changing routes or DNS won't fix that.
Check `pb2usb0` and `pb2-usb-gadget.service` from the serial console, run
`ip link set dev pb2usb0 up` if the interface is down, and reconnect the cable.
To undo sharing, delete `50-host-internet.conf` on the board and run
`networkctl reload` and `networkctl reconfigure pb2usb0`. Before you provision
Greengrass, check routing, DNS, the clock, and outbound TLS.

## Greengrass provisioning

Follow the pinned upstream
[Greengrass nucleus lite provisioning guide](https://github.com/aws-greengrass/aws-greengrass-lite/blob/v2.6.0/docs/Provisioning.md)
to create an IoT thing, an active certificate attached to the thing and its IoT
policy, a token-exchange IAM role trusted by `credentials.iot.amazonaws.com`, and
an IoT role alias. Use a unique identity for each board. Keep AWS access keys and
device private keys out of the source tree, `local.conf`, images, and shared
sstate.

The helper `pb2-provision-greengrass` installs the credentials and writes the
initial device settings. Run it as root on the board with your values:

```bash
pb2-provision-greengrass REGION THING_NAME \
  DATA_ENDPOINT CREDENTIAL_ENDPOINT ROLE_ALIAS_NAME \
  /path/to/device.pem.crt /path/to/private.pem.key /path/to/AmazonRootCA1.pem
systemctl status --with-dependencies greengrass-lite.target
systemctl --failed
journalctl -u ggl.core.iotcored.service -u ggl.core.ggdeploymentd.service -b
```

The helper installs the private key with mode `0600` and `ggcore` ownership. It
merges the settings into the existing `/etc/greengrass/config.d/greengrass-lite.yaml`
and keeps the other settings, then restarts the Greengrass target. The runtime
doesn't sort directory entries, so a second override file isn't reliable. Components
run as `gg_component:gg_component`. The image includes `libcgroup`, which supplies
`cgexec` for the health daemon, plus `sudo` and CA certificates. The helper is for
initial provisioning. Persistent cloud configuration can take precedence over the
initial YAML. Deploy a simple component first to confirm the setup.

## Weston desktop

`pb2-weston.service` runs a headless, software-rendered Weston as the `weston`
account. Its socket is `/run/pb2-weston/wayland-0`. The board has no built-in
monitor connector, so a physical display needs suitable hardware and a device-tree
configuration.

```bash
systemctl status pb2-weston.service
sudo -u weston env XDG_RUNTIME_DIR=/run/pb2-weston WAYLAND_DISPLAY=wayland-0 \
  weston-terminal
```

For remote access, create a certificate on the board and switch Weston to its RDP
backend, bound to localhost:

```bash
install -d -o weston -g weston -m 0700 /etc/weston-rdp
openssl req -x509 -newkey rsa:2048 -nodes -days 365 -subj '/CN=pocketbeagle2' \
  -keyout /etc/weston-rdp/key.pem -out /etc/weston-rdp/cert.pem
chown weston:weston /etc/weston-rdp/*.pem
chmod 0600 /etc/weston-rdp/key.pem
mkdir -p /etc/systemd/system/pb2-weston.service.d
cat > /etc/systemd/system/pb2-weston.service.d/backend.conf <<'EOF'
[Service]
ExecStart=
ExecStart=/usr/bin/weston --backend=rdp-backend.so --renderer=pixman --address=127.0.0.1 --width=1024 --height=600 --socket=wayland-0 --rdp-tls-cert=/etc/weston-rdp/cert.pem --rdp-tls-key=/etc/weston-rdp/key.pem --config=/etc/xdg/weston/weston.ini
EOF
systemctl daemon-reload
systemctl restart pb2-weston.service
```

Weston's RDP server has no user authentication, so keep the localhost binding and
use an SSH tunnel from your computer. Then connect an RDP client to
`127.0.0.1:13389` and check the certificate:

```bash
ssh -L 13389:127.0.0.1:3389 root@BOARD_IP
```

## Customization and the SDK

Add packages in the layer, or in `$WORKDIR/build/conf/pocketbeagle2-extra.conf`:

```bitbake
IMAGE_INSTALL:append = " your-package"
```

The SDK installer is a `.sh` file. Install it on a Linux host with the same
architecture as the build host, then source its `environment-setup-*` file to set
`$CC`, `$CXX`, and the sysroot for cross compilation.

## M4 core support

The kernel enables the AM6254 M4 remoteproc node, reserves `0x9cb00000`–`0x9da00000`
for its DMA and firmware regions, and keeps MCU_UART0 disabled in Linux. These
changes need the image's kernel and device tree. Copying only the `pb2-m4` helper
onto an older image isn't enough.

```bash
pb2-m4 status
pb2-m4 load /root/firmware.elf
```

Load firmware only while the M4 is offline. `pb2-m4` validates the ELF header,
installs a separate firmware file, and asks remoteproc to start it. It doesn't
select `remoteproc0` by index, replace the default TI firmware, stop a running
core, or start firmware automatically. The driver's stop operation expects a
firmware shutdown handshake, so restart the board before loading again. If the M4
stays attached to the bootloader, a cold power cycle may be needed. Don't force an
unbind or reset the system-management R5 core.

MCU_UART0 TX is pin P2.07. Connect it to the RX pin of a 3.3 V USB-UART adapter and
share a common ground, and leave the adapter's power lead disconnected. This
console is separate from Linux's MAIN_UART6 debug port.

## Sources

[Scarthgap host requirements](https://docs.yoctoproject.org/scarthgap/ref-manual/system-requirements.html),
[TI BSP metadata](https://git.yoctoproject.org/meta-ti/),
[AWS metadata](https://github.com/aws4embeddedlinux/meta-aws),
[LTTng modules releases](https://lttng.org/files/lttng-modules/),
[PocketBeagle 2 hardware](https://docs.beagleboard.org/boards/pocketbeagle-2/03-design-and-specifications.html).
