# PocketBeagle 2 Scarthgap development image

Builds a microSD image and Linux cross SDK for the `pocketbeagle2` machine in
`meta-ti/meta-beagle`. The machine includes the K3 R5 bootloader multiconfig.
The included custom layer installs the native C AWS IoT Greengrass Nucleus Lite
2.6.0 runtime with enabled systemd units, development tools, and a Weston Wayland
desktop. It targets PocketBeagle 2, not the original PocketBeagle.

Nucleus Lite implements a subset of the Java nucleus; verify compatibility with
your components. Device credentials are supplied after boot, not baked into the
image. Weston defaults to a software-rendered headless desktop. A physical
display requires appropriate hardware and a device-tree configuration; the bare
board has no built-in monitor connector. RDP access is described below.

## Update an existing build

The October 14 bundle includes every previous recipe/configuration correction,
USB Ethernet gadget startup, DHCP for the attached computer, common USB Ethernet
adapter drivers/Realtek firmware, and automatically enabled OpenSSH, networkd and
resolved. It retains the same pinned upstream sources to reuse your build cache.
Weston includes `egl` and its `libxml2` dependency; LTTng modules uses 2.13.23 for
the pinned Linux 6.12.57 kernel.

Back up your custom bundle changes, then extract the complete archive into the
parent of `pocketbeagle2/`. Keep the build directory, downloads and sstate:

```bash
cp -a /home/danson/ti/pocketbeagle2 \
  "/home/danson/ti/pocketbeagle2.backup-$(date +%Y%m%d-%H%M%S)"
unzip -o /path/to/pocketbeagle2-scarthgap-usb-ssh.zip -d /home/danson/ti
cd /home/danson/ti/pocketbeagle2
WORKDIR=/home/danson/yocto-pocketbeagle2 JOBS=4 ./build-pocketbeagle2.sh
```

The script regenerates its build configuration, validates dependencies, packages
both custom integration recipes, and builds LTTng, Weston, the image and SDK.
The new kernel fragment changes the kernel configuration, so expect a kernel
rebuild. Existing downloads and sstate are reused; a full cleanup is unnecessary.
Store persistent custom build settings in `build/conf/pocketbeagle2-extra.conf`.
The temporary Weston `egl`/`libxml2` overrides from the earlier troubleshooting
reply are now included in the layer and can be removed from that extra file.

For manual continuation from an already configured environment:

```bash
source /home/danson/yocto-pocketbeagle2/sources/poky/oe-init-build-env \
  /home/danson/yocto-pocketbeagle2/build
bitbake pb2-runtime-config pb2-usb-network -c package
bitbake lttng-modules weston
bitbake pocketbeagle2-dev-image
bitbake pocketbeagle2-dev-image -c populate_sdk
```

## Build host and commands

Use an x86_64 Ubuntu 22.04/24.04 or Debian 12 host/VM, a non-root build account,
and a Linux filesystem such as ext4. Prefer 16–32 GB RAM and 250–400 GB free disk.
Four parallel jobs are the default. A full image and SDK can take hours.
macOS users should build inside an x86_64 Linux VM or on a remote Linux machine,
with the build files on its Linux filesystem. Copy this entire bundle, including
the layer, to a fixed path without spaces.

```bash
cd /home/danson/ti/pocketbeagle2
chmod +x build-pocketbeagle2.sh
WORKDIR="$HOME/yocto-pocketbeagle2" JOBS=4 \
  ./build-pocketbeagle2.sh --install-deps
```

The dependency option uses `sudo apt-get`; the build itself runs as your normal
user. Ensure `en_US.UTF-8` is enabled (`sudo dpkg-reconfigure locales` if needed).
If Ubuntu 24.04 blocks user namespaces, see `ubuntu24-usernamespaces.txt`. The
script diagnoses this before cloning or compiling and does not modify host
security settings automatically.

```bash
./build-pocketbeagle2.sh --configure-only  # parsing and image/SDK dependency graphs
./build-pocketbeagle2.sh --no-sdk          # compile the image, skip SDK
```

The dedicated `$WORKDIR/build/conf/local.conf` and `bblayers.conf` are regenerated.
Put persistent custom settings in `conf/pocketbeagle2-extra.conf`. Downloads and
sstate are reused, upstream local edits are protected, and concurrent script
runs are rejected. `sources.lock` records resolved revisions. Avoid using the
script's directory for an unrelated Yocto configuration.

The script checks recipe parsing and generates the requested dependency/task
graphs in `$WORKDIR/validation`, builds `pb2-runtime-config` and `pb2-usb-network`
through packaging,
then builds the LTTng kernel modules and Weston before the complete image and SDK.
Graph generation cannot verify source downloads, compilation or root filesystem
assembly.

## Development tools

The image includes GCC/G++, binutils, make, C/C++ development headers, CMake,
Ninja, Meson, Autoconf, Automake, Libtool, pkg-config, Git, ccache, Python and its
standard modules/pip/setuptools/PyYAML, Node.js/npm, Rust/Cargo and Go. It includes
GDB/gdbserver, strace/ltrace, Valgrind, perf, kernel development sources, Yocto's
SDK/debug/profiling/test tool groups, Vim/Nano, tmux, htop, networking tools,
OpenSSL, GPIO/I2C/USB/device-tree tools, kernel modules and RPM package management.
`dev-pkgs` and `dbg-pkgs` add development headers and debug symbols for installed
packages. Add project-specific libraries or tools to the packagegroup as needed;
“all developer tools” is not a finite set of every package in every layer.

Use a 32 GB or larger microSD card and check the image size. Large native builds
are constrained by the board's RAM; prefer the SDK for those. This is a development
image with `debug-tweaks` and initial passwordless root access. Set a password
after boot and remove that feature for deployment outside a controlled development
environment. RPM support does not configure an online package feed.

## Flash and boot

TI deployment paths:

```text
$WORKDIR/build/deploy-ti/images/pocketbeagle2/
$WORKDIR/build/deploy-ti/sdk/
```

Use `pocketbeagle2-dev-image-pocketbeagle2*.wic.xz` and its matching `.wic.bmap`.
The image contains boot and root partitions plus `tiboot3.bin`, `tispl.bin` and
`u-boot.img`. On a Linux flashing host:

```bash
sudo apt-get install bmap-tools
lsblk -o NAME,SIZE,MODEL,MOUNTPOINTS
# Unmount the card's partitions. Verify /dev/sdX is the entire microSD card!
# This erases the selected device.
sudo bmaptool copy --bmap /path/to/image.wic.bmap /path/to/image.wic.xz /dev/sdX
sync
```

Insert the card and connect the board's USB-C port to your computer with a
USB data cable. Supply adequate power for the board and attached peripherals.
A 3.3 V debug UART or the board's debug connection is useful for boot diagnostics;
the target serial console is 115200 8N1 on `ttyS2`.

## USB Ethernet and SSH

At boot, `pb2-usb-gadget.service` creates a configfs Ethernet gadget on the
USB-C device controller. Both pinned PocketBeagle 2 device trees already select
peripheral mode for USB0. The USB1 host port can support an adapter on an
appropriate cape. [PocketBeagle 2 connection guide](https://docs.beagleboard.org/boards/pocketbeagle-2/02-quick-start.html).

The default protocol is CDC-ECM for Linux/macOS. CDC-NCM and legacy RNDIS are
selectable without rebuilding. The device has a stable serial number and two
locally administered MAC addresses derived from its board serial or machine-id.
The board interface is `pb2usb0`:

| Endpoint | IPv4 address | Configuration |
| --- | --- | --- |
| PocketBeagle 2 | `192.168.7.2/24` | Static, assigned by networkd |
| Attached computer | `192.168.7.1/24` | Offered by the board's DHCP server |

The DHCP server does not advertise a default router or DNS server, so the USB
link does not replace your computer's existing Internet connection. This gives
local access; Internet sharing is a separate step below.
The image masks `systemd-networkd-wait-online.service` so an optional cable or
adapter does not delay boot; the networking and SSH services still start.

Once the host detects USB Ethernet and receives its address:

```bash
ssh root@192.168.7.2
```

This remains a development image with `debug-tweaks` and an initially empty root
password. On the first connection run `passwd`. Subsequent password logins use
that password. For key-based access, run on the computer:

```bash
ssh-keygen -t ed25519                    # if you do not already have an SSH key
ssh-copy-id root@192.168.7.2
ssh root@192.168.7.2
scp ./your-file root@192.168.7.2:/root/
sftp root@192.168.7.2
```

Host keys are generated on the board. After reflashing, verify its new key using
the console before replacing a previous known-hosts entry. For deployment,
configure accounts/authorized keys and remove `debug-tweaks` in the image recipe.

Linux hosts normally detect CDC Ethernet automatically. Identify the new
interface with `ip -br link`; NetworkManager should use automatic IPv4/DHCP.
On a host without a DHCP client, assign the host address manually:

```bash
sudo ip address replace 192.168.7.1/24 dev YOUR_USB_INTERFACE
sudo ip link set YOUR_USB_INTERFACE up
ssh root@192.168.7.2
```

On macOS, select the new USB Ethernet network service and automatic IPv4/DHCP.
If necessary, use a manual address of `192.168.7.1`, mask `255.255.255.0`, with
router/DNS fields empty for this local link.

For Windows 11, set `USB_NET_MODE=ncm` on the board in
`/etc/default/pb2-usb-gadget`. Windows 10 can use `USB_NET_MODE=rndis`, subject to
the host's driver availability. Change the mode from a serial console, since
restarting the gadget disconnects USB Ethernet:

```bash
sed -i 's/^USB_NET_MODE=.*/USB_NET_MODE=ncm/' /etc/default/pb2-usb-gadget
systemctl restart pb2-usb-gadget.service
```

Reconnect the cable if needed, leave IPv4 addressing automatic on the computer,
and SSH to `192.168.7.2`. RNDIS mode includes Microsoft OS descriptors. To select
a Windows protocol before building, edit the bundled
`recipes-connectivity/pb2-usb-network/files/pb2-usb-gadget.defaults`.
The USB serial function is enabled by default and starts a login console on
`ttyGS0`; set `USB_ACM=0` to omit it. `USB_UDC` is available for systems with more
than one device controller.

Target diagnostics:

```bash
pb2-network-status
networkctl status pb2usb0
systemctl status pb2-usb-gadget.service sshd.service
journalctl -u pb2-usb-gadget.service -u systemd-networkd.service -u sshd.service -b
ls /sys/class/udc
lsusb
ss -ltn 'sport = :22'
```

If no USB NIC appears, check the data cable, host driver, controller list and
gadget log. Do not load legacy `g_ether`, `g_multi` or `g_serial` alongside this
configfs service; only one gadget can bind a controller. The kernel fragment
uses TI's `KERNEL_CONFIG_FRAGMENTS` mechanism and checks the resulting settings.

## USB adapters and Internet connectivity

For a USB Ethernet adapter connected to a USB **host** port/cape, this image
includes usbnet, CDC Ethernet/NCM/RNDIS-host, ASIX AX8817x/AX88179 and Realtek
RTL8152/RTL8153 drivers, Realtek NIC firmware, `ip`, `ethtool`, `lsusb` and
`tcpdump`. Networkd obtains a DHCP address, gateway and DNS for interfaces named
`en*`, `eth*` or `usb*`. It handles the gadget's `pb2usb0` separately. SSH listens
on port 22 on the board's available addresses. Inspect them using `ip -br address`.

To share an Ubuntu computer's Internet connection over the gadget, preserve
the board's static 192.168.7.2/24 management address. Use a serial console for
the change; do not rely on the SSH session being reconfigured. Verify USB carrier
on the host first (`ip -br link`, `/sys/class/net/INTERFACE/carrier`). An `UP`
interface with a `linkdown` route has no working link; restore carrier before
troubleshooting IP routing, NAT or DNS.

On the board as root, replace any earlier DHCP-client sharing drop-in with:

```bash
mkdir -p /etc/systemd/network/20-pb2-usb.network.d
cat > /etc/systemd/network/20-pb2-usb.network.d/50-host-internet.conf <<'EOF'
[Network]
DHCP=no
DHCPServer=no
DNS=192.168.7.1

[Route]
Destination=0.0.0.0/0
Gateway=192.168.7.1
Metric=200
EOF
networkctl reload
networkctl reconfigure pb2usb0
ip link set dev pb2usb0 up
ip -4 address show dev pb2usb0
```

Keep the bundled `Address=192.168.7.2/24` in the main `.network` file. On the
Ubuntu host, set `PB2_USB_IF` to the interface shown by `ip -br link`. Create the
profile only if it is missing, then configure the existing or newly created
profile:

```bash
export PB2_USB_IF=YOUR_USB_INTERFACE
nmcli connection show pb2-usb-share
# Run this next command only if the profile does not exist:
sudo nmcli connection add type ethernet ifname "$PB2_USB_IF" con-name pb2-usb-share
sudo nmcli connection modify pb2-usb-share \
  connection.interface-name "$PB2_USB_IF" \
  ipv4.method shared ipv4.addresses 192.168.7.1/24 \
  ipv4.never-default yes ipv6.method disabled
sudo nmcli connection up pb2-usb-share ifname "$PB2_USB_IF"
cat "/sys/class/net/$PB2_USB_IF/carrier"
ping -c 3 192.168.7.2
ssh root@192.168.7.2
```

Carrier must be 1 and local SSH must work before testing Internet access.
If carrier is 0, inspect `pb2usb0` and `pb2-usb-gadget.service` on the board through
its serial console. Bring the board interface up with
`ip link set dev pb2usb0 up` if it is administratively down. Reconnect the data
cable if necessary. Restarting the gadget disconnects USB serial as well as USB
Ethernet, so use a separate debug UART for that operation. Leave the host's
upstream network connection unchanged.

On macOS or Windows, enable Internet sharing to the USB network using that
platform's controls. Their gateway/subnet can differ, so the Ubuntu static
settings do not apply unchanged. Inspect the board through a serial console
and configure its address, gateway and DNS for the selected host network.

To restore the board's original local USB DHCP-server configuration, remove
only this sharing drop-in from the board's serial console, then reload networkd:

```bash
rm /etc/systemd/network/20-pb2-usb.network.d/50-host-internet.conf
networkctl reload
networkctl reconfigure pb2usb0
```

Switch the Ubuntu USB profile back to DHCP only after the board's server is
restored. This removes Internet sharing; it is not a repair for a missing USB
carrier. Verify routing, DNS, clock synchronization and outbound TLS before
provisioning Greengrass.

## Greengrass provisioning

Follow the pinned upstream [Nucleus Lite provisioning guide](https://github.com/aws-greengrass/aws-greengrass-lite/blob/v2.6.0/docs/Provisioning.md)
on an administrative workstation. Create an IoT thing, an ACTIVE certificate
attached to that thing and its IoT policy, a token-exchange IAM role trusted by
`credentials.iot.amazonaws.com`, and an IoT role alias. The IoT policy must permit
the required IoT/Greengrass operations and certificate-based role assumption;
the IAM role needs access to your component artifacts and services.
Use unique identities per board. Keep AWS access keys and device private keys
out of the source tree, `local.conf`, images and shared sstate.

Discover endpoints and obtain the root CA on the workstation:

```bash
aws iot describe-endpoint --region us-east-1 --endpoint-type iot:Data-ATS \
  --query endpointAddress --output text
aws iot describe-endpoint --region us-east-1 --endpoint-type iot:CredentialProvider \
  --query endpointAddress --output text
curl -fL https://www.amazontrust.com/repository/AmazonRootCA1.pem -o AmazonRootCA1.pem
```

Transfer the credentials securely to the target. Run as root with your values:

```bash
pb2-provision-greengrass us-east-1 pocketbeagle2-001 \
  YOUR_DATA_ENDPOINT.iot.us-east-1.amazonaws.com \
  YOUR_CREDENTIAL_ENDPOINT.credentials.iot.us-east-1.amazonaws.com \
  GreengrassV2TokenExchangeRoleAlias \
  /path/to/device.pem.crt /path/to/private.pem.key /path/to/AmazonRootCA1.pem
systemctl status --with-dependencies greengrass-lite.target
systemctl --failed
journalctl -u ggl.core.iotcored.service -u ggl.core.ggdeploymentd.service -b
```

The helper installs the key with mode 0600 and `ggcore` ownership, writes initial
device settings into the existing `greengrass-lite.yaml`, preserves its other
settings, and restarts the Greengrass target. Nucleus Lite does not sort directory
entries, so this avoids relying on a second file's override order. Components use
`gg_component:gg_component`. The image includes `libcgroup` (which supplies
`cgexec`, used by the runtime's health daemon), `sudo` and CA certificates.
The helper is for initial provisioning; persistent cloud configuration can take
precedence over initial YAML, so use the documented workflow for fleet rotation.
Confirm the core device appears in AWS and deploy a simple component first.

For local recipes/artifacts laid out according to the upstream guide:

```bash
sudo -u ggcore ggl-cli deploy --recipe-dir /path/to/recipes \
  --artifacts-dir /path/to/artifacts --add-component com.example.HelloWorld=1.0.0
```

## Weston Wayland desktop

`pb2-weston.service` starts the desktop without requiring a panel. Its runtime
socket is `/run/pb2-weston/wayland-0` and it runs as the `weston` account.

```bash
systemctl status pb2-weston.service
journalctl -u pb2-weston.service -b
sudo -u weston env XDG_RUNTIME_DIR=/run/pb2-weston WAYLAND_DISPLAY=wayland-0 \
  weston-terminal
```

For remote access, create TLS material on the board and switch to the built-in
RDP backend, bound only to localhost:

```bash
install -d -o weston -g weston -m 0700 /etc/weston-rdp
openssl req -x509 -newkey rsa:2048 -nodes -days 365 -subj '/CN=pocketbeagle2' \
  -keyout /etc/weston-rdp/key.pem -out /etc/weston-rdp/cert.pem
chown weston:weston /etc/weston-rdp/*.pem
chmod 0600 /etc/weston-rdp/key.pem
mkdir -p /etc/systemd/system/pb2-weston.service.d
cat > /etc/systemd/system/pb2-weston.service.d/backend.conf <<'EOF'
[Service]
ExecStart=
ExecStart=/usr/bin/weston --backend=rdp-backend.so --renderer=pixman --address=127.0.0.1 --width=1024 --height=600 --socket=wayland-0 --rdp-tls-cert=/etc/weston-rdp/cert.pem --rdp-tls-key=/etc/weston-rdp/key.pem --config=/etc/xdg/weston/weston.ini
EOF
systemctl daemon-reload
systemctl restart pb2-weston.service
```

Weston's RDP server lacks conventional user authentication. Keep the localhost
binding and use an SSH tunnel from the workstation:

```bash
ssh -L 13389:127.0.0.1:3389 root@BOARD_IP
```

Connect an RDP client to `127.0.0.1:13389` and verify the certificate. For an LCD,
first configure the correct panel/cape DT and verify a connected DRM connector
under `/sys/class/drm`. Stop the headless service and run Weston from a local
console with a valid seat/logind session:

```bash
systemctl stop pb2-weston.service
weston --backend=drm-backend.so --renderer=pixman
```

A persistent physical-display service also needs the appropriate VT/seat setup.

## SDK, customization and verification limits

Install the generated SDK `*.sh` on an x86_64 Linux host, then source its
`environment-setup-*` file. `$CC`, `$CXX` and the sysroot are configured for cross
compilation. This is a Linux SDK, not a macOS SDK. Add packages in the layer or
in `build/conf/pocketbeagle2-extra.conf`:

```bitbake
IMAGE_INSTALL:append = " your-package"
```

See `AUDIT.txt` for exactly what was checked. Successful dependency graph generation
verifies dependency providers, not that every upstream source compiles. A full
image build, SDK build, SD boot and AWS connection are separate validation steps.

Sources: [Scarthgap host requirements](https://docs.yoctoproject.org/scarthgap/ref-manual/system-requirements.html),
[user/group recipe configuration](https://docs.yoctoproject.org/scarthgap/ref-manual/classes.html#useradd),
[TI BSP metadata](https://git.yoctoproject.org/meta-ti/),
[AWS metadata](https://github.com/aws4embeddedlinux/meta-aws),
[LTTng modules release archive](https://lttng.org/files/lttng-modules/),
[PocketBeagle 2 hardware](https://docs.beagleboard.org/boards/pocketbeagle-2/03-design-and-specifications.html).

## Learning Path Part 2: AM6254 M4 support (October 16, 2026)

This bundle additionally enables the AM6254 M4 remoteproc node, reserves
0x9cb00000–0x9da00000 for its DMA and firmware regions, keeps MCU_UART0 disabled
in Linux, and installs `pb2-m4`. These changes need a new kernel and DTB boot;
copying only the helper onto an earlier image is insufficient.

Run `pb2-m4 status` on the board. Use `pb2-m4 load /root/zephyr.elf` only when the
M4 is offline. It validates the ELF header, installs a separate firmware file,
and asks remoteproc to start it. It does not select remoteproc0 by index, replace
the default TI firmware, stop a running core, or enable automatic startup.
The pinned driver's stop operation expects a firmware shutdown handshake.
The Part 2 UART heartbeat does not implement that protocol, so use a board
restart before another load. A cold power cycle may be needed if the M4 remains
bootloader-owned/attached; do not force an unbind or reset the system-management R5.

Part 2 uses Zephyr v4.3.0 and the pocketbeagle_2/am6254/m4 target. MCU_UART0 TX is
P2.07; connect it to a 3.3 V USB-UART adapter RX plus common ground. Keep the
adapter power lead disconnected. The MCU console is separate from Linux's
MAIN_UART6 debug port. See the Part 2 Learning Path for the sample and workflow.
