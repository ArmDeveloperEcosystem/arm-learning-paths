SUMMARY = "PocketBeagle 2 target development tools"
LICENSE = "MIT"
# This group includes machine packages and libraries whose runtime names can
# be remapped. It must not inherit allarch from the packagegroup class.
PACKAGE_ARCH = "${MACHINE_ARCH}"
inherit packagegroup
RDEPENDS:${PN} = " \
    packagegroup-core-buildessential cmake ninja meson pkgconfig \
    autoconf automake libtool git git-perltools ccache patch diffutils \
    python3 python3-modules python3-pip python3-setuptools python3-pyyaml \
    nodejs nodejs-npm packagegroup-rust-sdk-target packagegroup-go-sdk-target \
    gdb gdbserver strace ltrace valgrind perf kernel-devsrc \
    bash bash-completion vim nano less file which tree tmux htop \
    coreutils findutils util-linux procps iproute2 ethtool iputils \
    curl wget openssl openssl-bin ca-certificates tcpdump rsync \
    usbutils i2c-tools libgpiod libgpiod-tools dtc \
    tar gzip bzip2 xz zip unzip sudo systemd-analyze \
"
