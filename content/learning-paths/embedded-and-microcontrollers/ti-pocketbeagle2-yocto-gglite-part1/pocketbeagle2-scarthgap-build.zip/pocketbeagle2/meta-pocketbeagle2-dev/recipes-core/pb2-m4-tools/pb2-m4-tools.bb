SUMMARY = "PocketBeagle 2 M4 status and initial firmware loading helper"
LICENSE = "MIT"
LIC_FILES_CHKSUM = "file://${COMMON_LICENSE_DIR}/MIT;md5=0835ade698e0bcf8506ecda2f7b4f302"
SRC_URI = "file://pb2-m4"
S = "${WORKDIR}"
RDEPENDS:${PN} = "bash python3-core coreutils"
do_install() {
    install -d ${D}${sbindir}
    install -m 0755 ${WORKDIR}/pb2-m4 ${D}${sbindir}/pb2-m4
}
