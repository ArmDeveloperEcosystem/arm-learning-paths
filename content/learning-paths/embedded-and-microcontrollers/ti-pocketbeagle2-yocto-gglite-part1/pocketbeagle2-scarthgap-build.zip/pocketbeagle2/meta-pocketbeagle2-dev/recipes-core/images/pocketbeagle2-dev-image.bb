SUMMARY = "PocketBeagle 2 development image with native Greengrass and Wayland"
LICENSE = "MIT"
inherit core-image
IMAGE_FEATURES += "package-management ssh-server-openssh tools-sdk tools-debug tools-profile tools-testapps dev-pkgs dbg-pkgs debug-tweaks"
IMAGE_INSTALL:append = " packagegroup-pocketbeagle2-dev greengrass-lite pb2-runtime-config pb2-usb-network pb2-m4-tools weston weston-examples kernel-modules linux-firmware-rtl-nic"
DEPENDS += "systemd-systemctl-native"
IMAGE_ROOTFS_EXTRA_SPACE = "2097152"
IMAGE_OVERHEAD_FACTOR = "1.3"

pb2_enable_remote_services() {
    for unit in systemd-networkd.service systemd-resolved.service sshd.service; do
        systemctl --root=${IMAGE_ROOTFS} enable "$unit"
    done
    # USB and adapter links are optional; do not hold boot waiting for a cable.
    # Scarthgap's image-construction helper supports mask, not disable.
    systemctl --root=${IMAGE_ROOTFS} mask systemd-networkd-wait-online.service
}
ROOTFS_POSTPROCESS_COMMAND += "pb2_enable_remote_services; "
