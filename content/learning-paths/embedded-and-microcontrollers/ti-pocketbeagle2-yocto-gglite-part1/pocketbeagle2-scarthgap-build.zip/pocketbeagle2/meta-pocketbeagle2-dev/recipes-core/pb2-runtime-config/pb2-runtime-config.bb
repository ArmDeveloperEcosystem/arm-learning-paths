SUMMARY = "PocketBeagle 2 desktop and Greengrass provisioning helpers"
LICENSE = "MIT"
LIC_FILES_CHKSUM = "file://${COMMON_LICENSE_DIR}/MIT;md5=0835ade698e0bcf8506ecda2f7b4f302"
SRC_URI = "file://pb2-provision-greengrass file://pb2-weston.service file://weston.ini"
S = "${WORKDIR}"
inherit systemd useradd
USERADD_PACKAGES = "${PN}"
# render is not supplied by base-passwd. Groups are created before users.
GROUPADD_PARAM:${PN} = "--system render"
USERADD_PARAM:${PN} = "--system --home /home/weston --user-group --shell /bin/sh -G video,input,render weston"
SYSTEMD_SERVICE:${PN} = "pb2-weston.service"
SYSTEMD_AUTO_ENABLE = "enable"
RDEPENDS:${PN} = "bash python3-core python3-io python3-pyyaml greengrass-lite weston"
do_install() {
    install -d ${D}${sbindir} ${D}${systemd_system_unitdir} ${D}${sysconfdir}/xdg/weston
    install -m 0755 ${WORKDIR}/pb2-provision-greengrass ${D}${sbindir}/
    install -m 0644 ${WORKDIR}/pb2-weston.service ${D}${systemd_system_unitdir}/
    install -m 0644 ${WORKDIR}/weston.ini ${D}${sysconfdir}/xdg/weston/
    install -d -m 0750 ${D}/home/weston
    chown weston:weston ${D}/home/weston
}
FILES:${PN}:append = " /home/weston"
CONFFILES:${PN} = "${sysconfdir}/xdg/weston/weston.ini"
