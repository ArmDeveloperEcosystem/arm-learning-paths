# pb2-runtime-config supplies the compositor service, user and weston.ini.
# The default recommendation would install competing services/configuration.
RRECOMMENDS:${PN}:remove = "weston-init"

# Weston 13 enables test-junit-xml by default. Keep its dependency explicit
# rather than relying on another package to stage libxml-2.0.pc transitively.
DEPENDS += "libxml2"
