# The runtime's health daemon executes cgexec; these are runtime dependencies.
RDEPENDS:${PN}:append = " libcgroup sudo ca-certificates"
do_install:append() {
    sed -i 's/ggcore:ggcore/gg_component:gg_component/g' ${D}${sysconfdir}/greengrass/config.d/greengrass-lite.yaml
}
