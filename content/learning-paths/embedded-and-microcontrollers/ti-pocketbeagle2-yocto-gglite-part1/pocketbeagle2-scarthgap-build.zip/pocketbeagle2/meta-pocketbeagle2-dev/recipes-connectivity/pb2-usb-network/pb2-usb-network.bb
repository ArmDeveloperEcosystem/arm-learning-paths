SUMMARY = "PocketBeagle 2 USB Ethernet gadget and remote access configuration"
LICENSE = "MIT"
LIC_FILES_CHKSUM = "file://${COMMON_LICENSE_DIR}/MIT;md5=0835ade698e0bcf8506ecda2f7b4f302"
SRC_URI = "file://pb2-usb-gadget file://pb2-network-status \
           file://pb2-usb-gadget.service file://pb2-usb-gadget.defaults \
           file://10-pb2-usb.link file://20-pb2-usb.network file://70-pb2-wired.network"
S = "${WORKDIR}"
inherit systemd
SYSTEMD_SERVICE:${PN} = "pb2-usb-gadget.service"
SYSTEMD_AUTO_ENABLE = "enable"
# networkd/resolved belong to systemd in this pinned Scarthgap recipe.
RDEPENDS:${PN} = "bash coreutils kmod iproute2 systemd \
                 util-linux-mount util-linux-mountpoint util-linux-flock \
                 openssh-sshd openssh-keygen openssh-ssh openssh-scp \
                 openssh-sftp openssh-sftp-server usbutils ethtool"
do_install() {
    install -d ${D}${sbindir} ${D}${sysconfdir}/default ${D}${sysconfdir}/systemd/network ${D}${systemd_system_unitdir}
    install -m 0755 ${WORKDIR}/pb2-usb-gadget ${WORKDIR}/pb2-network-status ${D}${sbindir}/
    install -m 0644 ${WORKDIR}/pb2-usb-gadget.defaults ${D}${sysconfdir}/default/pb2-usb-gadget
    install -m 0644 ${WORKDIR}/10-pb2-usb.link ${WORKDIR}/20-pb2-usb.network ${WORKDIR}/70-pb2-wired.network ${D}${sysconfdir}/systemd/network/
    install -m 0644 ${WORKDIR}/pb2-usb-gadget.service ${D}${systemd_system_unitdir}/
}
CONFFILES:${PN} = "${sysconfdir}/default/pb2-usb-gadget ${sysconfdir}/systemd/network/10-pb2-usb.link ${sysconfdir}/systemd/network/20-pb2-usb.network ${sysconfdir}/systemd/network/70-pb2-wired.network"
