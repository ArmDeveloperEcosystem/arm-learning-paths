FILESEXTRAPATHS:prepend := "${THISDIR}/files:"
SRC_URI:append:pocketbeagle2 = " file://pb2-usb-network.cfg file://pb2-m4.cfg file://0001-pb2-zephyr-m4.patch"
# This BSP uses setup-defconfig.inc, not kernel-yocto's fragment discovery.
KERNEL_CONFIG_FRAGMENTS:append:pocketbeagle2 = " ${WORKDIR}/pb2-usb-network.cfg ${WORKDIR}/pb2-m4.cfg"

do_configure:append:pocketbeagle2() {
    for fragment in pb2-usb-network.cfg pb2-m4.cfg; do
        for setting in $(sed -n '/^CONFIG_/p' ${WORKDIR}/$fragment); do
            if ! grep -qx "$setting" ${B}/.config; then
                bbfatal "Required setting from $fragment missing from kernel .config: $setting"
            fi
        done
    done
}
