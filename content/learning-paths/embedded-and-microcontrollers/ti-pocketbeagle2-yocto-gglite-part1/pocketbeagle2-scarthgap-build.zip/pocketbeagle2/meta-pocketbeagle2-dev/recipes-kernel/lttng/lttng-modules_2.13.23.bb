SECTION = "devel"
SUMMARY = "LTTng kernel tracer with Linux 6.12 API support"
HOMEPAGE = "https://lttng.org/"
LICENSE = "LGPL-2.1-only & GPL-2.0-only & MIT"
LIC_FILES_CHKSUM = "file://LICENSE;md5=8d0d9f08888046474772a5d745d89d6a"

# Keep the 2.13 series used by Scarthgap's LTTng tools/UST. The pinned
# PocketBeagle 2 kernel is 6.12.57; upstream 2.13.12 predates its APIs.
inherit module
require recipes-kernel/lttng/lttng-platforms.inc

SRC_URI = "https://lttng.org/files/${BPN}/${BPN}-${PV}.tar.bz2"
SRC_URI[sha256sum] = "3d23df7532a6039080e361cb40ef45fa5cd46fa70ac3c680bfe22184cab7d774"

export INSTALL_MOD_DIR = "kernel/lttng-modules"
EXTRA_OEMAKE += "KERNELDIR='${STAGING_KERNEL_DIR}'"
MODULES_MODULE_SYMVERS_LOCATION = "src"

do_install:append() {
    if [ -d ${D}${nonarch_base_libdir} ]; then
        find ${D}${nonarch_base_libdir} -depth -type d -empty -exec rmdir {} \;
    fi
}

python do_package:prepend() {
    if not os.path.exists(os.path.join(d.getVar('D'), d.getVar('nonarch_base_libdir')[1:], 'modules')):
        bb.warn("%s: no modules were created; check CONFIG_TRACEPOINTS in the kernel." % d.getVar('PN'))
}
