# Part 2 integration validation

Checks performed on October 16, 2026:

- Built the supplied heartbeat with Zephyr tag `v4.3.0`, Zephyr SDK `0.17.4`,
  GNU Arm compiler `12.2.0`, and the `pocketbeagle_2/am6254/m4` target.
  The build used the locally installed SDK on a macOS Arm64 host; the tutorial
  describes an Ubuntu development host.
- Confirmed the ELF is 32-bit little-endian Arm. Its load segments fit the M4's
  internal SRAM or the Linux firmware carveout. Its `.resource_table` section is
  16 bytes at `0x9cc00000` and declares no resources.
- Applied the device-tree patch to BeagleBoard Linux commit
  `2eea568f445af33f3280261904bf1027b02512d8` and compiled the AM6254 DTB with
  the pinned includes and DTC 1.8.1. Existing device-tree warnings remain;
  compilation succeeded. This is not a kernel build or binding-schema check.
- Ran five loader fixture tests: select the M4 by name, reject missing/ambiguous
  devices, refuse owned cores without modifying them, reject invalid ELF input,
  and use a separate firmware filename for an offline core. Fixtures emulate
  the start transition; they do not execute firmware or call a remoteproc driver.
- Checked Bash syntax, front matter, page order, local links, and archive contents.

Run `python3 tools/pocketbeagle2/test_m4_helper.py` from the repository root to
repeat the fixture tests. Run `python3 tools/pocketbeagle2/package_bundle.py` to
rebuild the Part 1 download after changing these sources. The sample archive is
built from Part 2's `heartbeat/` source directory.

A complete updated BitBake image/SDK build, kernel boot, M4 firmware start, UART
output, restart behavior, and simultaneous Greengrass execution still require
validation on physical revision A1 hardware. Do not treat compilation or fixture
tests as proof of those outcomes. The historical `AUDIT.txt` predates these changes.
