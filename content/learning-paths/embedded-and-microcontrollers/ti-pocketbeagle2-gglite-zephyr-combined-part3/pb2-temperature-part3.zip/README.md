# PocketBeagle 2 external temperature — Part 3 source bundle

Follow the accompanying learning path in order: introduction, board preparation,
firmware build, bridge packaging, S3/component publishing, deployment, and removal.

This example uses the supplied external BMP280 over I2C at 3.3 V. The firmware
detects one BMP280 at address 0x76 or 0x77 and applies its factory calibration.

- `firmware/`: Zephyr v4.3.0 source for `pocketbeagle_2/am6254/m4`; software I2C,
  compensated BMP280 temperature, UART JSON, zero-entry resource table, and Linux
  mailbox shutdown acknowledgment.
- `components/`: firmware manager, UART/Greengrass IPC bridge, and bridge lifecycle.
- `tools/stage.sh`: stage the built ELF and download pinned Linux AArch64 wheels.
- `tools/make_recipes.py`: generate two full recipes for your actual S3 bucket.
- `tools/upload.py`: upload staged artifacts, refusing existing object keys.
- `tools/check.py`: host checks with simulated remoteproc and IPC; no AWS actions.
- `tools/check_bmp280.c`: host-compiled check of calibration decoding and integer
  compensation against fixed and floating-point references, run by `check.py`.
- `recipes/`: reference recipes with an example bucket and the verified wheel names.
  Regenerate them for your bucket after staging real artifacts.

There are no certificates, AWS credentials, Python wheels, or prebuilt firmware in
this bundle. The firmware still needs a real Zephyr build and board acceptance.
