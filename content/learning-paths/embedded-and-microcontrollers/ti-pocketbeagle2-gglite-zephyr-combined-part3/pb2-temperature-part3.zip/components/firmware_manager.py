#!/usr/bin/env python3
"""Run in the foreground of the Greengrass component's systemd unit."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import struct
import threading


def validate_elf(path):
    header = path.read_bytes()[:20]
    if (len(header) != 20 or header[:6] != b"\x7fELF\x01\x01"
            or struct.unpack_from("<H", header, 18)[0] != 40):
        raise ValueError("Expected an unstripped 32-bit little-endian Arm ELF")


def find_m4(root=Path("/sys/class/remoteproc")):
    matches = [p for p in root.glob("remoteproc*")
               if "5000000" in (p / "name").read_text()]
    if len(matches) != 1:
        raise RuntimeError(f"Expected exactly one AM62 M4, found {matches}")
    return matches[0]


def stage(artifact, work):
    validate_elf(artifact)
    installed = work / "installed"
    installed.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(artifact, installed / "zephyr.elf")
    return installed / "zephyr.elf"


def run(artifact, work):
    stopping = threading.Event()
    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, lambda *_: stopping.set())
    # Leave the lock inode in Greengrass's work directory to avoid lock races.
    with (work / "m4.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        core = find_m4()
        owner_file = work / "owner.json"
        if owner_file.exists():
            raise RuntimeError("Unclean previous exit; follow the recovery instructions")
        state = lambda: (core / "state").read_text().strip()
        if state() != "offline":
            raise RuntimeError("M4 must be offline; never take over other firmware")
        firmware = stage(artifact, work)
        digest = hashlib.sha256(firmware.read_bytes()).hexdigest()
        name = f"pb2-gg-temperature-{digest[:16]}.elf"
        destination = Path("/lib/firmware") / name
        previous = (core / "firmware").read_text().strip()
        owner = {"core": str(core), "firmware": name, "previous": previous,
                 "sha256": digest}
        started = False
        selected = False
        copied = False
        # Record ownership before any sysfs mutation. Preserve it on cleanup error.
        owner_file.write_text(json.dumps(owner) + "\n")
        try:
            if destination.exists():
                raise RuntimeError(f"Refusing to overwrite {destination}")
            temporary = work / "firmware.tmp"
            shutil.copyfile(firmware, temporary)
            os.chmod(temporary, 0o644)
            # /lib/firmware can be on a different filesystem from work.
            with destination.open("xb") as target, temporary.open("rb") as source:
                copied = True
                shutil.copyfileobj(source, target)
            os.chmod(destination, 0o644)
            temporary.unlink()
            (core / "firmware").write_text(name)
            selected = True
            started = True  # cleanup also checks state if start raises
            (core / "state").write_text("start")
            if state() != "running":
                raise RuntimeError("M4 did not enter running state")
            print(f"M4 started firmware={name} sha256={digest}", flush=True)
            while not stopping.wait(1):
                if state() != "running":
                    raise RuntimeError("M4 stopped unexpectedly")
        finally:
            if started and state() == "running":
                if (core / "firmware").read_text().strip() != name:
                    raise RuntimeError("Firmware ownership changed; refusing to stop it")
                (core / "state").write_text("stop")
            if state() != "offline":
                raise RuntimeError("M4 is not offline; preserve owner record for recovery")
            if selected:
                (core / "firmware").write_text(previous)
            # Remove only a file we created, never an existing firmware collision.
            if copied:
                destination.unlink(missing_ok=True)
            (work / "firmware.tmp").unlink(missing_ok=True)
            shutil.rmtree(work / "installed", ignore_errors=True)
            owner_file.unlink()
            print("M4 offline; firmware selection restored; installed files removed", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=("install", "run"))
    parser.add_argument("--artifact", type=Path, required=True)
    parser.add_argument("--work", type=Path, required=True)
    args = parser.parse_args()
    args.work.mkdir(parents=True, exist_ok=True)
    if args.phase == "install":
        stage(args.artifact, args.work)
        print("Firmware staged; remoteproc has not been started", flush=True)
    else:
        run(args.artifact, args.work)
