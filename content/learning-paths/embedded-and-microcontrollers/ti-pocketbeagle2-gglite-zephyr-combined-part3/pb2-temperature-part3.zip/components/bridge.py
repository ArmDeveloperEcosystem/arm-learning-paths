#!/usr/bin/env python3
"""Read newline-delimited MCU JSON and publish through Greengrass IPC."""
import argparse
from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import select
import signal
import termios
import threading
import time

TOPIC = "ti/pocketbeagle2/temperature/external"


def decode_frame(line, thing_name, boot_id):
    data = json.loads(line)
    if not isinstance(data, dict) or data.get("type") != "pb2.external.temperature":
        raise ValueError("Not external temperature telemetry")
    if type(data.get("schema")) is not int or data["schema"] != 1:
        raise ValueError("Unsupported telemetry schema")
    for key in ("seq", "uptime_ms", "temperature_uC"):
        if type(data.get(key)) is not int:
            raise ValueError(f"Invalid {key}")
    if data["seq"] < 0 or data["uptime_ms"] < 0:
        raise ValueError("Negative counter")
    if not -40_000_000 <= data["temperature_uC"] <= 85_000_000:
        raise ValueError("Temperature outside BMP280 range")
    return {
        "schemaVersion": 1, "thingName": thing_name,
        "sensor": "BMP280", "location": "external",
        "temperatureC": data["temperature_uC"] / 1_000_000,
        "sequence": data["seq"], "mcuUptimeMs": data["uptime_ms"],
        "linuxBootId": boot_id,
        "timestamp": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
    }


def open_uart(path):
    fd = os.open(path, os.O_RDWR | os.O_NOCTTY | os.O_NONBLOCK)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        termios.tcsetattr(fd, termios.TCSANOW, [
            0, 0, termios.CS8 | termios.CREAD | termios.CLOCAL, 0,
            termios.B115200, termios.B115200,
            [b"\0"] * termios.NCCS,
        ])
        termios.tcflush(fd, termios.TCIFLUSH)
        return fd
    except BaseException:
        os.close(fd)
        raise


def run(serial, thing):
    # Imported only after the lifecycle script has installed the offline wheels.
    from awsiot.greengrasscoreipc.clientv2 import GreengrassCoreIPCClientV2
    from awsiot.greengrasscoreipc.model import QOS
    stopping = threading.Event()
    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, lambda *_: stopping.set())
    boot_id = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    fd = open_uart(serial)
    client = None
    pending = b""
    last_sample = time.monotonic()
    try:
        while not stopping.is_set():
            if not select.select([fd], [], [], 1)[0]:
                if time.monotonic() - last_sample > 20:
                    print("No valid external temperature sample for 20 seconds", flush=True)
                    last_sample = time.monotonic()
                continue
            chunk = os.read(fd, 4096)
            if not chunk:
                raise RuntimeError("UART closed")
            pending += chunk
            while b"\n" in pending:
                line, pending = pending.split(b"\n", 1)
                if len(line) > 1024:
                    continue
                try:
                    record = decode_frame(line, thing, boot_id)
                except (ValueError, UnicodeDecodeError):
                    print(f"Ignored UART diagnostic or invalid frame: {line[:160]!r}", flush=True)
                    continue
                last_sample = time.monotonic()
                payload = json.dumps(record, separators=(",", ":"), allow_nan=False).encode()
                try:
                    if client is None:
                        client = GreengrassCoreIPCClientV2()
                    client.publish_to_iot_core_async(
                        topic_name=TOPIC, qos=QOS.AT_LEAST_ONCE,
                        payload=payload).result(timeout=5)
                    print(f"Published sequence={record['sequence']} topic={TOPIC}", flush=True)
                except Exception as exc:
                    print(f"Publish failed; dropping this sample: {exc}", flush=True)
                    if client is not None:
                        client.close()
                        client = None
                    stopping.wait(1)
                if stopping.is_set():
                    break
            if len(pending) > 1024:
                pending = b""  # bound memory for damaged or noisy UART input
    finally:
        try:
            if client is not None:
                client.close()
        finally:
            os.close(fd)
        print("Bridge stopped; IPC connection and UART closed", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--serial", required=True)
    parser.add_argument("--thing", required=True)
    args = parser.parse_args()
    run(args.serial, args.thing)
