#!/bin/sh
set -eu
phase=$1
artifacts=$2
work=$3
digest=$(sha256sum "$artifacts/bridge.py" "$artifacts/bridge_lifecycle.sh" \
    "$artifacts/"*.whl | sha256sum | cut -c 1-16)
app="$work/installed-$digest"

install_app() {
    if [ ! -f "$app/.complete" ]; then
        rm -rf "$app"
        mkdir -p "$app"
        python3 -m pip install --no-index --no-compile --no-cache-dir \
            --find-links "$artifacts" --target "$app" awsiotsdk==1.26.0
        cp "$artifacts/bridge.py" "$app/bridge.py"
        touch "$app/.complete"
    fi
}

case "$phase" in
    install) install_app ;;
    run)
        # Keep this shell as the foreground supervisor. systemd sends TERM to
        # the entire control group, including Python; wait before cleanup.
        child=
        finish() {
            trap '' TERM INT
            if [ -n "$child" ]; then
                kill -TERM "$child" 2>/dev/null || true
                wait "$child" 2>/dev/null || true
            fi
            rm -rf "$app"
        }
        trap finish EXIT
        trap 'exit 0' TERM INT
        install_app
        PYTHONPATH="$app" python3 -u "$app/bridge.py" --serial "$4" --thing "$5" &
        child=$!
        wait "$child"
        ;;
    *) echo "Unknown lifecycle phase" >&2; exit 2 ;;
esac
