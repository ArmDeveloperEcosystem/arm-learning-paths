/* SPDX-License-Identifier: Apache-2.0 */
#include <stdint.h>

/* Linux resource table v1, zero entries, two reserved words. */
__attribute__((section(".pb2_resource_table"), used, aligned(4)))
const uint32_t pb2_resource_table[] = {1, 0, 0, 0};
