/* SPDX-License-Identifier: Apache-2.0 */
#ifndef PB2_BMP280_TEMPERATURE_H
#define PB2_BMP280_TEMPERATURE_H

#include <stdint.h>

struct bmp280_temperature_calibration {
    uint16_t t1;
    int16_t t2;
    int16_t t3;
};

static inline int16_t bmp280_signed_le16(const uint8_t *bytes)
{
    int32_t value = (uint16_t)bytes[0] | ((uint16_t)bytes[1] << 8);
    return (int16_t)(value >= 32768 ? value - 65536 : value);
}

static inline struct bmp280_temperature_calibration
bmp280_decode_temperature_calibration(const uint8_t bytes[6])
{
    return (struct bmp280_temperature_calibration) {
        .t1 = (uint16_t)bytes[0] | ((uint16_t)bytes[1] << 8),
        .t2 = bmp280_signed_le16(bytes + 2),
        .t3 = bmp280_signed_le16(bytes + 4),
    };
}

/* Bosch's fixed-point temperature compensation, with wider intermediates.
 * adc is the unsigned 20-bit sample; result is signed hundredths of Celsius.
 * Signed right shifts use the arithmetic behavior of the Arm/GCC toolchain.
 */
static inline int32_t bmp280_temperature_centi_c(
    uint32_t adc, const struct bmp280_temperature_calibration *cal)
{
    int64_t delta = (int64_t)(adc >> 3) - 2 * (int64_t)cal->t1;
    int64_t linear = (delta * cal->t2) >> 11;
    delta = (int64_t)(adc >> 4) - cal->t1;
    int64_t quadratic = (((delta * delta) >> 12) * cal->t3) >> 14;
    return (int32_t)(((linear + quadratic) * 5 + 128) >> 8);
}

#endif
