/* SPDX-License-Identifier: Apache-2.0 */
#include <errno.h>
#include <string.h>
#include <zephyr/kernel.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/mbox.h>
#include <zephyr/sys/printk.h>
#include "bmp280_temperature.h"

#define SCL 16 /* P2.09 MCU_GPIO0_16 */
#define SDA 15 /* P2.11 MCU_GPIO0_15 */
#define BMP280_CHIP_ID 0x58
#define ECHO_REQUEST 0xffffff03U
#define ECHO_REPLY 0xffffff04U
#define SHUTDOWN 0xffffff14U
#define SHUTDOWN_ACK 0xffffff15U
#define TRY(call) do { int rc_ = (call); if (rc_ < 0) return rc_; } while (0)

static const struct device *const gpio = DEVICE_DT_GET(DT_NODELABEL(gpio0));
static const struct device *const mailbox = DEVICE_DT_GET(DT_NODELABEL(mbox0));
K_SEM_DEFINE(shutdown_sem, 0, 1);
static uint8_t sensor_address;
static struct bmp280_temperature_calibration calibration;

/* This GPIO driver has no hardware open-drain support. Release HIGH by
 * switching to INPUT; drive only LOW. External pull-ups are mandatory. */
static int line(unsigned int pin, bool high)
{
    int rc = gpio_pin_configure(gpio, pin, high ? GPIO_INPUT : GPIO_OUTPUT_LOW);
    k_busy_wait(5);
    return rc;
}

static int scl_high(void)
{
    TRY(line(SCL, true));
    for (int n = 0; n < 200; n++) {
        int value = gpio_pin_get(gpio, SCL);
        if (value < 0) return value;
        if (value) return 0;
        k_busy_wait(5);
    }
    return -ETIMEDOUT;
}

static int start(void)
{
    TRY(line(SDA, true));
    TRY(scl_high());
    int value = gpio_pin_get(gpio, SDA);
    if (value < 0) return value;
    if (!value) return -EBUSY;
    TRY(line(SDA, false));
    return line(SCL, false);
}

static int stop(void)
{
    TRY(line(SCL, false));
    TRY(line(SDA, false));
    TRY(scl_high());
    return line(SDA, true);
}

static int write_byte(uint8_t value)
{
    for (int bit = 7; bit >= 0; bit--) {
        TRY(line(SDA, (value & BIT(bit)) != 0));
        TRY(scl_high());
        TRY(line(SCL, false));
    }
    TRY(line(SDA, true));
    TRY(scl_high());
    int nack = gpio_pin_get(gpio, SDA);
    TRY(line(SCL, false));
    return nack < 0 ? nack : (nack ? -ENXIO : 0);
}

static int read_byte(uint8_t *value, bool last)
{
    *value = 0;
    TRY(line(SDA, true));
    for (int bit = 7; bit >= 0; bit--) {
        TRY(scl_high());
        int state = gpio_pin_get(gpio, SDA);
        if (state < 0) return state;
        *value |= state ? BIT(bit) : 0;
        TRY(line(SCL, false));
    }
    TRY(line(SDA, last)); /* ACK intermediate bytes, NACK final byte */
    TRY(scl_high());
    TRY(line(SCL, false));
    return line(SDA, true);
}

static int sensor_read(uint8_t reg, uint8_t *bytes, size_t count)
{
    TRY(start());
    TRY(write_byte(sensor_address << 1));
    TRY(write_byte(reg));
    TRY(start());
    TRY(write_byte((sensor_address << 1) | 1));
    for (size_t n = 0; n < count; n++) {
        TRY(read_byte(bytes + n, n + 1 == count));
    }
    return stop();
}

static int sensor_write(uint8_t reg, uint8_t value)
{
    TRY(start());
    TRY(write_byte(sensor_address << 1));
    TRY(write_byte(reg));
    TRY(write_byte(value));
    return stop();
}

static int wait_sensor_idle(uint8_t mask)
{
    for (int n = 0; n < 30; n++) {
        uint8_t status;
        TRY(sensor_read(0xf3, &status, 1));
        if (!(status & mask)) return 0;
        k_msleep(2);
    }
    return -ETIMEDOUT;
}

static int configure_sensor(void)
{
    uint8_t found = 0;
    int matches = 0;
    /* Only the BMP280's two legal addresses; reject a BME280 (ID 0x60). */
    for (uint8_t address = 0x76; address <= 0x77; address++) {
        uint8_t id;
        sensor_address = address;
        int rc = sensor_read(0xd0, &id, 1);
        if (rc == 0 && id == BMP280_CHIP_ID) {
            found = address;
            matches++;
        }
        if (rc < 0) (void)stop();
    }
    if (matches != 1) {
        sensor_address = 0;
        return matches ? -EINVAL : -ENODEV;
    }
    sensor_address = found;
    TRY(sensor_write(0xe0, 0xb6)); /* soft reset */
    k_msleep(3);
    TRY(wait_sensor_idle(0x01)); /* NVM calibration copy complete */
    uint8_t bytes[6];
    TRY(sensor_read(0x88, bytes, sizeof(bytes)));
    bool all_zero = true, all_ff = true;
    for (size_t n = 0; n < sizeof(bytes); n++) {
        all_zero = all_zero && bytes[n] == 0;
        all_ff = all_ff && bytes[n] == 0xff;
    }
    if (all_zero || all_ff) return -EIO;
    calibration = bmp280_decode_temperature_calibration(bytes);
    TRY(sensor_write(0xf5, 0x00)); /* IIR off; remain in sleep until triggered */
    printk("External BMP280 found at I2C address 0x%02x\n", sensor_address);
    return 0;
}

static int temperature(int32_t *micro_c)
{
    /* Forced measurement: temperature x1, pressure skipped, then sleep. */
    TRY(sensor_write(0xf4, 0x21));
    k_msleep(10);
    TRY(wait_sensor_idle(0x09)); /* measuring and im_update clear */
    uint8_t bytes[3];
    TRY(sensor_read(0xfa, bytes, sizeof(bytes)));
    uint32_t raw = ((uint32_t)bytes[0] << 12) |
                   ((uint32_t)bytes[1] << 4) | (bytes[2] >> 4);
    if (raw == 0x80000) return -EIO; /* skipped/uninitialized sample */
    int32_t centi_c = bmp280_temperature_centi_c(raw, &calibration);
    if (centi_c < -4000 || centi_c > 8500) return -ERANGE;
    *micro_c = centi_c * 10000; /* transport scale, native result is 0.01 C */
    return 0;
}

static int send_mailbox(uint32_t value)
{
    struct mbox_msg msg = {.data = &value, .size = sizeof(value)};
    return mbox_send(mailbox, 0, &msg); /* M4 -> Linux FIFO 0 */
}

static void on_mailbox(const struct device *dev, mbox_channel_id_t channel,
                       void *user, struct mbox_msg *msg)
{
    ARG_UNUSED(dev); ARG_UNUSED(channel); ARG_UNUSED(user);
    uint32_t value;
    if (!msg || msg->size != sizeof(value)) return;
    memcpy(&value, msg->data, sizeof(value));
    if (value == ECHO_REQUEST) (void)send_mailbox(ECHO_REPLY);
    if (value == SHUTDOWN) k_sem_give(&shutdown_sem);
}

static void shutdown_core(void)
{
    /* Finish peripheral activity before ACK. Linux also checks CPU WFI. */
    if (sensor_address) (void)sensor_write(0xf4, 0x00); /* sleep */
    (void)line(SDA, true);
    (void)line(SCL, true);
    while (send_mailbox(SHUTDOWN_ACK) == -EBUSY) k_busy_wait(10);
    (void)irq_lock();
    __asm__ volatile ("dsb sy" ::: "memory");
    for (;;) __asm__ volatile ("wfi" ::: "memory"); /* Linux asserts reset. */
}

int main(void)
{
    if (!device_is_ready(gpio) || !device_is_ready(mailbox)) {
        printk("ERROR: GPIO or mailbox is not ready\n");
        return 1;
    }
    if (mbox_register_callback(mailbox, 1, on_mailbox, NULL) < 0 ||
        mbox_set_enabled(mailbox, 1, true) < 0) {
        printk("ERROR: cannot enable shutdown mailbox\n");
        return 1;
    }
    uint32_t seq = 0;
    bool configured = false;
    for (;;) {
        int32_t micro_c;
        int rc = 0;
        if (!configured) {
            rc = configure_sensor();
            configured = (rc == 0);
        }
        if (rc == 0) rc = temperature(&micro_c);
        if (rc == 0) {
            printk("{\"type\":\"pb2.external.temperature\",\"schema\":1,"
                   "\"seq\":%u,\"uptime_ms\":%lld,\"temperature_uC\":%d}\n",
                   seq++, (long long)k_uptime_get(), (int)micro_c);
        } else {
            (void)stop();
            configured = false;
            printk("ERROR: external BMP280 read failed: %d\n", rc);
        }
        if (k_sem_take(&shutdown_sem, K_SECONDS(5)) == 0) shutdown_core();
    }
    return 0;
}
