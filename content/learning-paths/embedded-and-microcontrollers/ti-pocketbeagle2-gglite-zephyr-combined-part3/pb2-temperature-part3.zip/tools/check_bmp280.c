/* SPDX-License-Identifier: Apache-2.0 */
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include "../firmware/src/bmp280_temperature.h"

static double floating_reference(uint32_t raw,
                                 const struct bmp280_temperature_calibration *cal)
{
    double delta = raw / 131072.0 - cal->t1 / 8192.0;
    return ((raw / 16384.0 - cal->t1 / 1024.0) * cal->t2 +
            delta * delta * cal->t3) / 5120.0;
}

int main(void)
{
    /* Fixed fixture exercises unsigned T1 and signed little-endian T2/T3. */
    const uint8_t coefficients[] = {0x70, 0x6b, 0x43, 0x67, 0x18, 0xfc};
    struct bmp280_temperature_calibration cal =
        bmp280_decode_temperature_calibration(coefficients);
    assert(cal.t1 == 27504 && cal.t2 == 26435 && cal.t3 == -1000);
    assert(bmp280_temperature_centi_c(519888, &cal) == 2508);
    const uint32_t samples[] = {300000, 400000, 519888, 600000, 700000};
    for (unsigned int n = 0; n < sizeof(samples) / sizeof(samples[0]); n++) {
        double result = bmp280_temperature_centi_c(samples[n], &cal) / 100.0;
        assert(fabs(result - floating_reference(samples[n], &cal)) < 0.02);
    }
    const uint8_t signed_bytes[] = {0xbd, 0x98};
    assert(bmp280_signed_le16(signed_bytes) == -26435);
    /* Wider intermediates must remain well-defined even for extreme trims. */
    cal = (struct bmp280_temperature_calibration){65535, -32768, 32767};
    (void)bmp280_temperature_centi_c(0xfffff, &cal);
    puts("BMP280 calibration decoding and temperature compensation passed");
    return 0;
}
