#!/bin/sh
set -eu
elf=$1
python_version=${2:-312}
firmware=com.arm.PocketBeagle2.ZephyrExternalTemperature
bridge=com.arm.PocketBeagle2.ExternalTemperatureBridge
version=1.0.0
mkdir -p "staging/$firmware/$version" "staging/$bridge/$version"
cp "$elf" "staging/$firmware/$version/zephyr.elf"
cp components/firmware_manager.py "staging/$firmware/$version/"
cp components/bridge.py components/bridge_lifecycle.sh "staging/$bridge/$version/"
python3 -m pip download --only-binary=:all: \
    --platform manylinux2014_aarch64 --implementation cp \
    --python-version "$python_version" --abi "cp$python_version" --abi abi3 --abi none \
    --dest "staging/$bridge/$version" awsiotsdk==1.26.0
