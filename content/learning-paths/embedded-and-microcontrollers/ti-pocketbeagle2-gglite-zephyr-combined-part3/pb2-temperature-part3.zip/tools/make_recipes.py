#!/usr/bin/env python3
"""Create two JSON recipes from the actual staged artifact filenames."""
import argparse
import json
from pathlib import Path

FIRMWARE = "com.arm.PocketBeagle2.ZephyrExternalTemperature"
BRIDGE = "com.arm.PocketBeagle2.ExternalTemperatureBridge"
VERSION = "1.0.0"
TOPIC = "ti/pocketbeagle2/temperature/external"


def make_recipe(name, files, bucket, prefix, lifecycle):
    return {
        "RecipeFormatVersion": "2020-01-25", "ComponentName": name,
        "ComponentVersion": VERSION, "ComponentType": "aws.greengrass.generic",
        "ComponentPublisher": "Arm", "ComponentDescription": name.rsplit(".", 1)[1],
        "Manifests": [{
            "Platform": {"os": "linux", "architecture": "aarch64",
                         "runtime": "aws_nucleus_lite"},
            "Lifecycle": lifecycle,
            "Artifacts": [{"URI": f"s3://{bucket}/{prefix}/{name}/{VERSION}/{f.name}"}
                          for f in files],
        }],
    }


def write_recipes(staging, output, bucket, prefix):
    output.mkdir(parents=True, exist_ok=True)
    a, w = "{artifacts:path}", "{work:path}"
    firmware_files = sorted((staging / FIRMWARE / VERSION).glob("*"))
    bridge_files = sorted((staging / BRIDGE / VERSION).glob("*"))
    if {f.name for f in firmware_files} != {"zephyr.elf", "firmware_manager.py"}:
        raise ValueError("Stage zephyr.elf and firmware_manager.py first")
    if not {"bridge.py", "bridge_lifecycle.sh"}.issubset({f.name for f in bridge_files}):
        raise ValueError("Stage the bridge source files first")
    wheels = [f for f in bridge_files if f.suffix == ".whl"]
    if not any(f.name.startswith("awsiotsdk-1.26.0-") for f in wheels):
        raise ValueError("Missing pinned awsiotsdk wheel")
    if not any(f.name.startswith("awscrt-0.28.1-") and "aarch64" in f.name for f in wheels):
        raise ValueError("Missing pinned AArch64 awscrt wheel")
    firmware = make_recipe(FIRMWARE, firmware_files, bucket, prefix, {
        phase: {"RequiresPrivilege": True, "Script":
                f'exec python3 -u "{a}/firmware_manager.py" {phase} '
                f'--artifact "{a}/zephyr.elf" --work "{w}"'}
        for phase in ("install", "run")
    })
    bridge = make_recipe(BRIDGE, bridge_files, bucket, prefix, {
        phase: {"RequiresPrivilege": True, "Script":
                f'exec /bin/sh "{a}/bridge_lifecycle.sh" {phase} "{a}" "{w}"'
                + (' "{configuration:/serialDevice}" "{iot:thingName}"'
                   if phase == "run" else "")}
        for phase in ("install", "run")
    })
    bridge["ComponentConfiguration"] = {"DefaultConfiguration": {
        "serialDevice": "/dev/ttyS7",
        "accessControl": {"aws.greengrass.ipc.mqttproxy": {
            f"{BRIDGE}:publish:1": {
                "policyDescription": "Publish only external temperature telemetry",
                "operations": ["aws.greengrass#PublishToIoTCore"],
                "resources": [TOPIC],
            }
        }},
    }}
    for recipe in (firmware, bridge):
        (output / (recipe["ComponentName"] + ".json")).write_text(
            json.dumps(recipe, indent=2) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--staging", type=Path, default=Path("staging"))
    parser.add_argument("--output", type=Path, default=Path("recipes"))
    parser.add_argument("--bucket", required=True)
    parser.add_argument("--prefix", default="pb2-temperature")
    args = parser.parse_args()
    write_recipes(args.staging, args.output, args.bucket, args.prefix.strip("/"))
