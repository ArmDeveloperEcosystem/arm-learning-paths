#!/usr/bin/env python3
"""Upload immutable S3 artifacts with the workstation's AWS CLI credentials."""
import argparse
import subprocess
from pathlib import Path

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--bucket", required=True)
    parser.add_argument("--prefix", default="pb2-temperature")
    args = parser.parse_args()
    for source in sorted(Path("staging").glob("*/*/*")):
        key = args.prefix.strip("/") + "/" + source.relative_to("staging").as_posix()
        # Refuse to replace even one published object's bytes.
        subprocess.run(["aws", "s3api", "put-object", "--bucket", args.bucket,
                        "--key", key, "--body", str(source),
                        "--if-none-match", "*"], check=True)
        print(f"Uploaded s3://{args.bucket}/{key}", flush=True)
