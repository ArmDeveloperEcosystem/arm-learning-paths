#!/usr/bin/env python3
"""Host checks, including pure C compensation. No hardware or full firmware build."""
import ast
from concurrent.futures import Future
import importlib.util
import json
import os
from pathlib import Path
import pty
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import types
import unittest
from unittest.mock import patch

BUNDLE = Path(__file__).resolve().parents[1]


def module(name, relative):
    spec = importlib.util.spec_from_file_location(name, BUNDLE / relative)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


bridge = module("bridge", "components/bridge.py")
manager = module("firmware_manager", "components/firmware_manager.py")
recipes = module("make_recipes", "tools/make_recipes.py")


def fixture_elf():
    data = bytearray(20)
    data[:6] = b"\x7fELF\x01\x01"
    data[18] = 40
    return data  # header fixture only; never a deployable executable


class CorePath(type(Path())):
    """Model sysfs state transitions, not mailbox or kernel behavior."""
    def write_text(self, data, *args, **kwargs):
        if self.name == "state":
            data = {"start": "running", "stop": "offline"}.get(data, data)
        return super().write_text(data, *args, **kwargs)


class HostChecks(unittest.TestCase):
    def test_python_sources_parse(self):
        for source in BUNDLE.rglob("*.py"):
            ast.parse(source.read_text(), filename=str(source))

    def test_frames(self):
        frame = {"type": "pb2.external.temperature", "schema": 1,
                 "seq": 7, "uptime_ms": 1000, "temperature_uC": -10_060_000}
        record = bridge.decode_frame(json.dumps(frame), "Thing", "Boot")
        self.assertEqual(record["temperatureC"], -10.06)
        self.assertEqual(record["thingName"], "Thing")
        self.assertEqual(record["sensor"], "BMP280")
        for invalid in [b"Boot banner", b"[]", b"null", b"{}",
                        json.dumps({**frame, "temperature_uC": True}),
                        json.dumps({**frame, "temperature_uC": 85_010_000}),
                        json.dumps({**frame, "schema": True}),
                        json.dumps({**frame, "seq": -1})]:
            with self.assertRaises(ValueError):
                bridge.decode_frame(invalid, "Thing", "Boot")

    def test_uart_to_ipc_and_signal(self):
        master, slave = pty.openpty()
        messages = []

        class Client:
            closed = False
            def publish_to_iot_core_async(self, **kwargs):
                messages.append(kwargs)
                future = Future()
                future.set_result(None)
                return future
            def close(self):
                self.closed = True

        client = Client()
        client_module = types.ModuleType("awsiot.greengrasscoreipc.clientv2")
        client_module.GreengrassCoreIPCClientV2 = lambda: client
        model_module = types.ModuleType("awsiot.greengrasscoreipc.model")
        model_module.QOS = types.SimpleNamespace(AT_LEAST_ONCE="1")
        fake_modules = {"awsiot": types.ModuleType("awsiot"),
                        "awsiot.greengrasscoreipc": types.ModuleType("awsiot.greengrasscoreipc"),
                        "awsiot.greengrasscoreipc.clientv2": client_module,
                        "awsiot.greengrasscoreipc.model": model_module}
        handlers = {s: signal.getsignal(s) for s in (signal.SIGTERM, signal.SIGINT)}
        errors = []

        def producer():
            try:
                time.sleep(0.1)
                os.write(master, b"Zephyr boot banner\n{\"type\":\"pb2.external.temperature\","
                         b"\"schema\":1,\"seq\":1,\"uptime_ms\":300,"
                         b"\"temperature_uC\":25080000}\n")
                deadline = time.monotonic() + 3
                while not messages and time.monotonic() < deadline:
                    time.sleep(0.01)
                if not messages:
                    errors.append("No IPC message received")
            finally:
                os.kill(os.getpid(), signal.SIGTERM)

        worker = threading.Thread(target=producer)
        try:
            with patch.dict("sys.modules", fake_modules), \
                    patch.object(bridge, "Path", return_value=types.SimpleNamespace(
                        read_text=lambda: "test-boot\n")):
                worker.start()
                bridge.run(os.ttyname(slave), "TestThing")
            worker.join()
            self.assertFalse(errors)
            self.assertTrue(client.closed)
            self.assertEqual(messages[0]["topic_name"], bridge.TOPIC)
            record = json.loads(messages[0]["payload"])
            self.assertEqual(record["temperatureC"], 25.08)
            self.assertEqual(record["sensor"], "BMP280")
        finally:
            worker.join(timeout=5)
            for sig, handler in handlers.items():
                signal.signal(sig, handler)
            os.close(master)
            os.close(slave)

    def test_firmware_signal_cleanup_twice(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            core = CorePath(root / "core")
            core.mkdir()
            (core / "state").write_text("offline")
            (core / "firmware").write_text("original.elf")
            artifact = root / "test-header.elf"
            artifact.write_bytes(fixture_elf())
            work = root / "work"
            work.mkdir()
            firmware_dir = root / "firmware"
            firmware_dir.mkdir()
            with patch.object(manager, "find_m4", return_value=core), \
                    patch.object(manager, "Path", return_value=firmware_dir):
                for _ in range(2):
                    handlers = {s: signal.getsignal(s)
                                for s in (signal.SIGTERM, signal.SIGINT)}
                    timer = threading.Timer(0.1, lambda: os.kill(os.getpid(), signal.SIGTERM))
                    try:
                        timer.start()
                        manager.run(artifact, work)
                    finally:
                        timer.cancel()
                        timer.join()
                        for sig, handler in handlers.items():
                            signal.signal(sig, handler)
                    self.assertEqual((core / "state").read_text(), "offline")
                    self.assertEqual((core / "firmware").read_text(), "original.elf")
                    self.assertFalse((work / "owner.json").exists())
                    self.assertFalse((work / "installed").exists())
                    self.assertEqual(list(firmware_dir.iterdir()), [])
                (core / "state").write_text("running")
                with self.assertRaisesRegex(RuntimeError, "must be offline"):
                    manager.run(artifact, work)
                for sig, handler in handlers.items():
                    signal.signal(sig, handler)

    def test_recipes(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            fw = root / "staging" / recipes.FIRMWARE / recipes.VERSION
            br = root / "staging" / recipes.BRIDGE / recipes.VERSION
            fw.mkdir(parents=True)
            br.mkdir(parents=True)
            for name in ("zephyr.elf", "firmware_manager.py"):
                (fw / name).touch()
            for name in ("bridge.py", "bridge_lifecycle.sh",
                         "awsiotsdk-1.26.0-py3-none-any.whl",
                         "awscrt-0.28.1-cp311-abi3-manylinux2014_aarch64.whl"):
                (br / name).touch()
            recipes.write_recipes(root / "staging", root / "recipes", "example-bucket", "pb2")
            generated = [json.loads(p.read_text()) for p in (root / "recipes").glob("*.json")]
            self.assertEqual(len(generated), 2)
            for recipe in generated:
                manifest = recipe["Manifests"][0]
                self.assertEqual(manifest["Platform"]["runtime"], "aws_nucleus_lite")
                self.assertEqual(set(manifest["Lifecycle"]), {"install", "run"})
                self.assertTrue(all(a["URI"].startswith("s3://example-bucket/pb2/")
                                    for a in manifest["Artifacts"]))
            bridge_recipe = next(r for r in generated if r["ComponentName"] == recipes.BRIDGE)
            policy = bridge_recipe["ComponentConfiguration"]["DefaultConfiguration"][
                "accessControl"]["aws.greengrass.ipc.mqttproxy"]
            self.assertEqual(next(iter(policy.values()))["resources"], [bridge.TOPIC])

    def test_bridge_supervisor_removes_install(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            artifacts, work, executables = root / "artifacts", root / "work", root / "bin"
            for path in (artifacts, work, executables):
                path.mkdir()
            # Substitute pip and the application; execute the real lifecycle shell.
            wrapper = executables / "python3"
            wrapper.write_text('#!/bin/sh\nif [ "$1" = -m ]; then exit 0; fi\n'
                               'exec "' + sys.executable + '" "$@"\n')
            wrapper.chmod(0o755)
            (artifacts / "bridge.py").write_text(
                'import signal, sys, time\n'
                'signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))\n'
                'print("READY", flush=True)\n'
                'while True: time.sleep(1)\n')
            (artifacts / "bridge_lifecycle.sh").write_bytes(
                (BUNDLE / "components/bridge_lifecycle.sh").read_bytes())
            (artifacts / "test.whl").touch()
            environment = {**os.environ, "PATH": str(executables) + os.pathsep + os.environ["PATH"]}
            command = ["/bin/sh", str(artifacts / "bridge_lifecycle.sh")]
            subprocess.run(command + ["install", str(artifacts), str(work)],
                           env=environment, check=True)
            self.assertEqual(len(list(work.glob("installed-*"))), 1)
            process = subprocess.Popen(command + ["run", str(artifacts), str(work),
                                                  "/dev/test", "Thing"],
                                       env=environment, stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT, text=True, start_new_session=True)
            try:
                self.assertEqual(process.stdout.readline().strip(), "READY")
                os.killpg(process.pid, signal.SIGTERM)
                process.communicate(timeout=5)
                self.assertEqual(process.returncode, 0)
                self.assertEqual(list(work.glob("installed-*")), [])
            finally:
                if process.poll() is None:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.communicate()

    @unittest.skipUnless(shutil.which("cc"), "C compiler required for BMP280 compensation check")
    def test_bmp280_compensation(self):
        with tempfile.TemporaryDirectory() as directory:
            executable = Path(directory) / "check-bmp280"
            subprocess.run(["cc", "-std=c99", "-Wall", "-Wextra", "-Werror",
                            "-fsanitize=undefined", str(BUNDLE / "tools/check_bmp280.c"),
                            "-o", str(executable), "-lm"], check=True)
            subprocess.run([str(executable)], check=True)


if __name__ == "__main__":
    unittest.main(verbosity=2)
