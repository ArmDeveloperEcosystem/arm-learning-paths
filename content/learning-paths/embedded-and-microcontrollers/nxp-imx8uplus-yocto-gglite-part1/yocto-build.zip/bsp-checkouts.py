#!/usr/bin/env python3
"""Protect BSP edits while preserving the pinned NXP setup's file overrides."""

import json
from pathlib import Path
import subprocess
import sys


PINS = {
    'sources/meta-imx': '1cfbbb8f9ce1d6071775ea6083b79d98597c8206',
    'sources/meta-freescale': '3d2781ad200846183ee3f3391f49512d0ef1b529',
}
UPSTREAM = 'sources/meta-freescale'
OVERLAY = 'sources/meta-imx/meta-imx-bsp'
# setup-utils.sh:hook_in_layer removes these upstream duplicates, even for i.MX8.
OVERRIDES = {
    'conf/machine/imx95-19x19-verdin.conf',
    'conf/machine/include/imx95-evk.inc',
}


def command(*args, cwd=None):
    return subprocess.run(args, cwd=cwd, check=True, stdout=subprocess.PIPE,
                          text=True, errors='surrogateescape').stdout


def git(root, *args):
    return command('git', '-C', str(root), *args)


def status(root, *paths):
    fields = iter(git(root, 'status', '--porcelain=v1', '-z',
                      '--untracked-files=all', '--ignore-submodules=none',
                      '--', *paths).split('\0'))
    entries = []
    for field in fields:
        if not field:
            continue
        state, path = field[:2], field[3:]
        entries.append((state, path))
        if 'R' in state or 'C' in state:
            next(fields)  # The original name follows a renamed/copied path.
    return entries


def has_clean_replacement(workdir, path):
    if path not in OVERRIDES:
        return False
    for project, revision in PINS.items():
        if git(workdir / project, 'rev-parse', 'HEAD').strip() != revision:
            return False
    overlay = workdir / OVERLAY
    replacement = overlay / path
    if not replacement.is_file() or replacement.is_symlink():
        return False
    # Require a tracked, unchanged replacement; mere existence is insufficient.
    tracked = git(overlay, 'ls-files', '--', path).strip()
    return tracked == path and not status(overlay, path)


def inspect(workdir, projects):
    generated, dirty = [], []
    for project in projects:
        root = workdir / project
        if not (root / '.git').exists():
            if root.exists() and any(root.iterdir()):
                dirty.append(f'{project}: uninitialized checkout contains files')
            continue  # Initial/partial sync: absent checkouts have no edits to lose.
        for state, path in status(root):
            if (project == UPSTREAM and state == ' D'
                    and has_clean_replacement(workdir, path)):
                generated.append(path)
            else:
                dirty.append(f'{project}: {state} {path!r}')
    if dirty:
        raise RuntimeError('BSP checkouts contain local changes:\n'
                           + '\n'.join(dirty)
                           + '\nPreserve BSP checkout edits before syncing. '
                           'Commit or copy them outside WORKDIR, then resolve '
                           'the listed changes and retry.')
    return sorted(generated)


def reapply(workdir, generated):
    # Sync may restore these files. Retain only deletions accepted before sync;
    # never remove a new or edited file, or a file from a different BSP release.
    upstream = workdir / UPSTREAM
    for path in generated:
        if not has_clean_replacement(workdir, path):
            raise RuntimeError(f'NXP replacement changed; refusing to remove {path!r}')
        if status(upstream, path) not in ([], [(' D', path)]):
            raise RuntimeError(f'BSP file changed during sync; preserving {path!r}')
        if git(upstream, 'ls-files', '--', path).strip() != path:
            raise RuntimeError(f'BSP file is not tracked; preserving {path!r}')
    for path in generated:
        target = upstream / path
        if target.exists():
            target.unlink()
            print(f'Preserved NXP setup override: {UPSTREAM}/{path}', file=sys.stderr)


def main():
    mode, directory = sys.argv[1:]
    workdir = Path(directory).resolve()
    if mode == 'check':
        projects = command('repo', 'list', '-p', cwd=workdir).splitlines()
        print(json.dumps(inspect(workdir, projects)))
    elif mode == 'reapply':
        reapply(workdir, json.load(sys.stdin))
    else:
        raise ValueError(f'Unknown operation: {mode}')


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, ValueError, subprocess.CalledProcessError, OSError) as error:
        print(f'BSP checkout check failed: {error}', file=sys.stderr)
        sys.exit(1)
