# NXP FRDM i.MX 8M Plus source and validation notes

Current status (November 8, 2026): the user reported successful heartbeat/control
communication after rebuilding the corrected Part 1 FRDM image. Part 3 has
since been aligned and cross-compiled; see the final series-alignment section.
Earlier dated notes retain the prior failure and validation history.


Research date: October 29, 2026. BSP: LF6.12.49_2.2.0 / Walnascar.
NXP manifest commit: 07d7cd3f29a18e809f6391eea1be01103b1d6e13.
meta-imx: 1cfbbb8f9ce1d6071775ea6083b79d98597c8206.
Linux: df24f9428e38740256a410b983003a478e72a7c0.
meta-aws: 5d73130967dce143f44fe2f80d65361f6b653c5e (Lite 2.3.0).
Zephyr v4.3.0: 3568e1b6d5cdd51a6b964a2a1d6d29200fea2056; SDK 0.17.4.

Authoring checks cover syntax, source/patch consistency, recipes, compensation,
and simulated lifecycle behavior. Full Yocto compilation, Zephyr cross-compilation,
physical sensor routing, power sequencing, and AWS deployment were not executed
in the authoring environment. The FRDM i.MX 8M Plus profile reuses upstream i.MX 8M Plus M7 SoC support
with its supplied application overlay; the upstream target identifier is retained for build compatibility.
Run the documented image/MCU builds and deploy-remove-deploy-remove acceptance
on the actual board. Do not treat a model of remoteproc or a successful recipe
registration as proof of hardware operation.

Build-driver regression checks use real temporary Git checkouts and simulated
host, repo-sync, and Yocto commands. Fresh and repeated `--no-sdk` builds cover
NXP's two setup-generated file deletions, including sync restoring those files,
and setup unsetting MACHINE. Checks also verify that staged deletions, unrelated
edits, untracked files, changed replacements, and different BSP revisions stop
the build without discarding edits. No BitBake compilation is performed.

Host-tar packaging compatibility backport:
- Pinned pseudo source: 28dcefb809ce95db997811b5662f0b893b9923e0.
- Upstream syscall fix: 472c8977e0238e5a1ed4d29d7c41de699646ceff.
- Header follow-up: 899736ef46bb903099e13d649cfe785c29135cab,
  adapted to the older ENOSYS interposer.
Both patches apply without fuzz on top of this BSP's original pseudo patch stack.
A native ARM64 Ubuntu 24.04 container compiled that source before and after the
backport, with tar 1.35+dfsg-3ubuntu0.4. The unpatched source reproduced both the
unknown-directory error through openat2/mkdirat and the nested tar package-copy
failure. The patched source passed both checks and preserved copied file contents.
This validates the host-tool fix; it is not a full Yocto or board-image build.
The build-driver tests also verify that pseudo-native is built before the image.

FRDM correction (November 5, 2026): machine `imx8mp-lpddr4-frdm`,
DTB `imx8mp-frdm.dtb`, and the MCU policy patch target the pinned FRDM DTS.
The audio node disabled by that policy is `sound-wm8962`.
NXP FRDM machine source:
https://github.com/nxp-imx/meta-imx/blob/1cfbbb8f9ce1d6071775ea6083b79d98597c8206/meta-imx-bsp/conf/machine/imx8mp-lpddr4-frdm.conf
NXP FRDM DTS source:
https://github.com/nxp-imx/linux-imx/blob/df24f9428e38740256a410b983003a478e72a7c0/arch/arm64/boot/dts/freescale/imx8mp-frdm.dts
This correction has not been validated by a full image build or physical boot.

November 7, 2026 M7 hang correction: reserved vring nodes are now named
vdev0vring0 and vdev0vring1, with vdev0buffer as memory-region index 0.
Linux matches the node names when allocating host-managed RPMsg vrings; DTS
labels do not supply carveout names. The corrected patch and the migration
patch were applied against the pinned Linux DTS and produced identical results.
Rebuild and boot the corrected DTB before using Part 2. Run prepare_mcore in
FRDM U-Boot before Linux on each M7 test boot. See Part 2 HANG-FIX.md for the
Zephyr clock override, transport fixes, and preflight. No board test performed.

November 8 persistent-hang follow-up: supplied U-Boot control DT identifies EVK
on the physical FRDM board. New verify-machine.py checks effective BitBake
MACHINE, UBOOT_CONFIG_BASENAME, UBOOT_DTB_NAME and any explicit UBOOT_MACHINE
before building. The updated preflight is installed and runs before M7 loading;
it verifies the running M7 boot flag in addition to DT reservations. Wrapper and
manager both guard the operation, and stage logs bracket remoteproc start.
Checks covered synthetic valid/mismatched configs, preflight early abort and
syntax/archive consistency. No full Yocto build or hardware validation performed.

November 8, 2026 Part 1 image-selection and packaging repair:
The user supplied nxp-lp-dev-image-imx8mpevk.rootfs.wic.zst, SHA256
f99ff6117a93dca478b5323ae625e2d6714b4bf417cf9426fe23162e38d2025a.
The actual compressed image was opened read-only. Before its first partition
at 8 MiB, its bootloader area contains EVK DTs at offsets 0x20e90 (8651 bytes)
and 0x18a5c8 (82832 bytes). Both model/compatible values identify EVK; the boot
version strings match the board's U-Boot 2025.04-g4ddbad60eff3. This confirms
that the flashed source image itself contains EVK firmware. Its exact original
build configuration/history was not supplied.

The original driver could preserve a prior EVK local.conf even after board.env
changed to FRDM: the pinned setup-environment intentionally leaves an existing
configuration unchanged and clears the shell MACHINE. That failure path is
now covered by regressions. The driver defaults to build-frdm, explicitly writes
MACHINE=imx8mp-lpddr4-frdm in its own marked block, refuses another board.env
machine, and checks the effective SD/FRDM U-Boot recipe values before building.
The old build/ directory and unrelated user configuration are preserved.

A FRDM-only u-boot-imx_2025.04.bbappend patches the native FRDM boot command to
run prepare_mcore before bsp_bootcmd and uses an unquoted imx8mp-frdm.dtb name.
The patch applies cleanly to exact pinned U-Boot revision
4ddbad60eff308a5b356fb9ab8734ac382ddd692. No U-Boot compilation was performed.
The existing Linux/RPMsg ownership, preflight and pseudo backports are retained.

inspect-boot-image.py reads only the raw pre-partition area of plain/zstd MBR
WICs, identifies board DTs and embedded U-Boot defaults, and rejects non-FRDM or
unverified board identity and an incorrect M7 boot policy. The build invokes it
on the published WIC before reporting success (and before optional SDK work),
recording validation/boot-image.json next to boot-config.json. The exact failing
WIC was rejected by this final inspector. This is a boot identity/policy check,
not a complete disk-integrity or physical-board acceptance test.

Validation: 19 unittest cases passed. They include fresh/resumed simulated
builds, old EVK build preservation, effective U-Boot mismatch rejection before
compilation, EVK firmware hidden in a FRDM-named WIC rejected after packaging,
FAT-partition DTBs excluded from boot identity, plain/zstd WIC parsing, old boot
policy rejection, bad/truncated images, and the existing checkout safety tests.
Real temporary Git repositories and real binary-format fixtures were used;
repo/BitBake commands were simulated. Bash/Python syntax and ZIP/source equality
were checked. No full Yocto image was built, no card was flashed, and no new
firmware was executed on physical hardware in this repair session.

## November 8, 2026: working image and series alignment

The user rebuilt Part 1 for `imx8mp-lpddr4-frdm`, booted the new SD image and
reported the corrected heartbeat running with Linux responsive. The journal
confirms the M7 clock argument, named carveouts, return from remoteproc start
and HELLO/READY control handshake. Sequences 60–82 advanced continuously using
one open RPMsg descriptor. Tested heartbeat SHA256:
`5f6e8ff0c1b3c6596b13bb49c8e22a16f3e73a56a5431cf111742f2730abb27c`.
See Part 2's `validation/BOARD-RESULT.md` for the user-reported evidence.

Part 3 now shares corrected Part 2 firmware/build sources, both table patches,
strong FRDM clock initializer, separate temperature overlay and ELF inspector.
Its manager and staged recipe include the same Linux preflight as Part 1/2.
The build and packaging validation results are recorded in Part 3's validation
directory. Compiled Part 1 defaults perform the M7 preparation automatically;
manual U-Boot recovery is conditional on an old saved environment overriding
them. Earlier chronological failure notes describe the prior EVK-image setup.

Physical BMP280 acquisition, stop/restart qualification and AWS deployment
remain unreported. No full BitBake build was run on this macOS authoring host.

## November 8, 2026 Greengrass runtime audit

The pinned 2.3.0 recipe already contains the core runtime as one package. The
reported `ggl.core.ggtesd.service` spelling was incorrect for its canonical
`ggl.core.tesd.service`; the guide also had an incorrect fleet-status name and
an incomplete activation sequence. All three Part 1 bundles now include an
explicit runtime package group, forced unit installation, selected-recipe
verification and a completed-rootfs/package-manifest audit. Provisioning checks
all required products and attaches the complete core unit set. See
GREENGRASS-RUNTIME.md and validation/greengrass-* evidence for exact pins,
regressions and limits. No full BitBake build or physical AWS test was run here.

## MCU ownership recovery (November 9, 2026)

The shared manager now records the Linux boot ID, recovers verified previous-boot
ownership only with the core offline, and provides explicit recovery for legacy
records. Owned files are archived and the existing lock is retained. See
[MCU-RECOVERY.md](MCU-RECOVERY.md) for updating an existing image and the host
validation limits.
