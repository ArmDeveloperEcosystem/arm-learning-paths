# NXP FRDM i.MX 8M Plus Yocto build bundle

This bundle builds for **FRDM-IMX8MPLUS**, machine `imx8mp-lpddr4-frdm`,
using LF6.12.49_2.2.0 / Walnascar. The supplied failing `imx8mpevk` WIC was
inspected and contains EVK bootloader DTs; a firmware-only update cannot change
that image's board configuration.

On the Ubuntu build host, keep this complete bundle at its fixed path and run:

```bash
WORKDIR="$HOME/yocto-nxp-imx8uplus" JOBS=4 bash build-yocto.sh --no-sdk
```

Keep the documented host dependencies and EULA acceptance. The helper defaults
to `$WORKDIR/build-frdm`, so the existing EVK `build/` directory is preserved.
It explicitly selects FRDM and verifies the resolved U-Boot recipe settings.
A FRDM-only bootloader patch prepares the M7 clock argument and boots the
custom `imx8mp-frdm.dtb` through the BSP path without preloading M7.

Output: `build-frdm/tmp/deploy/images/imx8mp-lpddr4-frdm/` under WORKDIR.
Only after the image's raw boot area passes FRDM board and M7 boot-policy checks
does the helper report success. Reports are under `$WORKDIR/validation/`.
Standalone image inspection:

```bash
python3 inspect-boot-image.py --require-frdm --require-m7-boot YOUR_IMAGE.wic.zst
```

Write the verified full WIC to SD, boot with FRDM SW5 set to `0011`, and verify
FRDM identity in U-Boot's control DT. Linux must receive
`clk-imx8mp.mcore_booted`. The installed `nxp-mcore` preflight verifies the Linux
DT, memory reservations, UART ownership and M7 argument before starting firmware.
Existing saved U-Boot environment overrides can still replace compiled defaults;
check the actual boot arguments after boot. When the corrected defaults are
active, no manual U-Boot commands are needed on each boot. The user reported
successful Linux preflight, remoteproc start, control handshake and continuous
heartbeat after rebuilding this FRDM image; see `../validation/BOARD-RESULT.md`.

The checkout guard preserves user edits and accepts only the pinned NXP setup's
two known machine-file removals. The pseudo openat2 compatibility backport,
Greengrass Lite integration and M7 reservations are retained. Reuse WORKDIR to
retain the existing sources/downloads; the default FRDM build directory is new.
No credentials or prebuilt correct Yocto image are included. Configure-only
parses/dependency-checks; a full image build and board boot still require Ubuntu
and the physical board. Source tests do not constitute hardware acceptance.

## Complete Greengrass Lite installation

This bundle now installs `packagegroup-nxp-lp-greengrass`, forces systemd-unit
installation and fails if the completed image lacks any audited runtime
executable, core unit or required package. The pinned services are
`ggl.core.tesd.service` and `ggl.core.gg-fleet-statusd.service`. See
[GREENGRASS-RUNTIME.md](GREENGRASS-RUNTIME.md) for all recipes/components,
metadata/rootfs checks and the corrected activation procedure. Update the full
bundle and rerun with the same WORKDIR; require both new Greengrass validation
reports before flashing.

## MCU ownership recovery (November 9, 2026)

The shared manager now records the Linux boot ID, recovers verified previous-boot
ownership only with the core offline, and provides explicit recovery for legacy
records. Owned files are archived and the existing lock is retained. See
[MCU-RECOVERY.md](MCU-RECOVERY.md) for updating an existing image and the host
validation limits.

## External time servers (November 10, 2026)

The image now installs ntp/ntpq explicitly and replaces the upstream LOCAL-only
ntp.conf with external servers. Its completed-rootfs audit rejects the old
configuration. Follow [the UTC repair procedure](GREENGRASS-RUNTIME.md#external-utc-synchronization)
for a running older image; verify real UTC before provisioning/deployment.
The live board's S3 diagnostic identified RequestTimeTooSkewed despite
`timedatectl` previously reporting synchronized. The MCU ELF is unchanged.

## Build host architecture

The helper detects Ubuntu/Linux x86_64 or arm64/aarch64 automatically and sets
SDKMACHINE to the detected host. The target MACHINE remains this FRDM board.
Run as a non-root user on Ubuntu 22.04/24.04 or a compatible Ubuntu-based system.
The dependency installer uses native apt packages on either architecture.
A recorded host architecture protects new build directories against reuse by
another architecture. Use a separate WORKDIR or LP_BUILD_DIR when switching
hosts; keep existing tmp trees, Python environments and SDKs on their own host.
The pinned NXP Arm GNU native-toolchain recipe and Yocto uninative metadata
already provide x86_64 and aarch64 downloads/checksums. No BSP revision change
or emulation is required by this helper. Script/fixture tests cover both hosts;
a full native Ubuntu arm64 image/SDK build has not been performed here.
