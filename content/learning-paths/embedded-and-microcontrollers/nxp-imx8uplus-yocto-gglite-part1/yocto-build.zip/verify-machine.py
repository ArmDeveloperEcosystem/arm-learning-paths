#!/usr/bin/env python3
"""Reject a reused EVK build configuration before starting the FRDM image build."""
import ast
import json
import re
import subprocess
import sys
from pathlib import Path


def verify(environment, expected_machine):
    wanted = {'MACHINE', 'UBOOT_CONFIG', 'UBOOT_CONFIG_BASENAME', 'UBOOT_DTB_NAME', 'UBOOT_MACHINE'}
    values = {}
    for line in environment.splitlines():
        match = re.fullmatch(r'([A-Z_]+)=(".*")', line)
        if match and match[1] in wanted:
            values[match[1]] = ast.literal_eval(match[2])
    expected = {'MACHINE': expected_machine, 'UBOOT_CONFIG': 'sd', 'UBOOT_CONFIG_BASENAME': 'imx8mp_frdm',
                'UBOOT_DTB_NAME': 'imx8mp-frdm.dtb'}
    for key, value in expected.items():
        if values.get(key) != value:
            raise ValueError(f'{key} resolves to {values.get(key)!r}, expected {value!r}. '
                             'Preserve the existing configuration and use a fresh WORKDIR for FRDM.')
    configs = values.get('UBOOT_MACHINE', '').split()
    if any(not c.startswith('imx8mp_frdm') for c in configs):
        raise ValueError(f'UBOOT_MACHINE selects a non-FRDM configuration: {configs!r}')
    return values


if __name__ == '__main__':
    if len(sys.argv) != 3:
        sys.exit('Usage: verify-machine.py expected-machine report.json')
    result = subprocess.run(['bitbake', '-e', 'u-boot-imx'], capture_output=True, text=True)
    if result.returncode:
        sys.stderr.write(result.stderr)
        sys.exit('Could not resolve the U-Boot recipe environment; no image build started.')
    try:
        values = verify(result.stdout, sys.argv[1])
    except (ValueError, SyntaxError) as error:
        sys.exit(f'FRDM build configuration mismatch: {error}')
    report = Path(sys.argv[2]);report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(json.dumps(values, indent=2) + '\n')
    print('Verified FRDM machine and bootloader configuration: ' + json.dumps(values, sort_keys=True))
