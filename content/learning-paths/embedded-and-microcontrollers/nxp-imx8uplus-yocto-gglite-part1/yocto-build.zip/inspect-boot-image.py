#!/usr/bin/env python3
"""Read board DTs from the raw boot area of an MBR WIC (plain or zstd)."""
import argparse
import json
import re
import struct
import subprocess
import sys
from pathlib import Path

LIMIT = 32 * 1024 * 1024
MAGIC = b'\xd0\x0d\xfe\xed'


def partitions(header):
    if len(header) != 512 or header[510:512] != b'\x55\xaa':
        raise ValueError('expected an MBR WIC image')
    result = []
    for index in range(4):
        entry = header[446 + 16 * index:462 + 16 * index]
        start, size = struct.unpack_from('<II', entry, 8)
        if entry[4] and size:
            if entry[4] == 0xee:
                raise ValueError('GPT images need a different boot-area inspection')
            result.append({'index': index + 1, 'offset': start * 512, 'size': size * 512})
    if not result:
        raise ValueError('WIC has no partitions')
    return result


def root_properties(blob):
    magic, total, pos, names, _, version, last, _, names_size, tree_size = struct.unpack_from('>10I', blob)
    if magic != 0xd00dfeed or total != len(blob) or version != 17 or last > 17:
        raise ValueError('unsupported DT header')
    if pos < 40 or names < 40 or names + names_size > total or pos + tree_size > total:
        raise ValueError('invalid DT bounds')
    end = pos + tree_size
    strings = blob[names:names + names_size]
    depth, properties = 0, {}
    while pos + 4 <= end:
        token, = struct.unpack_from('>I', blob, pos)
        pos += 4
        if token == 1:
            pos = (blob.index(b'\0', pos, end) + 4) & ~3
            depth += 1
        elif token == 2:
            depth -= 1
            if depth < 0:
                raise ValueError('unbalanced DT')
        elif token == 3:
            length, name = struct.unpack_from('>II', blob, pos)
            pos += 8
            if pos + length > end:
                raise ValueError('invalid DT property')
            prop = strings[name:strings.index(b'\0', name)].decode()
            if depth == 1 and prop in ('model', 'compatible'):
                properties[prop] = blob[pos:pos + length].rstrip(b'\0').decode().split('\0')
            pos = (pos + length + 3) & ~3
        elif token == 9:
            if depth:
                raise ValueError('unbalanced DT')
            return properties
        elif token != 4:
            raise ValueError('invalid DT token')
    raise ValueError('unterminated DT')


def inspect(path):
    process = None
    if path.name.endswith('.zst'):
        process = subprocess.Popen(['zstd', '-dc', '--', str(path)], stdout=subprocess.PIPE,
                                   stderr=subprocess.DEVNULL)
        stream = process.stdout
    else:
        stream = path.open('rb')
    try:
        header = stream.read(512)
        layout = partitions(header)
        limit = min(p['offset'] for p in layout)
        if not 512 < limit <= LIMIT:
            raise ValueError('raw boot area is outside the supported 32 MiB range')
        data = header + stream.read(limit - 512)
        if len(data) != limit:
            raise ValueError('truncated WIC boot area')
    finally:
        if process is not None and process.poll() is None:
            process.terminate()
        stream.close()
        if process is not None:
            process.wait(timeout=5)
    trees, offset = [], 0
    while True:
        offset = data.find(MAGIC, offset)
        if offset < 0:
            break
        try:
            size, = struct.unpack_from('>I', data, offset + 4)
            if 40 <= size <= len(data) - offset:
                properties = root_properties(data[offset:offset + size])
                if 'fsl,imx8mp' in properties.get('compatible', []):
                    trees.append({'offset': offset, 'size': size, **properties})
        except (ValueError, IndexError, struct.error, UnicodeError):
            pass
        offset += 4
    defaults = {}
    for key in ('bootcmd', 'fdtfile', 'prepare_mcore'):
        values = re.findall(b'(?:^|\x00)' + key.encode() + b'=([^\x00]{1,512})\x00', data)
        defaults[key] = sorted(set(v.decode(errors='replace') for v in values))
    return {'image': str(path.resolve()), 'raw_boot_area_bytes': limit,
            'partitions': layout, 'bootloader_device_trees': trees, 'default_environment': defaults}


def require_frdm(report):
    trees = report['bootloader_device_trees']
    if not trees:
        raise ValueError('no readable i.MX8MP bootloader DT found; board identity is unverified')
    for tree in trees:
        if not any(c in tree['compatible'] for c in ('fsl,imx8mp-frdm', 'fsl,frdm-imx8mp')):
            raise ValueError(f"bootloader DT at {tree['offset']:#x} is not FRDM: {tree['compatible']}")


def require_m7_boot(report):
    expected = {'bootcmd': ['run prepare_mcore; run bsp_bootcmd'],
                'fdtfile': ['imx8mp-frdm.dtb'],
                'prepare_mcore': ['setenv mcore_clk clk-imx8mp.mcore_booted']}
    if report['default_environment'] != expected:
        raise ValueError('embedded U-Boot defaults do not match the FRDM Linux/M7 boot policy')


def image_in_deploy(directory, machine):
    candidates = [p for p in directory.glob(f'nxp-lp-dev-image-{machine}*.wic*')
                  if p.is_file() and (p.name.endswith('.wic') or p.name.endswith('.wic.zst'))]
    if not candidates:
        raise ValueError(f'no matching WIC or WIC.zst image in {directory}')
    return max(candidates, key=lambda p: (p.is_symlink(), p.stat().st_mtime))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('image', type=Path, nargs='?')
    parser.add_argument('--deploy-dir', type=Path)
    parser.add_argument('--machine', default='imx8mp-lpddr4-frdm')
    parser.add_argument('--require-frdm', action='store_true')
    parser.add_argument('--require-m7-boot', action='store_true')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    if bool(args.image) == bool(args.deploy_dir):
        parser.error('provide one image or --deploy-dir')
    try:
        path = args.image or image_in_deploy(args.deploy_dir, args.machine)
        report = inspect(path)
        output = json.dumps(report, indent=2) + '\n'
        if args.report:
            args.report.parent.mkdir(parents=True, exist_ok=True)
            args.report.write_text(output)
        print(output, end='')
        if args.require_frdm:
            require_frdm(report)
        if args.require_m7_boot:
            require_m7_boot(report)
        print('PASS: FRDM bootloader identity verified.' if args.require_frdm else 'Boot-area inspection complete.')
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        sys.exit(f'Boot image rejected: {error}')


if __name__ == '__main__':
    main()
