FILESEXTRAPATHS:prepend := "${THISDIR}/files:"
SRC_URI:append:imx8mp-lpddr4-frdm = " file://0001-frdm-linux-m7-boot-policy.patch"
