# NXP FRDM i.MX 8M Plus source and validation notes

BSP: LF6.12.49_2.2.0 / Walnascar.
NXP manifest: 07d7cd3f29a18e809f6391eea1be01103b1d6e13.
meta-imx: 1cfbbb8f9ce1d6071775ea6083b79d98597c8206.
Linux: df24f9428e38740256a410b983003a478e72a7c0.
meta-aws: 5d73130967dce143f44fe2f80d65361f6b653c5e (Lite 2.3.0).
Zephyr v4.3.0: 3568e1b6d5cdd51a6b964a2a1d6d29200fea2056; SDK 0.17.4.

The upstream `imx8mp_evk/mimx8ml8/m7` identifier supplies reusable SoC support;
the physical board, boot firmware, Linux image and application overrides are
FRDM-IMX8MPLUS. The bundle has no local board root.

## November 8, 2026: working image and series alignment

The user rebuilt Part 1 for `imx8mp-lpddr4-frdm`, booted the new SD image and
reported the corrected heartbeat running with Linux responsive. The journal
confirms the M7 clock argument, named carveouts, return from remoteproc start
and HELLO/READY control handshake. Sequences 60–82 advanced continuously using
one open RPMsg descriptor. Tested heartbeat SHA256:
`5f6e8ff0c1b3c6596b13bb49c8e22a16f3e73a56a5431cf111742f2730abb27c`.
See Part 2's `validation/BOARD-RESULT.md` for the user-reported evidence.

Part 3 now shares corrected Part 2 firmware/build sources, both table patches,
strong FRDM clock initializer, separate temperature overlay and ELF inspector.
Its manager and staged recipe include the same Linux preflight as Part 1/2.
The build and packaging validation results are recorded in Part 3's validation
directory. Compiled Part 1 defaults perform the M7 preparation automatically;
manual U-Boot recovery is conditional on an old saved environment overriding
them. Earlier chronological failure notes describe the prior EVK-image setup.

Physical BMP280 acquisition, stop/restart qualification and AWS deployment
remain unreported. No full BitBake build was run on this macOS authoring host.

## MCU ownership recovery (November 9, 2026)

The shared manager now records the Linux boot ID, recovers verified previous-boot
ownership only with the core offline, and provides explicit recovery for legacy
records. Owned files are archived and the existing lock is retained. See
[MCU-RECOVERY.md](MCU-RECOVERY.md) for updating an existing image and the host
validation limits.

## BMP280 probe diagnostics (November 9, 2026)

The firmware now reports controller readiness, per-address read errors and chip
IDs instead of hiding every discovery failure behind -19. See SENSOR-PROBE.md
for interpretation and validation limits.

## Artifact delivery correction (November 9, 2026)

The release is now 1.0.1, selected once in release.json. Generate recipes with
a real bucket/prefix/board Region, then use artifact-plan.json for uploads and
the read-only role/object preflight. The generated artifact-access.json grants
the existing device role S3 reads for the two component prefixes. Reference
JSON moved to examples/recipes; regenerate any old recipes/ files after
extracting this update. See ARTIFACT-DELIVERY.md for the complete sequence and
403 interpretation. No AWS policy, bucket or deployment was modified here.
