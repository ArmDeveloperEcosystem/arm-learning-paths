# Repair Part 3 artifact delivery

The subsequent live-board diagnosis identified RequestTimeTooSkewed: credentials
were issued successfully, but the request timestamp was about 1 hour 46 minutes
behind AWS. The board's ntp.conf trusted only its own local clock. Repair UTC
using the procedure below before repeating artifact or IAM changes. If existing
artifact URIs/bytes and permissions are correct, a clock-only repair can reuse
the published versions.

The reported 403 is from a signed S3 artifact request in the pinned Lite
runtime, before any component install/run script executes. The later NOENTRY
fleet-status errors are consistent with components not being installed. These
logs alone do not establish whether an object URI, role permission, Region,
encryption policy or signing/clock issue caused the denial.

The old bundle supplied placeholder-bucket recipes and let the generator and
uploader choose destinations independently. The update removes those examples
from recipes/, rejects placeholder/unsafe destinations and generates one
artifact-plan.json binding every recipe URI to its exact staged bytes and key.
The uploader uses only that plan. Source/recipe drift or conflicting objects
are rejected. Conditional PUT plus SHA256 allows safe resumption of identical
uploads. A version is selected once in release.json, currently 1.0.1.

## Use the working ELF and an unused release

Run on the AWS administrative workstation in this extracted bundle. Keep the
working Part 1 credentials/Hello World deployment and the MCU setup. No Yocto
rebuild or new firmware build is required for this S3 workflow change.

Set AWS_REGION to the board's configured awsRegion and IOT_ROLE_ALIAS to its
exact iotRoleAlias. Use a private bucket in that same Region. Do not substitute
the workstation identity or a similarly named Greengrass service role.

```bash
export AWS_REGION=YOUR_BOARD_REGION
export AWS_DEFAULT_REGION="$AWS_REGION"
export IOT_ROLE_ALIAS=YOUR_BOARD_ROLE_ALIAS
export ARTIFACT_BUCKET=YOUR_REAL_PRIVATE_BUCKET
export ARTIFACT_PREFIX=nxp-imx8uplus-temperature

# Edit release.json to another unused version if 1.0.1 already exists.
# Replace this ELF path; 313 is the board's Python 3.13 interpreter.
sh tools/stage.sh /path/to/working/temperature.elf 313
python3 tools/make_recipes.py --bucket "$ARTIFACT_BUCKET" \
  --prefix "$ARTIFACT_PREFIX" --region "$AWS_REGION"

export ROLE_ARN=$(aws iot describe-role-alias --region "$AWS_REGION" \
  --role-alias "$IOT_ROLE_ALIAS" --query roleAliasDescription.roleArn --output text)
export ROLE_NAME=${ROLE_ARN##*/}
python3 -m json.tool artifact-access.json
aws iam put-role-policy --role-name "$ROLE_NAME" \
  --policy-name NXPIMX8MPlusExternalTemperatureArtifacts --policy-document file://artifact-access.json

python3 tools/upload.py --plan artifact-plan.json
python3 tools/check_artifact_access.py --plan artifact-plan.json \
  --role-alias "$IOT_ROLE_ALIAS" &&
aws greengrassv2 create-component-version --region "$AWS_REGION" \
  --inline-recipe fileb://recipes/com.arm.NXPIMX8MPlus.ZephyrExternalTemperature.json &&
aws greengrassv2 create-component-version --region "$AWS_REGION" \
  --inline-recipe fileb://recipes/com.arm.NXPIMX8MPlus.ExternalTemperatureBridge.json
```

Review the generated policy before applying it. It grants s3:GetObject on only
these two component prefixes across versions, plus the bucket's location read.
It preserves access to earlier versions for rollback. Use a different policy
name if the documented name belongs to something unrelated. The bucket remains
private; this is a role policy, not an IoT certificate MQTT policy.

Follow deploy.md to preserve the existing group selection and deploy the
release.json version. Do not change objects behind a published version or
republish 1.0.0 with different bytes. Stop the manual M7 test before deploying
its Greengrass owner, as the existing instructions require.

## Existing published versions

If their URIs and bytes are already correct, grant the actual device role
reads on those existing paths and retry the deployment. That permissions-only
repair does not need new recipes. If a published URI contains a placeholder,
wrong bucket/key or wrong-Region bucket, use fresh keys and an unused version.
When updating an old extracted bundle, run the new generator to replace old
recipes/ files; unzipping alone does not remove leftover files.

The preflight performs workstation HEAD requests with checksum verification,
bucket Region verification, role-alias resolution and IAM simulation for every
object. It requires the corresponding read permissions and
IAM SimulatePrincipalPolicy. It does not assume the device role, test its IoT
certificate, reproduce the board's signed request, or prove access through all
bucket/SCP/VPC policies. SSE-KMS requires explicit verification of kms:Decrypt
and the key policy; the preflight refuses to claim success for that case.
If preflight passes and the board still gets 403, inspect its UTC clock,
effective Region/role alias and the actual S3 denial. No device credentials
need to be shared or installed on the workstation.

## Validation

The artifact tests use temporary files and mocked AWS responses, checking
placeholder rejection, exact object/policy paths, version/Region drift, staged
byte changes, resumable uploads and denied role/object checks. The existing
host lifecycle checks also pass. Offline AWS CLI skeleton checks verify API
argument names without credentials or AWS requests. No AWS policies, buckets,
component versions or deployments were changed during authoring. On November
10 the user confirmed successful deployment and BMP280 temperature telemetry in
AWS IoT Core on FRDM-IMX8MPLUS after correcting the local-clock-only NTP setup.
That hardware result applies to i.MX8M Plus; i.MX93/i.MX95 hardware validation
remains outstanding. Exact deployed versions and a post-fix standalone S3
HTTP status were not supplied.

Sources:
- https://docs.aws.amazon.com/greengrass/v2/developerguide/device-service-role.html#device-service-role-access-s3-bucket
- https://docs.aws.amazon.com/cli/latest/reference/s3api/put-object.html
- https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_testing-policies.html
- https://github.com/aws-greengrass/aws-greengrass-lite/blob/584b9dadc5446e400f53ffa7d1b2c15dcc6b9e4f/modules/ggdeploymentd/src/deployment_handler.c

## Read-only board diagnosis when workstation checks pass

Copy tools/diagnose_s3.py to /root/diagnose_s3.py on the board. It requires
Python 3 and curl, which the image already includes. Supply one exact artifact
URI from the published component recipe, including its actual version/key:

```bash
python3 /root/diagnose_s3.py --uri 's3://YOUR_BUCKET/EXACT_PUBLISHED_OBJECT_KEY'
```

The default configuration file is /etc/greengrass/config.yaml. Use --config
/path/to/config.json for a JSON copy or another supported connection-kit YAML
file. The parser accepts the known nested scalar connection-kit format; it
refuses complex YAML or unresolved placeholders. The paths inside that file
must identify this board's actual certificate, private key and root CA.

It fetches fresh temporary credentials through the certificate-authenticated
IoT credentials provider, checks their caller ARN with STS, and requests byte
0 of the S3 object using curl's native SigV4 signing. These are read-only
requests; it changes no policies, bucket objects, deployments or services.
Temporary keys/tokens remain in memory and curl's stdin, not its command line,
files or output. The JSON includes only selected diagnostic fields and redacts
credential values if an error unexpectedly echoes them. It omits canonical
requests, Authorization headers and raw credential/error bodies.

Interpret the report:

- credential_provider HTTP 403: certificate/thing/role-alias authorization.
- caller_identity.Arn: the role actually obtained through this certificate.
- s3 HTTP 200/206: this fresh-credential read succeeded. Compare the daemon's
  effective configuration, cached credentials and signing behavior next.
- s3 Code AccessDenied: examine the identified principal/object and applicable
  explicit denies or KMS permissions. Full S3 on a different role is irrelevant.
- SignatureDoesNotMatch: investigate signer inputs/implementation, not a missing
  S3 allow. AuthorizationHeaderMalformed may identify a signing-Region mismatch.
- RequestTimeTooSkewed: compare board_utc and ServerTime/RequestTime if supplied.
- NoSuchKey: correct the published URI/object path using an unused version.

This uses the supplied bootstrap configuration and new credentials. It does
not claim to read the running daemon's effective database configuration or
cached token, and it does not exercise the daemon's custom signing library.
That independent comparison is intentional. A successful result does not
establish that ggdeploymentd used those same effective values or credentials.

The tests use fake credentials and mocked AWS replies plus an actual local TLS
curl request. The emitted signature is independently recomputed using HMAC.
No real device credentials or AWS API requests were used in authoring.

References:
- https://docs.aws.amazon.com/iot/latest/developerguide/authorizing-direct-aws.html
- https://docs.aws.amazon.com/STS/latest/APIReference/API_GetCallerIdentity.html
- https://curl.se/docs/manpage.html#--aws-sigv4

## Repair the confirmed clock problem


The pinned NXP base image installs ntpd, but the upstream OpenEmbedded ntp.conf
enables only `server 127.127.1.0` and `fudge ... stratum 14`. That LOCAL reference
can mark a wrong clock synchronized. The November 10 board diagnostic confirmed
S3 RequestTimeTooSkewed with the board approximately 6,391 seconds behind AWS;
its ntp.conf contained this exact local-clock-only configuration.

The layer now replaces that default with four external pool servers and iburst,
keeps ntpd enabled, and explicitly installs the separate ntpq package. The
completed-rootfs audit requires the configuration, binaries and ntpd unit and
rejects a LOCAL/orphan fallback or no external source. These static checks do
not establish live synchronization or server reachability. Greengrass startup
is not gated by this audit; check live UTC before provisioning or deployment.

For an existing board, run as root. This preserves the original configuration.
Use your organization's approved NTP servers instead of the public pool if
required. The network must permit DNS and NTP traffic (UDP port 123).

```sh
cp -an /etc/ntp.conf /etc/ntp.conf.before-external-ntp
cat > /etc/ntp.conf <<'EOF'
driftfile /var/lib/ntp/drift
server 0.pool.ntp.org iburst
server 1.pool.ntp.org iburst
server 2.pool.ntp.org iburst
server 3.pool.ntp.org iburst
restrict -4 default kod notrap nomodify nopeer noquery
restrict -6 default kod notrap nomodify nopeer noquery
restrict 127.0.0.1
restrict ::1
EOF
systemctl disable --now systemd-timesyncd.service
systemctl stop ntpd.service
if timeout 60 ntpd -gq -n -c /etc/ntp.conf; then
    systemctl enable --now ntpd.service
    date -u
else
    systemctl enable --now ntpd.service
    echo 'Time correction failed: check DNS, reachable NTP servers and UDP 123 before retrying AWS.'
fi
```

The pinned ntpd service already uses -g, which permits one initial large clock
correction. The one-shot -gq command performs that correction immediately when
an external server is reachable; it must finish successfully. A timeout is a
failure. Do not run it alongside a different clock-setting daemon. Leave
systemd-timesyncd disabled when using this image's ntpd.

On updated images, inspect `ntpq -pn` and `ntpq -c rv`: require a selected
external server (`*`), a nonzero reach register, a recent sample, a small offset
(the peer table uses milliseconds), and leap_none/stratum below 16. Allow a few
polls after restarting ntpd. Verify UTC against a trusted synchronized clock.
`timedatectl` saying yes/active, or an ntpd process running, is insufficient.
Older images may lack ntpq; the new image installs it explicitly. Once UTC is
correct, retry the Part 3 S3 diagnostic for HTTP 200/206 and retry the failed
deployment. A clock-only repair does not require another component version or
ELF. Write the RTC with `hwclock --systohc --utc` only after accurate UTC is
confirmed and if the board has a working retained RTC.
