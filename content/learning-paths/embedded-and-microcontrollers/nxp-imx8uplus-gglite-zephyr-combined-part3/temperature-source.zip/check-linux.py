#!/usr/bin/env python3
"""Read-only FRDM remoteproc preflight. Run on the Linux board as root."""
import struct
import sys
from pathlib import Path


def strings(path):
    return path.read_bytes().rstrip(b"\0").decode().split("\0") if path.exists() else []


def cells(path):
    data = path.read_bytes()
    return struct.unpack(f">{len(data) // 4}I", data)


def enabled(node):
    return not (node / "status").exists() or strings(node / "status") == ["okay"]


def check():
    root = Path("/sys/firmware/devicetree/base")
    compatible = strings(root / "compatible")
    assert any(c in compatible for c in ("fsl,frdm-imx8mp", "fsl,imx8mp-frdm")), "running DT is not FRDM-IMX8MPLUS"
    cmdline = Path("/proc/cmdline").read_text().split()
    assert any(p in cmdline for p in ("clk-imx8mp.mcore_booted", "clk-imx8mp.mcore_booted=1")), (
        "missing clk-imx8mp.mcore_booted in the running Linux command line; "
        "run prepare_mcore in U-Boot and use a boot path that passes mcore_clk")
    print("PASS: Linux received clk-imx8mp.mcore_booted")
    nodes = [p.parent for p in root.rglob("compatible")
             if any(c in strings(p) for c in ("fsl,imx8mn-cm7", "fsl,imx8mp-cm7")) and enabled(p.parent)]
    assert len(nodes) == 1, "need exactly one enabled i.MX8MP M7 remoteproc node"
    node = nodes[0]
    phandles = {cells(p)[0]: p.parent for p in root.rglob("phandle")}
    regions = [phandles[h] for h in cells(node / "memory-region")]
    expected = [("vdev0buffer", 0x55400000, 0x100000),
                ("vdev0vring0", 0x55000000, 0x8000),
                ("vdev0vring1", 0x55008000, 0x8000),
                ("rsc-table", 0x550ff000, 0x1000)]
    for name, address, size in expected:
        matches = [p for p in regions if p.name.split("@")[0] == name]
        assert len(matches) == 1, f"missing reserved-memory node named {name}@...; rebuild the corrected Part 1 DTB"
        p = matches[0]
        assert cells(p / "reg") == (0, address, 0, size), f"incorrect range: {p.name}"
        assert (p / "no-map").exists(), f"missing no-map: {p.name}"
        print(f"PASS: {p.name} size={size:#x}")
    assert regions[0].name.split("@")[0] == "vdev0buffer", "buffer pool must be memory-region index 0"
    uart4 = [p for p in root.rglob("serial@30a60000")]
    assert uart4 and all(not enabled(p) for p in uart4), "Linux must release UART4 to M7"
    processors = [p for p in Path("/sys/class/remoteproc").glob("remoteproc*")
                  if (p / "device/of_node").resolve() == node.resolve()]
    assert len(processors) == 1, "M7 remoteproc driver is missing or ambiguous"
    state = (processors[0] / "state").read_text().strip()
    assert state == "offline", f"M7 must be offline, found {state}"
    print(f"PASS: FRDM Linux DT, boot arguments, and {processors[0].name} configuration checks passed.")
    print("Verify the U-Boot control tree identifies FRDM separately; Linux cannot establish that here.")
    print("This checks DT and boot arguments; it does not test TCM hardware access or qualify firmware execution.")


if __name__ == "__main__":
    try:
        check()
    except (AssertionError, OSError, KeyError, ValueError, struct.error) as error:
        sys.exit(f"FAIL: {error}")
