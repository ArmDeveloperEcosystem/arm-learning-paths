# Reference-only recipe shape

These example files contain placeholder bucket names. They are not publication
inputs. Generate both real recipes from the staged artifacts with
python3 tools/make_recipes.py --bucket REAL_BUCKET --prefix REAL_PREFIX --region BOARD_REGION.
Then upload and preflight using artifact-plan.json. See ARTIFACT-DELIVERY.md.
