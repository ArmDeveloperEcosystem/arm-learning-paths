#!/usr/bin/env python3
"""Foreground remoteproc owner with a separate RPMsg quiescence endpoint."""
import argparse, fcntl, hashlib, json, os, select, shutil, signal, struct, subprocess, sys, tempfile, termios, threading, time, uuid
from pathlib import Path
PROFILE=Path('/etc/nxp-lp/board.json')
BOOT_ID_FILE=Path('/proc/sys/kernel/random/boot_id')
def boot_id():
    return str(uuid.UUID(BOOT_ID_FILE.read_text().strip()))
def profile():
    return json.loads(PROFILE.read_text())
def preflight():
    if profile().get('id')!='nxp-imx8uplus':return
    here=Path(__file__).resolve()
    candidates=(here.with_name('check-linux.py'),here.parent.parent/'check-linux.py')
    helper=next((p for p in candidates if p.is_file()),None)
    if helper is None:raise RuntimeError('FRDM preflight helper is missing; install the updated Part 1 tools')
    subprocess.run([sys.executable,str(helper)],check=True)
def find_mcore(root=Path('/sys/class/remoteproc')):
    expected=profile()['compatible'].encode()
    matches=[]
    for p in root.glob('remoteproc*'):
        node=p/'device/of_node/compatible'
        if node.exists() and expected in node.read_bytes().split(b'\0'): matches.append(p)
    if len(matches)!=1: raise RuntimeError(f'Expected one {expected!r} application core; found {matches}')
    return matches[0]
def validate_elf(path):
    h=path.read_bytes()[:20]
    if len(h)!=20 or h[:6]!=b'\x7fELF\x01\x01' or struct.unpack_from('<H',h,18)[0]!=40:
        raise ValueError('Expected an unstripped little-endian 32-bit Arm ELF')
def stage(artifact,work):
    validate_elf(artifact); d=work/'installed';d.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(artifact,d/'zephyr.elf');return d/'zephyr.elf'
def recover_locked(core,work):
    """Archive recorded files only while the caller holds mcore.lock."""
    if (core/'state').read_text().strip()!='offline':
        raise RuntimeError('Recovery requires an offline application MCU')
    owner_file=work/'owner.json'
    if not owner_file.exists():return None
    if owner_file.is_symlink():raise RuntimeError('Refusing a symlinked owner record')
    record=json.loads(owner_file.read_text())
    digest=record.get('sha256','')
    if not isinstance(digest,str) or len(digest)!=64 or any(c not in '0123456789abcdef' for c in digest):
        raise RuntimeError('Invalid firmware digest in owner record; preserve files for inspection')
    name=profile()['id']+'-gg-'+digest[:16]+'.elf'
    if record.get('core')!=str(core) or record.get('firmware')!=name:
        raise RuntimeError('Owner record does not match this core and firmware profile')
    firmware=Path('/lib/firmware')/name
    if firmware.is_symlink():raise RuntimeError('Refusing a symlinked firmware file')
    if firmware.exists() and (not firmware.is_file() or hashlib.sha256(firmware.read_bytes()).hexdigest()!=digest):
        raise RuntimeError('Recorded firmware has changed; preserve files for inspection')
    restore=(core/'firmware').read_text().strip()==name
    previous=record.get('previous','')
    if restore and (not isinstance(previous,str) or not previous or any(c in previous for c in '\x00\r\n')):
        raise RuntimeError('Invalid previous firmware selection in owner record')
    recovery=work/'recovery';recovery.mkdir(mode=0o700,exist_ok=True)
    archive=recovery/os.path.basename(tempfile.mkdtemp(prefix='owner-',dir=recovery))
    if firmware.exists():firmware.rename(archive/name)
    installed=work/'installed'
    if installed.exists() or installed.is_symlink():installed.rename(archive/'installed')
    if restore:(core/'firmware').write_text(previous)
    owner_file.rename(archive/'owner.json')
    print(f'MCore: archived stale ownership and owned files in {archive}',flush=True)
    return archive
def recover(work):
    work.mkdir(parents=True,exist_ok=True)
    with (work/'mcore.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        result=recover_locked(find_mcore(),work)
        if result is None:print('MCore: no stale owner record',flush=True)
        return result
def exchange(command,expected,timeout=8):
    deadline=time.monotonic()+timeout
    port=Path('/dev/nxp-mcore-control')
    while not port.exists():
        if time.monotonic()>deadline:raise TimeoutError('RPMsg control endpoint did not appear')
        time.sleep(.1)
    fd=os.open(port,os.O_RDWR|os.O_NOCTTY|os.O_NONBLOCK)
    try:
        fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
        attrs=termios.tcgetattr(fd);attrs[0]=0;attrs[1]=0;attrs[3]=0
        termios.tcsetattr(fd,termios.TCSANOW,attrs);termios.tcflush(fd,termios.TCIFLUSH)
        os.write(fd,command+b'\n');received=b''
        while time.monotonic()<deadline:
            if select.select([fd],[],[],.1)[0]:
                received+=os.read(fd,1024)
                if expected in received.splitlines():return
                if len(received)>4096:raise RuntimeError('Invalid control response')
        raise TimeoutError(f'No {expected!r} acknowledgment')
    finally:os.close(fd)
def run(artifact,work):
    preflight()
    stopping=threading.Event()
    for sig in (signal.SIGTERM,signal.SIGINT):signal.signal(sig,lambda *_:stopping.set())
    work.mkdir(parents=True,exist_ok=True)
    with (work/'mcore.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        core=find_mcore();state=lambda:(core/'state').read_text().strip()
        owner_file=work/'owner.json'
        if state()!='offline':raise RuntimeError('Application MCU must be offline')
        current_boot=boot_id()
        if owner_file.exists():
            record=json.loads(owner_file.read_text())
            try:previous_boot=str(uuid.UUID(record.get('boot_id','')))
            except (ValueError,TypeError,AttributeError):previous_boot=None
            if previous_boot is None or previous_boot==current_boot:
                raise RuntimeError('Stale owner record: with the MCU offline, run firmware_manager.py recover --work '+str(work))
            recover_locked(core,work)
        elf=stage(artifact,work);digest=hashlib.sha256(elf.read_bytes()).hexdigest()
        name=profile()['id']+'-gg-'+digest[:16]+'.elf';dest=Path('/lib/firmware')/name
        previous=(core/'firmware').read_text().strip();copied=False;selected=False;started=False
        owner_file.write_text(json.dumps({'core':str(core),'firmware':name,'previous':previous,'sha256':digest,'boot_id':current_boot})+'\n')
        try:
            print(f'MCore: installing firmware={name}',flush=True)
            with dest.open('xb') as output,elf.open('rb') as source:
                copied=True;shutil.copyfileobj(source,output)
            os.chmod(dest,0o644);(core/'firmware').write_text(name);selected=True
            print('MCore: entering Linux remoteproc start (ELF load and M7 release)',flush=True)
            started=True;(core/'state').write_text('start')
            print('MCore: Linux remoteproc start returned',flush=True)
            if state()!='running':raise RuntimeError('Application MCU did not start')
            exchange(b'HELLO',b'READY')
            print(f'MCore started firmware={name} sha256={digest}',flush=True)
            while not stopping.wait(1):
                if state()!='running':raise RuntimeError('Unexpected MCU state')
        finally:
            if started and state()=='running':
                if (core/'firmware').read_text().strip()!=name:raise RuntimeError('MCU ownership changed')
                exchange(b'STOP',b'QUIESCED')
                time.sleep(.05)
                (core/'state').write_text('stop')
            if state()!='offline':raise RuntimeError('MCU not offline; preserve owner record')
            if selected:(core/'firmware').write_text(previous)
            if copied:dest.unlink(missing_ok=True)
            shutil.rmtree(work/'installed',ignore_errors=True);owner_file.unlink()
            print('MCore offline; firmware selection restored; installed files removed',flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('phase',choices=['install','run','recover']);p.add_argument('--artifact',type=Path);p.add_argument('--work',type=Path,required=True)
    a=p.parse_args();a.work.mkdir(parents=True,exist_ok=True)
    if a.phase!='recover' and a.artifact is None:p.error('--artifact is required for install/run')
    if a.phase=='recover':recover(a.work)
    elif a.phase=='install':stage(a.artifact,a.work)
    else:run(a.artifact,a.work)
