#!/usr/bin/env python3
"""Host-only ownership recovery checks; fake sysfs, never target hardware."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch
import fcntl

BUNDLE = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('manager', BUNDLE / 'components/firmware_manager.py')
manager = importlib.util.module_from_spec(spec)
spec.loader.exec_module(manager)
CURRENT_BOOT = '11111111-1111-4111-8111-111111111111'
OLD_BOOT = '22222222-2222-4222-8222-222222222222'


class CorePath(type(Path())):
    def write_text(self, data, *args, **kwargs):
        if self.name == 'state':
            data = {'start': 'running', 'stop': 'offline'}.get(data, data)
        return super().write_text(data, *args, **kwargs)


class RecoveryChecks(unittest.TestCase):
    def setUp(self):
        area = tempfile.TemporaryDirectory()
        self.addCleanup(area.cleanup)
        self.root = Path(area.name)
        self.core = CorePath(self.root / 'core')
        self.core.mkdir()
        (self.core / 'state').write_text('offline')
        (self.core / 'firmware').write_text('boot-default')
        self.work = self.root / 'work'
        self.work.mkdir()
        self.firmware_dir = self.root / 'firmware'
        self.firmware_dir.mkdir()
        header = bytearray(20)
        header[:6] = b'\x7fELF\x01\x01'
        header[18] = 40
        self.artifact = self.root / 'header-fixture.elf'
        self.artifact.write_bytes(header)
        self.digest = hashlib.sha256(header).hexdigest()
        self.name = 'test-nxp-gg-' + self.digest[:16] + '.elf'
        self.owned = self.firmware_dir / self.name
        self.owner = self.work / 'owner.json'
        for context in (
            patch.object(manager, 'find_mcore', return_value=self.core),
            patch.object(manager, 'profile', return_value={'id': 'test-nxp'}),
            patch.object(manager, 'boot_id', return_value=CURRENT_BOOT),
            patch.object(manager, 'preflight'),
            patch.object(manager, 'Path', return_value=self.firmware_dir),
            patch.object(manager.signal, 'signal'),
            patch.object(manager.threading, 'Event', return_value=types.SimpleNamespace(wait=lambda _: True)),
        ):
            context.start()
            self.addCleanup(context.stop)

    def seed(self, boot=None):
        record = {'core': str(self.core), 'firmware': self.name,
                  'sha256': self.digest, 'previous': 'previous.elf'}
        if boot is not None:
            record['boot_id'] = boot
        self.owner.write_text(json.dumps(record))
        self.owned.write_bytes(self.artifact.read_bytes())
        installed = self.work / 'installed'
        installed.mkdir()
        (installed / 'zephyr.elf').write_bytes(self.artifact.read_bytes())
        return record

    def test_explicit_recovery_archives_legacy_record_and_preserves_lock(self):
        record = self.seed()
        lock = self.work / 'mcore.lock'
        lock.touch()
        inode = lock.stat().st_ino
        unrelated = self.firmware_dir / 'unrelated.elf'
        unrelated.write_bytes(b'keep')
        archive = manager.recover(self.work)
        self.assertEqual(json.loads((archive / 'owner.json').read_text()), record)
        self.assertEqual((archive / self.name).read_bytes(), self.artifact.read_bytes())
        self.assertTrue((archive / 'installed/zephyr.elf').is_file())
        self.assertEqual(lock.stat().st_ino, inode)
        self.assertEqual(unrelated.read_bytes(), b'keep')
        self.assertFalse(self.owner.exists())
        self.assertFalse(self.owned.exists())
        self.assertEqual((self.core / 'firmware').read_text(), 'boot-default')

    def test_recovery_rejects_running_core_without_changes(self):
        self.seed()
        (self.core / 'state').write_text('running')
        with self.assertRaisesRegex(RuntimeError, 'offline'):
            manager.recover(self.work)
        self.assertTrue(self.owner.is_file())
        self.assertTrue(self.owned.is_file())
        self.assertFalse((self.work / 'recovery').exists())

    def test_recovery_rejects_live_work_lock(self):
        self.seed()
        with (self.work / 'mcore.lock').open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            with self.assertRaises(BlockingIOError):
                manager.recover(self.work)
        self.assertTrue(self.owner.is_file())

    def test_recovery_rejects_changed_firmware(self):
        self.seed()
        self.owned.write_bytes(b'changed')
        with self.assertRaisesRegex(RuntimeError, 'has changed'):
            manager.recover(self.work)
        self.assertTrue(self.owner.is_file())
        self.assertFalse((self.work / 'recovery').exists())

    def test_recovery_rejects_foreign_or_invalid_records(self):
        record = self.seed()
        for key, value in [('core', '/another/core'), ('firmware', '../other.elf'), ('sha256', 'bad')]:
            self.owner.write_text(json.dumps({**record, key: value}))
            with self.assertRaises(RuntimeError):
                manager.recover(self.work)
            self.assertFalse((self.work / 'recovery').exists())

    def test_recovery_rejects_symlinks(self):
        self.seed()
        self.owned.unlink()
        self.owned.symlink_to(self.artifact)
        with self.assertRaisesRegex(RuntimeError, 'symlinked firmware'):
            manager.recover(self.work)
        self.assertTrue(self.artifact.is_file())
        self.owned.unlink()
        saved = self.work / 'saved-owner'
        self.owner.rename(saved)
        self.owner.symlink_to(saved)
        with self.assertRaisesRegex(RuntimeError, 'symlinked owner'):
            manager.recover(self.work)
        self.assertTrue(saved.is_file())

    def test_recovery_tolerates_already_missing_owned_firmware(self):
        self.seed()
        self.owned.unlink()
        archive = manager.recover(self.work)
        self.assertTrue((archive / 'owner.json').is_file())

    def test_recovery_restores_prior_selection_only_if_owned_name_is_selected(self):
        self.seed()
        (self.core / 'firmware').write_text(self.name)
        manager.recover(self.work)
        self.assertEqual((self.core / 'firmware').read_text(), 'previous.elf')

    def test_run_recovers_previous_boot_then_reuses_same_elf(self):
        self.seed(OLD_BOOT)
        with patch.object(manager, 'exchange') as exchange:
            manager.run(self.artifact, self.work)
        self.assertEqual(exchange.call_args_list[0].args, (b'HELLO', b'READY'))
        self.assertEqual(exchange.call_args_list[1].args, (b'STOP', b'QUIESCED'))
        archives = list((self.work / 'recovery').iterdir())
        self.assertEqual(len(archives), 1)
        self.assertTrue((archives[0] / self.name).is_file())
        self.assertFalse(self.owner.exists())
        self.assertEqual((self.core / 'state').read_text(), 'offline')
        self.assertEqual((self.core / 'firmware').read_text(), 'boot-default')

    def test_run_never_auto_recovers_same_boot_legacy_or_invalid_boot(self):
        record = self.seed()
        for boot in (None, CURRENT_BOOT, 'invalid'):
            changed = dict(record)
            if boot is not None:
                changed['boot_id'] = boot
            self.owner.write_text(json.dumps(changed))
            with self.assertRaisesRegex(RuntimeError, 'recover --work'):
                manager.run(self.artifact, self.work)
            self.assertTrue(self.owned.is_file())
            self.assertFalse((self.work / 'recovery').exists())

    def test_run_records_current_boot_before_startup_handshake(self):
        def exchange(*_):
            self.assertEqual(json.loads(self.owner.read_text())['boot_id'], CURRENT_BOOT)
        with patch.object(manager, 'exchange', side_effect=exchange):
            manager.run(self.artifact, self.work)
        self.assertFalse(self.owner.exists())

    def test_no_owner_recovery_is_idempotent(self):
        self.assertIsNone(manager.recover(self.work))
        self.assertFalse((self.work / 'recovery').exists())


if __name__ == '__main__':
    unittest.main(verbosity=2)
