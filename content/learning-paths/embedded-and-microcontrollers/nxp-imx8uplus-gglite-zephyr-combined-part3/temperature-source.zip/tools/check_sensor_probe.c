/* Host-only test of the actual acquisition code with an emulated I2C device. */
#include <assert.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include "test-platform.h"
#include "../firmware/src/sensor.c"

struct device test_bus = { .name = "i2c@30a40000" };
static bool ready = true;
static int errors[2], reads;
static uint8_t ids[2];
static char output[4096];
static size_t used;

bool device_is_ready(const struct device *dev) { assert(dev == &test_bus); return ready; }
void k_msleep(int ms) { (void)ms; }
int printk(const char *format, ...)
{
    va_list args;
    va_start(args, format);
    int count = vsnprintf(output + used, sizeof(output) - used, format, args);
    va_end(args);
    assert(count >= 0 && (size_t)count < sizeof(output) - used);
    used += (size_t)count;
    return count;
}
int i2c_write_read(const struct device *dev, uint16_t address, const void *reg,
                   size_t reg_count, void *data, size_t count)
{
    assert(dev == &test_bus && reg_count == 1 && address >= 0x76 && address <= 0x77);
    reads++;
    unsigned int slot = address - 0x76;
    if (errors[slot]) return errors[slot];
    uint8_t *bytes = data;
    switch (*(const uint8_t *)reg) {
    case 0xd0: assert(count == 1); bytes[0] = ids[slot]; break;
    case 0xf3: assert(count == 1); bytes[0] = 0; break;
    case 0x88: {
        const uint8_t calibration_bytes[] = {0x70, 0x6b, 0x43, 0x67, 0x18, 0xfc};
        assert(count == sizeof(calibration_bytes));
        memcpy(bytes, calibration_bytes, count);
        break;
    }
    case 0xfa: {
        const uint32_t raw = 519888;
        assert(count == 3);
        bytes[0] = (uint8_t)(raw >> 12);
        bytes[1] = (uint8_t)(raw >> 4);
        bytes[2] = (uint8_t)(raw << 4);
        break;
    }
    default: assert(false);
    }
    return 0;
}
int i2c_write(const struct device *dev, const void *data, size_t count, uint16_t address)
{
    (void)data;
    assert(dev == &test_bus && count == 2 && ids[address - 0x76] == 0x58);
    return 0;
}
static void reset(void)
{
    configured = false; sensor_address = 0; ready = true; reads = 0;
    errors[0] = errors[1] = -EIO;
    ids[0] = ids[1] = 0xff;
    used = 0; output[0] = '\0';
}
int main(void)
{
    int32_t temperature;
    reset();
    assert(lp_sensor_sample(&temperature) == -EIO);
    assert(strstr(output, "addr=0x76 read_rc=-5 (no chip ID read)"));
    assert(strstr(output, "addr=0x77 read_rc=-5 (no chip ID read)"));
    puts("PASS: bus read errors preserved and both addresses diagnosed");

    reset(); ready = false;
    assert(lp_sensor_sample(&temperature) == -ENODEV && reads == 0);
    assert(strstr(output, "I2C controller i2c@30a40000 is not ready"));
    puts("PASS: unready controller identified before any transaction");

    reset(); errors[0] = 0; ids[0] = 0x60;
    assert(lp_sensor_sample(&temperature) == -ENODEV);
    assert(strstr(output, "BME280 ID 0x60 detected"));
    puts("PASS: incompatible BME280 is explicitly identified");

    reset(); errors[0] = 0; ids[0] = 0;
    assert(lp_sensor_sample(&temperature) == -ENODEV);
    assert(strstr(output, "read_rc=0 chip_id=0x00"));
    puts("PASS: unexpected chip ID is reported without invented sensor data");

    for (int slot = 0; slot < 2; slot++) {
        reset(); errors[slot] = 0; ids[slot] = 0x58;
        assert(lp_sensor_sample(&temperature) == 0);
        assert(temperature == 25080000);
        assert(sensor_address == 0x76 + slot);
        assert(strstr(output, "read_rc=0 chip_id=0x58"));
        printf("PASS: accepted BMP280 at 0x%02x produces compensated temperature\n", 0x76 + slot);
    }

    reset(); errors[0] = errors[1] = 0; ids[0] = ids[1] = 0x58;
    assert(lp_sensor_sample(&temperature) == -EINVAL && sensor_address == 0);
    puts("PASS: ambiguous pair of BMP280 devices is rejected");

    reset(); errors[0] = errors[1] = -ETIMEDOUT;
    assert(lp_sensor_sample(&temperature) == -ETIMEDOUT);
    char expected_timeout[80];
    snprintf(expected_timeout, sizeof(expected_timeout), "read_rc=%d (no chip ID read)", -ETIMEDOUT);
    assert(strstr(output, expected_timeout));
    puts("PASS: timeout is preserved instead of becoming device-not-found");
    return 0;
}
