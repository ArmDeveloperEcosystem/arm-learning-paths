#!/usr/bin/env python3
"""Upload exactly the immutable objects referenced by the generated recipes."""
import argparse
import base64
from pathlib import Path
import subprocess
from artifact_utils import aws, check_region, check_remote, head, load_plan


def upload(plan_file, bucket=None, prefix=None, region=None):
    plan_file = Path(plan_file).resolve()
    plan = load_plan(plan_file, bucket, prefix, region)
    check_region(plan)
    for artifact in plan['artifacts']:
        try:
            remote = head(plan, artifact)
        except subprocess.CalledProcessError as error:
            if not any(text in (error.stderr or '') for text in ('(404)', 'Not Found', 'NoSuchKey', 'NotFound')):
                raise
        else:
            check_remote(artifact, remote)
            print('Already uploaded and verified: ' + artifact['uri'])
            continue
        checksum = base64.b64encode(bytes.fromhex(artifact['sha256'])).decode()
        try:
            aws(plan['region'], 's3api', 'put-object', '--bucket', artifact['bucket'],
                '--key', artifact['key'], '--body', str(plan_file.parent / artifact['source']),
                '--checksum-algorithm', 'SHA256', '--checksum-sha256', checksum, '--if-none-match', '*')
        except subprocess.CalledProcessError as error:
            if not any(text in (error.stderr or '') for text in ('(412)', 'PreconditionFailed')):
                raise
        check_remote(artifact, head(plan, artifact))
        print('Uploaded and verified: ' + artifact['uri'], flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, default=Path('artifact-plan.json'))
    parser.add_argument('--bucket')
    parser.add_argument('--prefix')
    parser.add_argument('--region')
    args = parser.parse_args()
    try:
        upload(args.plan, args.bucket, args.prefix, args.region)
    except subprocess.CalledProcessError as error:
        raise SystemExit(error.stderr or str(error))
    except (OSError, ValueError, KeyError) as error:
        raise SystemExit('Artifact upload refused: ' + str(error))
