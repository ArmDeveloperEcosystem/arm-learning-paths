#!/usr/bin/env python3
"""Compile the real hardware-I2C acquisition path against a host I2C emulator."""
from pathlib import Path
import shutil
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
compiler = shutil.which('cc')
if not compiler:
    raise SystemExit('A host C compiler is required')
with tempfile.TemporaryDirectory(prefix='bmp280-probe-') as directory:
    root = Path(directory)
    platform = root / 'test-platform.h'
    platform.write_text('''#ifndef TEST_PLATFORM_H
#define TEST_PLATFORM_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
struct device { const char *name; };
extern struct device test_bus;
#define DT_ALIAS(name) 0
#define DEVICE_DT_GET(node) (&test_bus)
#define DT_PROP(node, property) 100000U
bool device_is_ready(const struct device *);
void k_msleep(int);
int printk(const char *, ...);
int i2c_write_read(const struct device *, uint16_t, const void *, size_t, void *, size_t);
int i2c_write(const struct device *, const void *, size_t, uint16_t);
#endif
''')
    for name in ('zephyr/kernel.h', 'zephyr/drivers/i2c.h',
                 'zephyr/drivers/gpio.h', 'zephyr/sys/printk.h'):
        header = root / name
        header.parent.mkdir(parents=True, exist_ok=True)
        header.write_text('#include "test-platform.h"\n')
    binary = root / 'test-sensor-probe'
    subprocess.run([compiler, '-std=c99', '-Wall', '-Wextra', '-Werror',
                    '-fsanitize=undefined', '-I', str(root),
                    str(HERE / 'check_sensor_probe.c'), '-o', str(binary)], check=True)
    subprocess.run([str(binary)], check=True)
