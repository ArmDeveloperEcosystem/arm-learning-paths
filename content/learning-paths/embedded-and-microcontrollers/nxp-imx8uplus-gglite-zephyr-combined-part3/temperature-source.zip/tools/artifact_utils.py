"""Shared artifact identity and AWS CLI checks; never handles device credentials."""
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys


def version(value=None):
    value = value or json.loads((Path(__file__).resolve().parents[1] / 'release.json').read_text())['version']
    if not re.fullmatch(r'(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)', value):
        raise ValueError('Use a numeric major.minor.patch component version')
    return value


def location(bucket, prefix, region):
    if (not re.fullmatch(r'[a-z0-9][a-z0-9-]{1,61}[a-z0-9]', bucket)
            or bucket.startswith(('replace-with-', 'amzn-s3-demo-'))):
        raise ValueError('Set a real private bucket name using lowercase letters, digits and hyphens')
    prefix = prefix.strip('/')
    if not prefix or any(not re.fullmatch(r'[A-Za-z0-9_-][A-Za-z0-9_.-]*', p)
                         or p in ('.', '..') for p in prefix.split('/')):
        raise ValueError('Use a nonempty S3 prefix without empty segments, traversal, spaces or URL escapes')
    if not region or not re.fullmatch(r'(us|eu|ap|sa|ca|me|af|il|mx)-[a-z]+-[0-9]+', region):
        raise ValueError('Set --region/AWS_REGION to the commercial AWS Region configured on the board')
    return bucket, prefix, region


def fingerprint(path):
    if path.is_symlink() or not path.is_file() or not path.stat().st_size:
        raise ValueError('Artifact must be a nonempty regular file: ' + str(path))
    return {'size': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def write_plan(staging, output, recipes, bucket, prefix, region, release):
    plan_file = output.parent / 'artifact-plan.json'
    entries = []
    recipe_files = []
    for recipe in recipes:
        name = recipe['ComponentName']
        recipe_file = output / (name + '.json')
        recipe_files.append({'path': os.path.relpath(recipe_file, plan_file.parent),
                             **fingerprint(recipe_file)})
        for artifact in recipe['Manifests'][0]['Artifacts']:
            uri = artifact['URI']
            key = uri.removeprefix('s3://' + bucket + '/')
            filename = key.rsplit('/', 1)[1]
            if not re.fullmatch(r'[A-Za-z0-9_.-]+', filename):
                raise ValueError('Unsupported artifact filename: ' + filename)
            source = staging / name / release / filename
            entries.append({'uri': uri, 'bucket': bucket, 'key': key,
                            'source': os.path.relpath(source, plan_file.parent), **fingerprint(source)})
    plan = {'schema': 1, 'bucket': bucket, 'prefix': prefix, 'region': region,
            'version': release, 'components': sorted(r['ComponentName'] for r in recipes),
            'recipes': recipe_files, 'artifacts': entries}
    plan_file.write_text(json.dumps(plan, indent=2) + '\n')
    policy = {'Version': '2012-10-17', 'Statement': [
        {'Effect': 'Allow', 'Action': 's3:GetObject',
         'Resource': [f'arn:aws:s3:::{bucket}/{prefix}/{name}/*' for name in plan['components']]},
        {'Effect': 'Allow', 'Action': 's3:GetBucketLocation', 'Resource': f'arn:aws:s3:::{bucket}'},
    ]}
    (output.parent / 'artifact-access.json').write_text(json.dumps(policy, indent=2) + '\n')
    return plan_file


def load_plan(path, bucket=None, prefix=None, region=None):
    path = Path(path).resolve()
    plan = json.loads(path.read_text())
    if plan.get('schema') != 1:
        raise ValueError('Unsupported artifact plan; regenerate recipes')
    location(plan['bucket'], plan['prefix'], plan['region'])
    version(plan['version'])
    if plan['version'] != version():
        raise ValueError('Artifact plan does not match release.json; restage and regenerate')
    for key, supplied in [('bucket', bucket), ('prefix', prefix.strip('/') if prefix is not None else None), ('region', region)]:
        if supplied is not None and supplied != plan[key]:
            raise ValueError(key + ' does not match artifact-plan.json; regenerate rather than uploading elsewhere')
    uris = []
    for recipe in plan['recipes']:
        source = path.parent / recipe['path']
        if fingerprint(source) != {k: recipe[k] for k in ('size', 'sha256')}:
            raise ValueError('Recipe changed after generation: ' + str(source))
        document = json.loads(source.read_text())
        if document['ComponentName'] not in plan['components'] or document['ComponentVersion'] != plan['version']:
            raise ValueError('Recipe identity does not match artifact plan')
        uris.extend(a['URI'] for m in document['Manifests'] for a in m['Artifacts'])
    planned = [a['uri'] for a in plan['artifacts']]
    if not planned or len(planned) != len(set(planned)) or sorted(planned) != sorted(uris):
        raise ValueError('Recipe URIs and planned upload objects do not match')
    for artifact in plan['artifacts']:
        if artifact['bucket'] != plan['bucket'] or artifact['uri'] != 's3://' + plan['bucket'] + '/' + artifact['key']:
            raise ValueError('Artifact URI does not match its bucket/key')
        pieces = artifact['key'].split('/')
        if len(pieces) < 4:
            raise ValueError('Invalid artifact object key')
        expected = [plan['prefix'], pieces[-3], plan['version'], pieces[-1]]
        if expected[1] not in plan['components'] or artifact['key'] != '/'.join(expected):
            raise ValueError('Artifact key does not match release/component prefix')
        source = path.parent / artifact['source']
        if fingerprint(source) != {k: artifact[k] for k in ('size', 'sha256')}:
            raise ValueError('Staged bytes changed after recipe generation: ' + str(source))
    return plan


def aws(region, *arguments):
    result = subprocess.run(['aws', '--region', region, *arguments, '--output', 'json'],
                            check=True, capture_output=True, text=True)
    return json.loads(result.stdout or '{}')


def check_region(plan):
    result = aws(plan['region'], 's3api', 'get-bucket-location', '--bucket', plan['bucket'])
    actual = result.get('LocationConstraint') or 'us-east-1'
    actual = 'eu-west-1' if actual == 'EU' else actual
    if actual != plan['region']:
        raise ValueError(f"Bucket Region is {actual}; pinned Lite signs using board awsRegion={plan['region']}")


def head(plan, artifact):
    return aws(plan['region'], 's3api', 'head-object', '--bucket', artifact['bucket'],
               '--key', artifact['key'], '--checksum-mode', 'ENABLED')


def check_remote(artifact, remote):
    expected = base64.b64encode(bytes.fromhex(artifact['sha256'])).decode()
    if remote.get('ContentLength') != artifact['size'] or remote.get('ChecksumSHA256') != expected:
        raise ValueError('Remote bytes unverified or different at ' + artifact['uri'] +
                         '; preserve published objects and use a new version/key')


if __name__ == '__main__':
    print(version(sys.argv[1] if len(sys.argv) == 2 else None))
