#!/usr/bin/env python3
"""Mocked tests: no AWS requests, certificates or real credentials."""
import json
import hashlib
import hmac
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
import re
import shutil
import ssl
import subprocess
import tempfile
import threading
import types
import unittest
from unittest.mock import patch
import diagnose_s3 as diagnostic

CREDS = {'accessKeyId': 'AKIAFAKE000000000000', 'secretAccessKey': 'FAKEsecret/not-a-real-key',
         'sessionToken': 'FAKEsession+not-a-real-token', 'expiration': '2030-01-01T00:00:00Z'}
IDENTITY = b'<GetCallerIdentityResponse xmlns="https://sts.amazonaws.com/doc/2011-06-15/"><GetCallerIdentityResult><Arn>arn:aws:sts::123456789012:assumed-role/DeviceRole/session</Arn></GetCallerIdentityResult></GetCallerIdentityResponse>'


class DiagnosticTests(unittest.TestCase):
    def setUp(self):
        area = tempfile.TemporaryDirectory()
        self.addCleanup(area.cleanup)
        self.root = Path(area.name)
        self.settings = {'thing': 'MyBoard', 'region': 'us-east-1', 'alias': 'MyAlias',
                         'endpoint': 'example.credentials.iot.us-east-1.amazonaws.com'}
        for field in ('cert', 'key', 'ca'):
            path = self.root / field
            path.write_text('not a real certificate or key')
            self.settings[field] = str(path)
        self.document = {'system': {'thingName': 'MyBoard', 'certificateFilePath': self.settings['cert'],
                                    'privateKeyPath': self.settings['key'], 'rootCaPath': self.settings['ca']},
                         'services': {'aws.greengrass.NucleusLite': {'configuration': {
                             'awsRegion': 'us-east-1', 'iotRoleAlias': 'MyAlias',
                             'iotCredEndpoint': self.settings['endpoint']}}}}

    def assert_no_credentials(self, report):
        text = json.dumps(report)
        for name in ('accessKeyId', 'secretAccessKey', 'sessionToken'):
            self.assertNotIn(CREDS[name], text)

    def test_json_settings_and_credential_paths(self):
        path = self.root / 'config.json'
        path.write_text(json.dumps(self.document))
        self.assertEqual(diagnostic.load_settings(path), self.settings)

    def test_connection_kit_yaml_quotes_and_comments(self):
        path = self.root / 'config.yaml'
        path.write_text('''---
system:
  thingName: "MyBoard"
  certificateFilePath: CERT
  privateKeyPath: 'KEY'
  rootCaPath: CA # root CA
services:
  aws.greengrass.NucleusLite:
    componentType: NUCLEUS
    configuration:
      awsRegion: us-east-1
      iotRoleAlias: MyAlias
      iotCredEndpoint: ENDPOINT
'''.replace('CERT', self.settings['cert']).replace('KEY', self.settings['key'])
           .replace('CA #', self.settings['ca'] + ' #').replace('ENDPOINT', self.settings['endpoint']))
        self.assertEqual(diagnostic.load_settings(path), self.settings)

    def test_wrong_credential_host_or_templates_are_rejected(self):
        path = self.root / 'config.json'
        config = self.document['services']['aws.greengrass.NucleusLite']['configuration']
        for host in ('https://untrusted.example', '{{endpoint}}'):
            config['iotCredEndpoint'] = host
            path.write_text(json.dumps(self.document))
            with self.assertRaises(ValueError):
                diagnostic.load_settings(path)

    def test_curl_uses_stdin_for_secrets_and_preserves_error_body(self):
        body = b'<Error><Code>AccessDenied</Code></Error>'
        result = types.SimpleNamespace(returncode=0, stdout=body + diagnostic.MARKER + b'403', stderr=b'')
        with patch.object(diagnostic.subprocess, 'run', return_value=result) as run:
            self.assertEqual(diagnostic.request('https://bucket.s3.us-east-1.amazonaws.com/key',
                             self.settings['ca'], region='us-east-1', service='s3', credentials=CREDS), (403, body))
        argv = run.call_args.args[0]
        config = run.call_args.kwargs['input'].decode()
        for name in ('accessKeyId', 'secretAccessKey', 'sessionToken'):
            self.assertNotIn(CREDS[name], ' '.join(argv))
            self.assertIn(CREDS[name], config)
        self.assertEqual(argv[1], '-q')
        self.assertNotIn('--insecure', argv)
        self.assertNotIn('--location', argv)
        self.assertIn('aws-sigv4 = "aws:amz:us-east-1:s3"', config)

    def test_successful_fresh_credentials_identity_and_range_read(self):
        with patch.object(diagnostic, 'request', side_effect=[
            (200, json.dumps({'credentials': CREDS}).encode()), (200, IDENTITY), (206, b'P')]) as request:
            result = diagnostic.diagnose(self.settings, 's3://private-bucket/nxp/artifact.whl')
        self.assertEqual(result['s3']['http_status'], 206)
        self.assertIn('assumed-role/DeviceRole/', result['caller_identity']['Arn'])
        self.assertEqual(request.call_args.kwargs['headers'], {'Range': 'bytes=0-0'})
        self.assertEqual(request.call_args.kwargs['service'], 's3')
        self.assert_no_credentials(result)

    def test_credential_denial_stops_before_signed_requests(self):
        with patch.object(diagnostic, 'request', return_value=(403, b'{"message":"Access denied"}')) as request:
            result = diagnostic.diagnose(self.settings, 's3://private-bucket/nxp/file')
        self.assertEqual(request.call_count, 1)
        self.assertEqual(result['credential_provider']['http_status'], 403)
        self.assertNotIn('s3', result)

    def test_signature_error_is_reported_and_secrets_are_redacted(self):
        body = ('<Error><Code>SignatureDoesNotMatch</Code><Message>' + CREDS['accessKeyId'] + ' ' +
                CREDS['secretAccessKey'] + ' ' + CREDS['sessionToken'] + '</Message><CanonicalRequest>' +
                CREDS['sessionToken'] + '</CanonicalRequest></Error>').encode()
        with patch.object(diagnostic, 'request', side_effect=[
            (200, json.dumps({'credentials': CREDS}).encode()), (200, IDENTITY), (403, body)]):
            result = diagnostic.diagnose(self.settings, 's3://private-bucket/nxp/file')
        self.assertEqual(result['s3']['Code'], 'SignatureDoesNotMatch')
        self.assertNotIn('CanonicalRequest', result['s3'])
        self.assert_no_credentials(result)

    def test_sts_failure_does_not_prevent_s3_read(self):
        with patch.object(diagnostic, 'request', side_effect=[
            (200, json.dumps({'credentials': CREDS}).encode()), RuntimeError('STS unreachable'), (206, b'x')]):
            result = diagnostic.diagnose(self.settings, 's3://private-bucket/nxp/file')
        self.assertEqual(result['s3']['http_status'], 206)
        self.assertEqual(result['caller_identity']['error'], 'STS unreachable')

    def test_clock_error_exposes_only_safe_fields(self):
        result = diagnostic.describe(403, b'<Error><Code>RequestTimeTooSkewed</Code><ServerTime>2030-01-01T00:00:00Z</ServerTime><RequestTime>2020-01-01T00:00:00Z</RequestTime><Signature>omit</Signature></Error>')
        self.assertEqual(result['Code'], 'RequestTimeTooSkewed')
        self.assertIn('ServerTime', result)
        self.assertNotIn('Signature', result)

    def test_config_injection_is_rejected(self):
        with self.assertRaises(ValueError):
            diagnostic.curl_quote('value\nverbose=true')

    @unittest.skipUnless(shutil.which('curl') and shutil.which('openssl'), 'curl and openssl needed')
    def test_real_curl_signing_over_local_tls(self):
        cert, key = self.root / 'tls-cert.pem', self.root / 'tls-key.pem'
        config = self.root / 'tls.cnf'
        config.write_text('[req]\ndistinguished_name=dn\nx509_extensions=v3\nprompt=no\n'
                          '[dn]\nCN=localhost\n[v3]\nsubjectAltName=DNS:localhost\n'
                          'basicConstraints=critical,CA:true\n')
        subprocess.run(['openssl', 'req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-days', '1',
                        '-config', str(config), '-keyout', str(key), '-out', str(cert)],
                       capture_output=True, check=True)
        observed = {}
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                observed.update(self.headers)
                self.send_response(403)
                self.end_headers()
                self.wfile.write(b'<Error><Code>AccessDenied</Code><Message>Local fixture</Message></Error>')
            def log_message(self, *_):
                pass
        server = HTTPServer(('127.0.0.1', 0), Handler)
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(cert, key)
        server.socket = context.wrap_socket(server.socket, server_side=True)
        worker = threading.Thread(target=server.serve_forever, daemon=True)
        worker.start()
        try:
            status, body = diagnostic.request('https://localhost:' + str(server.server_port) + '/object',
                str(cert), region='us-east-1', service='s3', credentials=CREDS,
                headers={'Range': 'bytes=0-0'})
        finally:
            server.shutdown()
            server.server_close()
            worker.join(timeout=3)
        self.assertEqual(status, 403)
        self.assertEqual(diagnostic.describe(status, body)['Code'], 'AccessDenied')
        headers = {k.lower(): v for k, v in observed.items()}
        self.assertEqual(headers['range'], 'bytes=0-0')
        self.assertEqual(headers['x-amz-security-token'], CREDS['sessionToken'])
        match = re.fullmatch(r'AWS4-HMAC-SHA256 Credential=([^/]+)/([^,]+), SignedHeaders=([^,]+), Signature=([a-f0-9]+)', headers['authorization'])
        self.assertIsNotNone(match)
        access_key, scope, signed, signature = match.groups()
        self.assertEqual(access_key, CREDS['accessKeyId'])
        canonical_headers = ''.join(name + ':' + ' '.join(headers[name].split()) + '\n'
                                    for name in signed.split(';'))
        empty = hashlib.sha256(b'').hexdigest()
        canonical = '\n'.join(['GET', '/object', '', canonical_headers, signed,
                                headers.get('x-amz-content-sha256', empty)])
        string_to_sign = '\n'.join(['AWS4-HMAC-SHA256', headers['x-amz-date'], scope,
                                    hashlib.sha256(canonical.encode()).hexdigest()])
        signing_key = ('AWS4' + CREDS['secretAccessKey']).encode()
        for segment in scope.split('/'):
            signing_key = hmac.new(signing_key, segment.encode(), hashlib.sha256).digest()
        self.assertEqual(hmac.new(signing_key, string_to_sign.encode(), hashlib.sha256).hexdigest(), signature)


if __name__ == '__main__':
    unittest.main(verbosity=2)
