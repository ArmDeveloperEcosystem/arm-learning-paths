#!/usr/bin/env python3
"""Read-only board test: certificate -> fresh role credentials -> signed S3 GET.

Only public diagnostics reach stdout. Credentials and signing options are sent
to curl through stdin, never command arguments, files or printed responses.
"""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import quote, urlsplit
import xml.etree.ElementTree as ET

MARKER = b'\n__NXP_HTTP_STATUS__='
FIELDS = {
    ('system', 'thingName'): 'thing',
    ('system', 'certificateFilePath'): 'cert',
    ('system', 'privateKeyPath'): 'key',
    ('system', 'rootCaPath'): 'ca',
    ('services', 'aws.greengrass.NucleusLite', 'configuration', 'awsRegion'): 'region',
    ('services', 'aws.greengrass.NucleusLite', 'configuration', 'iotRoleAlias'): 'alias',
    ('services', 'aws.greengrass.NucleusLite', 'configuration', 'iotCredEndpoint'): 'endpoint',
}


def scalar(text):
    text = text.strip()
    if text.startswith('"'):
        value, end = json.JSONDecoder().raw_decode(text)
        if text[end:].strip() and not text[end:].lstrip().startswith('#'):
            raise ValueError('Unsupported YAML scalar suffix')
        return value
    if text.startswith("'"):
        match = re.fullmatch(r"'((?:[^']|'')*)'\s*(?:#.*)?", text)
        if not match:
            raise ValueError('Unsupported quoted YAML scalar')
        return match[1].replace("''", "'")
    if text.startswith(('&', '*', '!', '|', '>', '[', '{')):
        raise ValueError('This diagnostic accepts simple connection-kit YAML or JSON; complex YAML needs conversion to JSON')
    return re.split(r'\s+#', text, maxsplit=1)[0].strip()


def load_settings(path):
    text = Path(path).read_text()
    found = {}
    if text.lstrip().startswith('{'):
        document = json.loads(text)
        for keys, name in FIELDS.items():
            value = document
            for key in keys:
                value = value[key]
            found[name] = value
    else:
        # Deliberately limited to the scalar, nested connection-kit configuration.
        stack = []
        for line in text.splitlines():
            if not line.strip() or line.lstrip().startswith(('#', '---', '...')):
                continue
            match = re.fullmatch(r'( *)([^:]+):(?:\s+(.*))?', line)
            if not match:
                raise ValueError('Unsupported YAML; provide a JSON copy of the configuration')
            indent, key, value = match.groups()
            while stack and stack[-1][0] >= len(indent):
                stack.pop()
            key = scalar(key)
            keys = tuple(k for _, k in stack) + (key,)
            if value is None or not value.strip() or value.lstrip().startswith('#'):
                stack.append((len(indent), key))
            elif keys in FIELDS:
                name = FIELDS[keys]
                if name in found:
                    raise ValueError('Duplicate configuration value: ' + name)
                found[name] = scalar(value)
    missing = set(FIELDS.values()) - set(found)
    if missing:
        raise ValueError('Missing configuration settings: ' + ', '.join(sorted(missing)))
    if any(not isinstance(value, str) or not value or '\n' in value or '\r' in value
           or '{{' in value for value in found.values()):
        raise ValueError('Configuration contains empty, multiline or unresolved template values')
    host = found['endpoint'].removeprefix('https://').rstrip('/')
    if not re.fullmatch(r'[a-z0-9-]+\.credentials\.iot\.[a-z0-9-]+\.amazonaws\.com', host):
        raise ValueError('Expected a commercial AWS IoT credentials-provider hostname')
    if not re.fullmatch(r'[a-z]{2}-[a-z]+-\d+', found['region']):
        raise ValueError('Unsupported AWS Region')
    found['endpoint'] = host
    for name in ('cert', 'key', 'ca'):
        if not Path(found[name]).is_file():
            raise ValueError('Configured credential file is missing: ' + found[name])
    return found


def curl_quote(value):
    if '\n' in value or '\r' in value or '\0' in value:
        raise ValueError('Invalid multiline curl configuration value')
    return '"' + value.replace('\\', '\\\\').replace('"', '\\"') + '"'


def request(url, ca, cert=None, key=None, region=None, service=None, credentials=None, headers=None):
    options = [('url', url), ('cacert', ca)]
    if cert:
        options += [('cert', cert), ('key', key)]
    if credentials:
        options += [('aws-sigv4', f'aws:amz:{region}:{service}'),
                    ('user', credentials['accessKeyId'] + ':' + credentials['secretAccessKey']),
                    ('header', 'x-amz-security-token: ' + credentials['sessionToken'])]
    options += [('header', name + ': ' + value) for name, value in (headers or {}).items()]
    config = ''.join(name + ' = ' + curl_quote(value) + '\n' for name, value in options)
    result = subprocess.run(['curl', '-q', '--silent', '--show-error', '--connect-timeout', '10',
                             '--max-time', '30', '--max-filesize', '65536', '--proto', '=https',
                             '--path-as-is', '--globoff', '--config', '-',
                             '--write-out', MARKER.decode() + '%{http_code}'],
                            input=config.encode(), capture_output=True)
    body, separator, status = result.stdout.rpartition(MARKER)
    if result.returncode or not separator:
        raise RuntimeError(result.stderr.decode(errors='replace').strip() or 'curl transport failed')
    return int(status), body


def xml_value(root, key):
    node = root.find('.//{*}' + key)
    return node.text if node is not None else None


def describe(status, body):
    result = {'http_status': status}
    if 200 <= status < 300:
        return result
    try:
        root = ET.fromstring(body)
        for key in ('Code', 'Message', 'Region', 'RequestId', 'ServerTime', 'RequestTime'):
            value = xml_value(root, key)
            if value:
                result[key] = value
    except ET.ParseError:
        try:
            document = json.loads(body)
            if isinstance(document.get('message'), str):
                result['Message'] = document['message']
        except (ValueError, AttributeError):
            result['Message'] = 'Non-XML/JSON error body omitted'
    return result


def diagnose(settings, uri):
    target = urlsplit(uri)
    if (target.scheme != 's3' or not re.fullmatch(r'[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]', target.netloc)
            or not target.path.startswith('/') or len(target.path) < 2 or target.query or target.fragment):
        raise ValueError('Use the exact s3://bucket/object-key artifact URI, without query or fragment')
    report = {'board_utc': datetime.now(timezone.utc).isoformat(), 'region': settings['region'],
              'role_alias': settings['alias'], 'thing_name': settings['thing'], 'artifact_uri': uri,
              'scope': 'Fresh credentials using supplied bootstrap configuration; not the running daemon cache.'}
    credentials = {}
    try:
        url = 'https://' + settings['endpoint'] + '/role-aliases/' + quote(settings['alias'], safe='') + '/credentials'
        status, body = request(url, settings['ca'], cert=settings['cert'], key=settings['key'],
                               headers={'x-amzn-iot-thingname': settings['thing']})
        report['credential_provider'] = describe(status, body)
        if status != 200:
            return report
        document = json.loads(body)
        if not isinstance(document, dict) or not isinstance(document.get('credentials'), dict):
            raise ValueError('Credential provider returned an invalid credential structure')
        credentials = document['credentials']
        if any(not isinstance(credentials.get(k), str) or not credentials[k]
               for k in ('accessKeyId', 'secretAccessKey', 'sessionToken')):
            raise ValueError('Credential provider returned an invalid credential structure')
        report['credential_provider']['expiration'] = credentials.get('expiration')
        sts_url = 'https://sts.' + settings['region'] + '.amazonaws.com/?Action=GetCallerIdentity&Version=2011-06-15'
        try:
            status, body = request(sts_url, settings['ca'], region=settings['region'], service='sts', credentials=credentials)
            report['caller_identity'] = describe(status, body)
            if status == 200:
                root = ET.fromstring(body)
                report['caller_identity']['Arn'] = xml_value(root, 'Arn')
        except (RuntimeError, ET.ParseError) as error:
            report['caller_identity'] = {'error': str(error)}
        # S3 keys are literal, and are encoded for the HTTP request without path normalization.
        path = quote(target.path, safe='/-_.~')
        url = 'https://' + target.netloc + '.s3.' + settings['region'] + '.amazonaws.com' + path
        status, body = request(url, settings['ca'], region=settings['region'], service='s3',
                               credentials=credentials, headers={'Range': 'bytes=0-0'})
        report['s3'] = describe(status, body)
    except (ValueError, RuntimeError, KeyError) as error:
        report['error'] = str(error)
    finally:
        # Never emit credentials, even if an error message unexpectedly echoes one.
        encoded = json.dumps(report)
        for name in ('accessKeyId', 'secretAccessKey', 'sessionToken'):
            secret = credentials.get(name)
            if isinstance(secret, str) and secret:
                encoded = encoded.replace(json.dumps(secret)[1:-1], '[REDACTED]')
        report.clear()
        report.update(json.loads(encoded))
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, default=Path('/etc/greengrass/config.yaml'))
    parser.add_argument('--uri', required=True)
    args = parser.parse_args()
    try:
        result = diagnose(load_settings(args.config), args.uri)
        result['configuration_file'] = str(args.config)
        print(json.dumps(result, indent=2))
        sys.exit(0 if result.get('s3', {}).get('http_status') in (200, 206) else 1)
    except (OSError, ValueError, KeyError) as error:
        sys.exit('S3 diagnostic could not run: ' + str(error))
