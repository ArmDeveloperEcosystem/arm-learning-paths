#!/usr/bin/env python3
"""Artifact workflow regressions using local files and mocked AWS responses."""
import base64
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import artifact_utils as util
import make_recipes as recipes
import upload
import check_artifact_access as access


class ArtifactTests(unittest.TestCase):
    def setUp(self):
        area = tempfile.TemporaryDirectory()
        self.addCleanup(area.cleanup)
        self.root = Path(area.name)
        self.staging = self.root / 'staging'
        for component, names in (
            (recipes.FIRMWARE, ['zephyr.elf', 'firmware_manager.py', 'check-linux.py']),
            (recipes.BRIDGE, ['bridge.py', 'bridge_lifecycle.sh', 'awsiotsdk-1.26.0-py3-none-any.whl',
                              'awscrt-0.28.1-cp311-abi3-manylinux2014_aarch64.whl']),
        ):
            folder = self.staging / component / recipes.VERSION
            folder.mkdir(parents=True)
            for name in names:
                (folder / name).write_bytes(('fixture-' + name).encode())
        self.plan = recipes.write_recipes(self.staging, self.root / 'recipes', 'private-bucket',
                                         '/nested/nxp/', region='us-east-1')
        self.data = util.load_plan(self.plan)

    def remote(self, artifact):
        return {'ContentLength': artifact['size'],
                'ChecksumSHA256': base64.b64encode(bytes.fromhex(artifact['sha256'])).decode()}

    def test_exact_upload_recipe_and_policy_paths(self):
        self.assertEqual(len(self.data['artifacts']), 7)
        self.assertEqual(self.data['prefix'], 'nested/nxp')
        policy = json.loads((self.root / 'artifact-access.json').read_text())
        resources = policy['Statement'][0]['Resource']
        self.assertEqual(set(resources), {f'arn:aws:s3:::private-bucket/nested/nxp/{c}/*' for c in self.data['components']})
        for artifact in self.data['artifacts']:
            self.assertIn('/' + recipes.VERSION + '/', artifact['uri'])

    def test_placeholder_region_and_unsafe_prefix_rejected(self):
        for bucket, prefix, region in [('replace-with-your-private-bucket', 'nxp', 'us-east-1'),
                                       ('private-bucket', '../nxp', 'us-east-1'),
                                       ('private-bucket', 'nxp//bad', 'us-east-1'),
                                       ('private-bucket', 'nxp', None)]:
            with self.assertRaises(ValueError):
                util.location(bucket, prefix, region)

    def test_bucket_prefix_or_region_drift_rejected_before_aws(self):
        with patch.object(upload, 'check_region') as call:
            for field, value in [('bucket', 'different-bucket'), ('prefix', 'other'), ('region', 'eu-west-1')]:
                with self.assertRaisesRegex(ValueError, 'does not match'):
                    upload.upload(self.plan, **{field: value})
            call.assert_not_called()

    def test_staged_or_recipe_bytes_cannot_change_after_generation(self):
        source = self.root / self.data['artifacts'][0]['source']
        saved = source.read_bytes()
        source.write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError, 'Staged bytes changed'):
            util.load_plan(self.plan)
        source.write_bytes(saved)
        recipe = self.root / self.data['recipes'][0]['path']
        recipe.write_text(recipe.read_text() + ' ')
        with self.assertRaisesRegex(ValueError, 'Recipe changed'):
            util.load_plan(self.plan)

    def test_wrong_bucket_region_rejected(self):
        with patch.object(util, 'aws', return_value={'LocationConstraint': 'eu-west-1'}):
            with self.assertRaisesRegex(ValueError, 'Bucket Region is eu-west-1'):
                util.check_region(self.data)

    def test_old_plan_after_release_change_is_rejected(self):
        with patch.object(util, 'version', return_value='2.0.0'):
            with self.assertRaisesRegex(ValueError, 'does not match release.json'):
                util.load_plan(self.plan)

    def test_extra_bridge_artifact_is_rejected(self):
        (self.staging / recipes.BRIDGE / recipes.VERSION / 'unexpected.txt').write_bytes(b'extra')
        with self.assertRaisesRegex(ValueError, 'exactly'):
            recipes.write_recipes(self.staging, self.root / 'other-recipes', 'private-bucket', 'nxp', region='us-east-1')

    def test_upload_uses_only_plan_and_can_resume_identical_objects(self):
        (self.staging / 'unrelated.txt').write_bytes(b'never upload')
        with patch.object(upload, 'check_region'), \
             patch.object(upload, 'head', side_effect=lambda _, a: self.remote(a)), \
             patch.object(upload, 'aws') as put:
            upload.upload(self.plan)
            put.assert_not_called()

    def test_missing_objects_uploaded_conditionally_with_checksum(self):
        absent = subprocess.CalledProcessError(254, ['aws'], stderr='An error occurred (404): Not Found')
        sequence = []
        for artifact in self.data['artifacts']:
            sequence.extend([absent, self.remote(artifact)])
        with patch.object(upload, 'check_region'), patch.object(upload, 'head', side_effect=sequence), \
             patch.object(upload, 'aws', return_value={}) as put:
            upload.upload(self.plan)
            self.assertEqual(put.call_count, 7)
            for call in put.call_args_list:
                self.assertIn('--if-none-match', call.args)
                self.assertIn('--checksum-sha256', call.args)

    def test_conflicting_existing_object_never_overwritten(self):
        with patch.object(upload, 'check_region'), patch.object(upload, 'head', return_value={'ContentLength': 0}), \
             patch.object(upload, 'aws') as put:
            with self.assertRaisesRegex(ValueError, 'Remote bytes'):
                upload.upload(self.plan)
            put.assert_not_called()

    def test_head_403_never_triggers_upload(self):
        denied = subprocess.CalledProcessError(254, ['aws'], stderr='An error occurred (403): Forbidden')
        with patch.object(upload, 'check_region'), patch.object(upload, 'head', side_effect=denied), \
             patch.object(upload, 'aws') as put:
            with self.assertRaises(subprocess.CalledProcessError):
                upload.upload(self.plan)
            put.assert_not_called()

    def test_conditional_write_race_verifies_winner_bytes(self):
        absent = subprocess.CalledProcessError(254, ['aws'], stderr='An error occurred (404): Not Found')
        race = subprocess.CalledProcessError(254, ['aws'], stderr='An error occurred (412): PreconditionFailed')
        sequence = []
        for artifact in self.data['artifacts']:
            sequence.extend([absent, self.remote(artifact)])
        with patch.object(upload, 'check_region'), patch.object(upload, 'head', side_effect=sequence), \
             patch.object(upload, 'aws', side_effect=race):
            upload.upload(self.plan)

    def fake_aws(self, region, service, operation, *args):
        self.assertEqual(region, 'us-east-1')
        if operation == 'describe-role-alias':
            self.assertEqual(args, ('--role-alias', 'BoardAlias'))
            return {'roleAliasDescription': {'roleArn': 'arn:aws:iam::123456789012:role/ActualDeviceRole'}}
        self.assertEqual(operation, 'simulate-principal-policy')
        self.assertIn('arn:aws:iam::123456789012:role/ActualDeviceRole', args)
        return {'EvaluationResults': [{'EvalResourceName': 'arn:aws:s3:::' + a['bucket'] + '/' + a['key'],
                                       'EvalDecision': self.decision} for a in self.data['artifacts']]}

    def test_preflight_resolves_actual_alias_role_and_checks_all_objects(self):
        self.decision = 'allowed'
        with patch.object(access, 'check_region'), patch.object(access, 'aws', side_effect=self.fake_aws), \
             patch.object(access, 'head', side_effect=lambda _, a: self.remote(a)):
            result = access.check(self.plan, 'BoardAlias')
            self.assertEqual(result['artifacts'], 7)
            self.assertIn('ActualDeviceRole', result['role_arn'])

    def test_preflight_denied_role_stops_before_object_checks(self):
        self.decision = 'implicitDeny'
        with patch.object(access, 'check_region'), patch.object(access, 'aws', side_effect=self.fake_aws), \
             patch.object(access, 'head') as head:
            with self.assertRaisesRegex(ValueError, 'IAM simulation did not allow'):
                access.check(self.plan, 'BoardAlias')
            head.assert_not_called()

    def test_kms_requires_explicit_verification(self):
        self.decision = 'allowed'
        with patch.object(access, 'check_region'), patch.object(access, 'aws', side_effect=self.fake_aws), \
             patch.object(access, 'head', side_effect=lambda _, a: {**self.remote(a), 'ServerSideEncryption': 'aws:kms'}):
            with self.assertRaisesRegex(ValueError, 'SSE-KMS'):
                access.check(self.plan, 'BoardAlias')


if __name__ == '__main__':
    unittest.main(verbosity=2)
