#!/usr/bin/env python3
"""Read-only workstation checks of generated S3 objects and the device role."""
import argparse
import json
from pathlib import Path
import subprocess
from artifact_utils import aws, check_region, check_remote, head, load_plan


def check(plan_file, role_alias):
    plan = load_plan(plan_file)
    check_region(plan)
    alias = aws(plan['region'], 'iot', 'describe-role-alias', '--role-alias', role_alias)
    role = alias['roleAliasDescription']['roleArn']
    resources = ['arn:aws:s3:::' + a['bucket'] + '/' + a['key'] for a in plan['artifacts']]
    result = aws(plan['region'], 'iam', 'simulate-principal-policy', '--policy-source-arn', role,
                 '--action-names', 's3:GetObject', '--resource-arns', *resources)
    evaluated = {r['EvalResourceName']: r['EvalDecision'] for r in result['EvaluationResults']}
    denied = [r for r in resources if evaluated.get(r) != 'allowed']
    if denied:
        raise ValueError('IAM simulation did not allow ' + role + ' to read: ' + ', '.join(denied) +
                         '; attach generated artifact-access.json to this role and inspect missing context, denies and boundaries')
    for artifact in plan['artifacts']:
        remote = head(plan, artifact)
        check_remote(artifact, remote)
        if remote.get('ServerSideEncryption') == 'aws:kms':
            raise ValueError('Artifact uses SSE-KMS: verify kms:Decrypt and the KMS key policy for ' + role +
                             '; this preflight does not qualify KMS access')
    return {'result': 'pass', 'region': plan['region'], 'role_alias': role_alias,
            'role_arn': role, 'version': plan['version'], 'artifacts': len(resources),
            'limits': 'IAM simulation and workstation HEAD requests do not test device credentials, bucket/SCP/VPC policies or board clock/signing.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, default=Path('artifact-plan.json'))
    parser.add_argument('--role-alias', required=True, help='Exact iotRoleAlias configured on the board')
    parser.add_argument('--report', type=Path, default=Path('artifact-preflight.json'))
    args = parser.parse_args()
    try:
        result = check(args.plan, args.role_alias)
        args.report.write_text(json.dumps(result, indent=2) + '\n')
        print(f"PASS: {result['artifacts']} artifacts, bucket Region and simulated S3 reads for {result['role_arn']}")
        print(result['limits'])
    except subprocess.CalledProcessError as error:
        raise SystemExit(error.stderr or str(error))
    except (OSError, ValueError, KeyError) as error:
        raise SystemExit('Artifact preflight failed: ' + str(error))
