# FRDM-IMX8MPLUS managed temperature firmware

Use the corrected Part 1 image for `imx8mp-lpddr4-frdm`. The user reported
successful Part 2 heartbeat execution after rebuilding that image, with a
completed control handshake and continuous RPMsg sequences. The former EVK
boot image still hung with an ELF-only update.

In the Part 2 Zephyr virtual environment, with SDK 0.17.4 installed:

```bash
cd "$HOME/nxp-imx8uplus-temperature-part3"
source "$HOME/nxp-imx8uplus-zephyr-venv/bin/activate"
export ZEPHYR_WORKSPACE="$HOME/nxp-imx8uplus-zephyr-workspace"
export ZEPHYR_TOOLCHAIN_VARIANT=zephyr
export ZEPHYR_SDK_INSTALL_DIR="$HOME/zephyr-sdk-0.17.4"
bash setup-zephyr-sdk.sh
bash build-zephyr.sh temperature
python3 inspect-elf.py build/temperature/zephyr/zephyr.elf
sh tools/stage.sh build/temperature/zephyr/zephyr.elf 313
python3 tools/check.py
```

Use your installed SDK directory and the board's Python major/minor version.
The helper checks the pinned Zephyr v4.3.0 commit and SDK, applies both
resource-table patches idempotently and validates the resulting ELF. The
upstream target remains `imx8mp_evk/mimx8ml8/m7` for SoC support; the supplied
FRDM clock override preserves shared roots/PLLs, and the temperature overlay
enables M7-owned I2C3. Heartbeat disables I2C3/GPIO. No `BOARD_ROOT` is needed.

The corrected Part 1 boot defaults run `prepare_mcore` automatically. No extra
manual U-Boot adjustment is needed when `/proc/cmdline` contains
`clk-imx8mp.mcore_booted` and the Linux preflight passes with M7 offline. Part 1's
setup page covers recovery only for a saved environment overriding defaults.

`tools/stage.sh` inspects the ELF before copying artifacts. The firmware recipe
must include all three files: `zephyr.elf`, `firmware_manager.py`, and
`check-linux.py`. The manager runs that preflight before changing firmware or
remoteproc state, then requires HELLO/READY. The bridge uses a separate RPMsg
TTY, validates real BMP280 frames and publishes to
`nxp/imx8mplus/temperature/external` through Greengrass IPC.

Follow the learning path for wiring, pinned offline AArch64 Python wheels,
private S3 artifacts, recipes, IAM/IoT permissions and deployment. The default release is 1.0.1. If that version is already published, select an
unused version in release.json before restaging; preserve published artifacts.

Cross-compilation and host checks are documented in `../validation/`.
Physical BMP280 acquisition, stop/restart qualification and AWS deployment
remain to be tested. Heartbeat success does not establish those results.

## MCU ownership recovery (November 9, 2026)

The shared manager now records the Linux boot ID, recovers verified previous-boot
ownership only with the core offline, and provides explicit recovery for legacy
records. Owned files are archived and the existing lock is retained. See
[MCU-RECOVERY.md](MCU-RECOVERY.md) for updating an existing image and the host
validation limits.

## BMP280 probe diagnostics (November 9, 2026)

The firmware now reports controller readiness, per-address read errors and chip
IDs instead of hiding every discovery failure behind -19. See SENSOR-PROBE.md
for interpretation and validation limits.

## Artifact delivery correction (November 9, 2026)

The release is now 1.0.1, selected once in release.json. Generate recipes with
a real bucket/prefix/board Region, then use artifact-plan.json for uploads and
the read-only role/object preflight. The generated artifact-access.json grants
the existing device role S3 reads for the two component prefixes. Reference
JSON moved to examples/recipes; regenerate any old recipes/ files after
extracting this update. See ARTIFACT-DELIVERY.md for the complete sequence and
403 interpretation. No AWS policy, bucket or deployment was modified here.

## Native build-host tools

Ubuntu x86_64 and arm64/aarch64 are accepted automatically. Activate the pinned
Zephyr Python environment (Python 3.12+) and set ZEPHYR_WORKSPACE, then run
`bash setup-zephyr-sdk.sh` from this bundle. It asks Zephyr v4.3.0's installer
for SDK 0.17.4 and arm-zephyr-eabi; west selects linux-x86_64 or linux-aarch64.
Existing SDKs are checked without replacement. Set ZEPHYR_SDK_INSTALL_DIR to
the installer-reported path, or a fresh host-specific directory when changing
hosts. The build helper checks the SDK metadata, executable tools, compiler
execution and Arm target before patching source or running CMake. The SDK's
host architecture differs from the MCU target: both hosts produce the same
board-specific Arm firmware. macOS x86_64/Arm SDK detection remains available
for Zephyr/staging; Yocto requires Linux. Host-matrix tests mock external tools;
full native Ubuntu arm64 compilation remains an acceptance check.

Staging always selects Linux AArch64 Python wheels for the FRDM board, on either host architecture.
