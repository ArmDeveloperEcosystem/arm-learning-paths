# Shared host detection. POSIX shell so staging helpers can source this too.
lp_detect_host() {
    LP_HOST_OS=$(uname -s)
    case "$(uname -m)" in
        x86_64|amd64|AMD64) LP_HOST_ARCH=x86_64 ;;
        aarch64|arm64) LP_HOST_ARCH=aarch64 ;;
        *) echo 'Unsupported build host: use x86_64 or arm64/aarch64.' >&2; return 1 ;;
    esac
    case "$LP_HOST_OS" in
        Linux) LP_SDK_PLATFORM=linux-$LP_HOST_ARCH ;;
        Darwin) LP_SDK_PLATFORM=macos-$LP_HOST_ARCH ;;
        *) echo 'Unsupported host OS: use Ubuntu Linux (or macOS for Zephyr/staging).' >&2; return 1 ;;
    esac
}
