# Diagnose BMP280 discovery

The older acquisition code returned -ENODEV (-19) for both failed I2C reads and
an unexpected chip ID. The updated configure_sensor() prints probe v1, hardware
controller readiness/name, and the read result at each of 0x76 and 0x77. It
prints a chip ID only when register 0xd0 was actually read. If both reads fail,
the original first bus error is preserved. A BME280 response (0x60) is identified
and still rejected; BMP280 requires 0x58. A successful sample still uses the
same calibrated temperature conversion and RPMsg schema.

Interpret the new MCU DEBUG output:

- Controller not ready: investigate Zephyr device initialization/configuration.
- read_rc=0, chip_id=0x58: accepted BMP280 at that address.
- read_rc=0, another ID: the responding device does not match this app.
- Negative read_rc: the transaction failed; no chip ID was obtained. The NXP
  I2C driver maps several hardware failures to -EIO (-5), so this alone does
  not prove that a NACK, clock, wiring or power fault is the cause.

Open the MCU debug console before loading. Stop the existing owner normally,
then load the temperature diagnostic ELF. Successful temperature samples go
over RPMsg; the UART does not print every temperature.

Eight host scenarios compile and execute the actual hardware-I2C acquisition
source using emulated bus operations, including both accepted addresses,
controller-not-ready, bus errors/timeouts, wrong IDs and ambiguous devices.
Run python3 tools/test_sensor_probe.py on a host with a C compiler. These
checks do not validate physical pins, analog levels, GPIO I2C or real sensors.
Clock roots, pin routing, resource tables and transport were not changed by
this diagnostic update.

## FRDM-IMX8MPLUS B1 header verification

NXP's SCH-95022_B1 netlist and schematic show J18.3 = I2C3_SDA_3V3 and
J18.5 = I2C3_SCL_3V3, connected through U58 to the SoC's dedicated I2C3 pins.
J18.1/J18.17 supply VCC_EXT_3V3; J18.6/J18.20 are GND. Keep the corrected
BMP280 CSB -> J18.17 and SDO -> J18.20 wiring. This confirms the existing I2C3
selection for B1; the user board's revision and electrical readings still
need checking. The older manual's GPIO RXC/RXFS labels are not sufficient
evidence to change this board to I2C6.

Source: https://www.nxp.com/downloads/en/schematics/FRDM-IMX8MPLUS-SCH-95022_B1.zip
The netlist's exact connections were checked, along with schematic sheets 6,
21 and 24. Read-only voltage checks on the sensor module should verify VCC,
CSB and idle SDA/SCL relative to sensor GND. Do not run a Linux I2C scan while
the M7 owns this bus.

A prebuilt diagnostic ELF is supplied in the learning path's elf directory as
temperature-i2c-diagnostic.elf. It was cross-compiled using the same pinned
Zephyr/SDK and passed inspect-elf.py. It has not been tested on the board.
Copy it to /root/temperature-i2c-diagnostic.elf, then on the board:

```bash
nxp-mcore stop
nxp-mcore load /root/temperature-i2c-diagnostic.elf
journalctl -u nxp-mcore-test.service -b -f
```

Use the updated ownership manager from MCU-RECOVERY.md if a stale record blocks
loading. Capture the BMP280 probe lines from the separate M7 DEBUG console.
No Yocto rebuild is required to use this diagnostic artifact.
