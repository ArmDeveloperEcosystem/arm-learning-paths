# Generate publishable recipes here

Run tools/make_recipes.py with your real private bucket, prefix and board Region.
It creates both recipes, ../artifact-plan.json and ../artifact-access.json.
The reference-only JSON is under examples/recipes and must not be published.
If upgrading an extracted old bundle, regenerate to replace old recipes/ JSON.
Do not upload or register components until the artifact plan passes preflight.
