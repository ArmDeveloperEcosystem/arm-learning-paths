#!/usr/bin/env bash
set -Eeuo pipefail
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
mode=${1:-heartbeat}
[[ $mode == heartbeat || $mode == temperature ]] || { echo 'Usage: build-zephyr.sh heartbeat|temperature' >&2; exit 2; }
: "${ZEPHYR_WORKSPACE:?Set ZEPHYR_WORKSPACE to your west workspace}"
ZEPHYR="$ZEPHYR_WORKSPACE/zephyr"
[[ $(git -C "$ZEPHYR" rev-parse HEAD) == 3568e1b6d5cdd51a6b964a2a1d6d29200fea2056 ]] || { echo 'Use the pinned Zephyr v4.3.0 checkout.' >&2; exit 1; }

# Validate the host-native SDK before source patches or CMake configuration.
export ZEPHYR_TOOLCHAIN_VARIANT=${ZEPHYR_TOOLCHAIN_VARIANT:-zephyr}
[[ $ZEPHYR_TOOLCHAIN_VARIANT == zephyr ]] || { echo 'Use ZEPHYR_TOOLCHAIN_VARIANT=zephyr for this bundle.' >&2; exit 1; }
export ZEPHYR_SDK_INSTALL_DIR=${ZEPHYR_SDK_INSTALL_DIR:-$HOME/zephyr-sdk-0.17.4}
bash "$HERE/setup-zephyr-sdk.sh" --check

for patchfile in "$HERE/patches/0001-linux-resource-table.patch" \
                 "$HERE/patches/0002-keep-resource-table.patch"; do
    if git -C "$ZEPHYR" apply --check "$patchfile"; then git -C "$ZEPHYR" apply "$patchfile";
    elif ! git -C "$ZEPHYR" apply --reverse --check "$patchfile"; then echo "Source differs; preserve edits and inspect $patchfile" >&2; exit 1; fi
done
extra="$HERE/firmware/profile.conf"
extra_overlay=""
if [[ $mode == temperature ]]; then
    extra="$extra;$HERE/firmware/temperature.conf"
    extra_overlay="$HERE/firmware/temperature.overlay"
fi
cd "$ZEPHYR_WORKSPACE"
# This target is supplied by upstream Zephyr; the bundle has no local boards/.
west build -p always -b imx8mp_evk/mimx8ml8/m7 "$HERE/firmware" -d "$HERE/build/$mode" -- -DEXTRA_CONF_FILE="$extra" "-DEXTRA_DTC_OVERLAY_FILE=$extra_overlay"
file "$HERE/build/$mode/zephyr/zephyr.elf"
python3 "$HERE/inspect-elf.py" "$HERE/build/$mode/zephyr/zephyr.elf"
