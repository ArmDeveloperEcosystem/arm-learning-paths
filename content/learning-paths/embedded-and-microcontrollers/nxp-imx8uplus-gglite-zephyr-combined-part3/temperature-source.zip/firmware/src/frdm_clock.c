/* SPDX-License-Identifier: Apache-2.0 */
#include <fsl_clock.h>

/*
 * Linux remoteproc owns the M7 root; U-Boot/ATF own the shared clock tree.
 * Replace the weak i.MX8M SOC_ClockInit(), which switches the live AHB root
 * through 24 MHz. Never reparent AHB, M7, AXI, DRAM or reinitialize PLLs here.
 * SOC_RdcInit() still establishes the M7 domain before calling this function.
 */
void SOC_ClockInit(void)
{
    /* UART4 is dedicated to M7 by the companion Linux device tree. */
    CLOCK_SetRootMux(kCLOCK_RootUart4, kCLOCK_UartRootmuxSysPll1Div10);
    CLOCK_SetRootDivider(kCLOCK_RootUart4, 1U, 1U);

#ifdef CONFIG_APP_TEMPERATURE
    /* Only the temperature profile owns I2C3. */
    CLOCK_SetRootMux(kCLOCK_RootI2c3, kCLOCK_I2cRootmuxOsc24M);
    CLOCK_SetRootDivider(kCLOCK_RootI2c3, 1U, 1U);
#endif

    /* Retain the upstream enable-only clock gates without retuning roots. */
    CLOCK_EnableClock(kCLOCK_Rdc);
    CLOCK_EnableClock(kCLOCK_Ocram);
    CLOCK_EnableClock(kCLOCK_Sim_m);
    CLOCK_EnableClock(kCLOCK_Sim_main);
    CLOCK_EnableClock(kCLOCK_Sim_s);
    CLOCK_EnableClock(kCLOCK_Sim_wakeup);
    CLOCK_EnableClock(kCLOCK_Debug);
    CLOCK_EnableClock(kCLOCK_Dram);
    CLOCK_EnableClock(kCLOCK_Sec_Debug);
}
