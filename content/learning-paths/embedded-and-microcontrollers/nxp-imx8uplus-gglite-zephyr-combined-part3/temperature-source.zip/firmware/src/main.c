/* SPDX-License-Identifier: Apache-2.0
 * Transport follows Zephyr v4.3.0 openamp_rsc_table and the OpenAMP APIs.
 */
#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/ipm.h>
#include <zephyr/sys/printk.h>
#include <openamp/open_amp.h>
#include <metal/sys.h>
#include <metal/io.h>
#include <resource_table.h>
#include <addr_translation.h>
#include <stdio.h>
#include "board_name.h"
#include <string.h>
#ifdef CONFIG_APP_TEMPERATURE
#include "sensor.h"
#endif
#define SHM DT_CHOSEN(zephyr_ipc_shm)
static const struct device *const mailbox=DEVICE_DT_GET(DT_CHOSEN(zephyr_ipc));
static struct metal_io_region shared_io,table_io;
static metal_phys_addr_t shared_phys=DT_REG_ADDR(SHM),table_phys;
static struct rpmsg_virtio_device rvdev;
static struct rpmsg_endpoint telemetry,control;
static struct rpmsg_device *rpdev;
static void *table;
K_SEM_DEFINE(notification,0,1);
K_SEM_DEFINE(ready,0,1);
K_SEM_DEFINE(stop_requested,0,1);
static void notify_callback(const struct device *dev,void *context,uint32_t id,volatile void *data)
{ ARG_UNUSED(dev);ARG_UNUSED(context);ARG_UNUSED(id);ARG_UNUSED(data);k_sem_give(&notification); }
static int notify_linux(void *priv,uint32_t id)
{
    ARG_UNUSED(priv);
    /* Linux's <&mu 1 1> receives register 1, regardless of the vring ID. */
    uint32_t message=id << 16;
    return ipm_send(mailbox,0,1,&message,sizeof(message));
}
static int telemetry_rx(struct rpmsg_endpoint *ept,void *data,size_t len,uint32_t src,void *priv)
{ ARG_UNUSED(data);ARG_UNUSED(len);ARG_UNUSED(priv);ept->dest_addr=src;return RPMSG_SUCCESS; }
static int control_rx(struct rpmsg_endpoint *ept,void *data,size_t len,uint32_t src,void *priv)
{
    ARG_UNUSED(priv);ept->dest_addr=src;
    if(len>=4 && !memcmp(data,"STOP",4))k_sem_give(&stop_requested);
    else if(len>=5 && !memcmp(data,"HELLO",5))(void)rpmsg_trysend(ept,"READY\n",6);
    return RPMSG_SUCCESS;
}
static void transport(void *a,void *b,void *c)
{
    ARG_UNUSED(a);ARG_UNUSED(b);ARG_UNUSED(c);
    struct metal_init_params params=METAL_INIT_DEFAULTS;
    int size;
    if(metal_init(&params) || !device_is_ready(mailbox))goto failed;
    metal_io_init(&shared_io,(void *)DT_REG_ADDR(SHM),&shared_phys,DT_REG_SIZE(SHM),-1,0,addr_translation_get_ops(shared_phys));
    rsc_table_get(&table,&size);table_phys=(uintptr_t)table;
    struct fw_resource_table *resources=table;
    if(resources->hdr.ver!=1 || resources->hdr.num!=1 ||
       resources->vdev.id!=VIRTIO_ID_RPMSG)goto failed;
    metal_io_init(&table_io,table,&table_phys,size,-1,0,NULL);
    ipm_register_callback(mailbox,notify_callback,NULL);
    if(ipm_set_enabled(mailbox,1))goto failed;
    struct virtio_device *vdev=rproc_virtio_create_vdev(VIRTIO_DEV_DEVICE,VDEV_ID,rsc_table_to_vdev(table),&table_io,NULL,notify_linux,NULL);
    if(!vdev)goto failed;
    rproc_virtio_wait_remote_ready(vdev);
    struct fw_rsc_vdev_vring *rings[]={rsc_table_get_vring0(table),rsc_table_get_vring1(table)};
    for(int n=0;n<2;n++){
        /* Refuse rings allocated in Linux RAM outside our reserved carveouts. */
        uint32_t expected=0x55000000U + (uint32_t)n * 0x8000U;
        if(rings[n]->da!=expected || rings[n]->num!=8 || rings[n]->align!=16){
            printk("ERROR: vring %d da=0x%08x; fix Linux reserved-memory names\n",n,rings[n]->da);
            goto failed;
        }
        if(rproc_virtio_init_vring(vdev,n,rings[n]->notifyid,(void *)(uintptr_t)rings[n]->da,&shared_io,rings[n]->num,rings[n]->align))goto failed;
    }
    if(rpmsg_init_vdev(&rvdev,vdev,NULL,&shared_io,NULL))goto failed;
    rpdev=rpmsg_virtio_get_rpmsg_device(&rvdev);
    if(rpmsg_create_ept(&telemetry,rpdev,"rpmsg-tty",0x400,RPMSG_ADDR_ANY,telemetry_rx,NULL))goto failed;
    if(rpmsg_create_ept(&control,rpdev,"rpmsg-tty",0x401,RPMSG_ADDR_ANY,control_rx,NULL))goto failed;
    k_sem_give(&ready);
    for(;;){
        (void)k_sem_take(&notification,K_MSEC(20));
        rproc_virtio_notified(rvdev.vdev,RSC_NOTIFY_ID_ANY);
    }
failed:
    printk("ERROR: RPMsg initialization failed\n");
}
K_THREAD_DEFINE(transport_thread,4096,transport,NULL,NULL,NULL,7,0,0);
static void quiesce(void)
{
#ifdef CONFIG_APP_TEMPERATURE
    lp_sensor_sleep();
#endif
    int result=-1;
    for(int n=0;n<100 && result<0;n++){
        result=rpmsg_trysend(&control,"QUIESCED\n",9);
        if(result<0)k_msleep(10);
    }
    if(result<0){printk("ERROR: quiescence acknowledgment unavailable\n");for(;;)k_sleep(K_FOREVER);}
    k_msleep(20);
    (void)irq_lock();__asm__ volatile("dsb sy":::"memory");
    for(;;)__asm__ volatile("wfi":::"memory");
}
int main(void)
{
    printk("%s: Zephyr on application MCU\n",LP_BOARD_NAME);
    k_sem_take(&ready,K_FOREVER);
    unsigned int sequence=0;
    for(;;){
        char frame[256];int length;
#ifdef CONFIG_APP_TEMPERATURE
        int32_t micro_c;int rc=lp_sensor_sample(&micro_c);
        if(rc){printk("ERROR: external BMP280 acquisition: %d\n",rc);length=0;}
        else length=snprintf(frame,sizeof(frame),"{\"type\":\"nxp.external.temperature\",\"schema\":1,\"seq\":%u,\"uptime_ms\":%lld,\"temperature_uC\":%d}\n",sequence++,(long long)k_uptime_get(),(int)micro_c);
#else
        printk("MCU heartbeat %u\n",sequence);
        length=snprintf(frame,sizeof(frame),"{\"type\":\"nxp.heartbeat\",\"seq\":%u}\n",sequence++);
#endif
        if(length>0 && length<(int)sizeof(frame) && telemetry.dest_addr!=RPMSG_ADDR_ANY)(void)rpmsg_trysend(&telemetry,frame,length);
#ifdef CONFIG_APP_TEMPERATURE
        if(k_sem_take(&stop_requested,K_SECONDS(5))==0)quiesce();
#else
        if(k_sem_take(&stop_requested,K_SECONDS(1))==0)quiesce();
#endif
    }
    return 0;
}
