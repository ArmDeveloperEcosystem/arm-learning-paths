#pragma once
#include <stdint.h>
int lp_sensor_sample(int32_t *micro_c);
void lp_sensor_sleep(void);
