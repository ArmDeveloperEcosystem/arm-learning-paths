/* SPDX-License-Identifier: Apache-2.0 */
#include <errno.h>
#include <string.h>
#include <zephyr/kernel.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/sys/printk.h>
#include "bmp280_temperature.h"
#include "sensor.h"
#define BMP280_CHIP_ID 0x58
#define TRY(call) do { int rc_=(call); if(rc_<0)return rc_; } while(0)
static uint8_t sensor_address;
static struct bmp280_temperature_calibration calibration;
#ifdef CONFIG_LP_SOFT_I2C
#define SCL_PIN 3
#define SDA_PIN 2
static const struct device *const gpio=DEVICE_DT_GET(DT_NODELABEL(gpio2));
/* Software I2C drives LOW and releases HIGH by selecting INPUT.
 * External pull-ups provide the high level. */
static int line(unsigned int pin, bool high)
{
    int rc = gpio_pin_configure(gpio, pin, high ? GPIO_INPUT : GPIO_OUTPUT_LOW);
    k_busy_wait(5);
    return rc;
}

static int scl_high(void)
{
    TRY(line(SCL_PIN, true));
    for (int n = 0; n < 200; n++) {
        int value = gpio_pin_get(gpio, SCL_PIN);
        if (value < 0) return value;
        if (value) return 0;
        k_busy_wait(5);
    }
    return -ETIMEDOUT;
}

static int start(void)
{
    TRY(line(SDA_PIN, true));
    TRY(scl_high());
    int value = gpio_pin_get(gpio, SDA_PIN);
    if (value < 0) return value;
    if (!value) return -EBUSY;
    TRY(line(SDA_PIN, false));
    return line(SCL_PIN, false);
}

static int stop(void)
{
    TRY(line(SCL_PIN, false));
    TRY(line(SDA_PIN, false));
    TRY(scl_high());
    return line(SDA_PIN, true);
}

static int write_byte(uint8_t value)
{
    for (int bit = 7; bit >= 0; bit--) {
        TRY(line(SDA_PIN, (value & BIT(bit)) != 0));
        TRY(scl_high());
        TRY(line(SCL_PIN, false));
    }
    TRY(line(SDA_PIN, true));
    TRY(scl_high());
    int nack = gpio_pin_get(gpio, SDA_PIN);
    TRY(line(SCL_PIN, false));
    return nack < 0 ? nack : (nack ? -ENXIO : 0);
}

static int read_byte(uint8_t *value, bool last)
{
    *value = 0;
    TRY(line(SDA_PIN, true));
    for (int bit = 7; bit >= 0; bit--) {
        TRY(scl_high());
        int state = gpio_pin_get(gpio, SDA_PIN);
        if (state < 0) return state;
        *value |= state ? BIT(bit) : 0;
        TRY(line(SCL_PIN, false));
    }
    TRY(line(SDA_PIN, last)); /* ACK intermediate bytes, NACK final byte */
    TRY(scl_high());
    TRY(line(SCL_PIN, false));
    return line(SDA_PIN, true);
}

static int sensor_read(uint8_t reg, uint8_t *bytes, size_t count)
{
    TRY(start());
    TRY(write_byte(sensor_address << 1));
    TRY(write_byte(reg));
    TRY(start());
    TRY(write_byte((sensor_address << 1) | 1));
    for (size_t n = 0; n < count; n++) {
        TRY(read_byte(bytes + n, n + 1 == count));
    }
    return stop();
}

static int sensor_write(uint8_t reg, uint8_t value)
{
    TRY(start());
    TRY(write_byte(sensor_address << 1));
    TRY(write_byte(reg));
    TRY(write_byte(value));
    return stop();
}


#else
static const struct device *const bus=DEVICE_DT_GET(DT_ALIAS(temp_i2c));
static int sensor_read(uint8_t reg,uint8_t *bytes,size_t count)
{ if(!device_is_ready(bus))return -ENODEV;return i2c_write_read(bus,sensor_address,&reg,1,bytes,count); }
static int sensor_write(uint8_t reg,uint8_t value)
{ uint8_t bytes[]={reg,value};if(!device_is_ready(bus))return -ENODEV;return i2c_write(bus,bytes,2,sensor_address); }
static int stop(void){return 0;}
#endif
static int wait_sensor_idle(uint8_t mask)
{
    for (int n = 0; n < 30; n++) {
        uint8_t status;
        TRY(sensor_read(0xf3, &status, 1));
        if (!(status & mask)) return 0;
        k_msleep(2);
    }
    return -ETIMEDOUT;
}

static int configure_sensor(void)
{
    uint8_t found = 0;
    int matches = 0;
    int read_failures = 0, first_error = 0;
#ifndef CONFIG_LP_SOFT_I2C
    if (!device_is_ready(bus)) {
        printk("BMP280 probe: I2C controller %s is not ready\n", bus->name);
        return -ENODEV;
    }
    printk("BMP280 probe v1: bus=%s, speed=%u Hz, chip-ID register=0xd0\n",
           bus->name, (unsigned int)DT_PROP(DT_ALIAS(temp_i2c), clock_frequency));
#else
    printk("BMP280 probe v1: software I2C, chip-ID register=0xd0\n");
#endif
    /* Only the BMP280's two legal addresses; reject a BME280 (ID 0x60). */
    for (uint8_t address = 0x76; address <= 0x77; address++) {
        uint8_t id = 0xff;
        sensor_address = address;
        int rc = sensor_read(0xd0, &id, 1);
        if (rc < 0) {
            printk("BMP280 probe: addr=0x%02x read_rc=%d (no chip ID read)\n", address, rc);
            if (!read_failures) first_error = rc;
            read_failures++;
        } else {
            printk("BMP280 probe: addr=0x%02x read_rc=0 chip_id=0x%02x\n", address, id);
            if (id == 0x60) {
                printk("BMP280 probe: BME280 ID 0x60 detected; this app requires BMP280 ID 0x58\n");
            }
        }
        if (rc == 0 && id == BMP280_CHIP_ID) {
            found = address;
            matches++;
        }
        if (rc < 0) (void)stop();
    }
    if (matches != 1) {
        sensor_address = 0;
        if (read_failures == 2) return first_error;
        return matches ? -EINVAL : -ENODEV;
    }
    sensor_address = found;
    TRY(sensor_write(0xe0, 0xb6)); /* soft reset */
    k_msleep(3);
    TRY(wait_sensor_idle(0x01)); /* NVM calibration copy complete */
    uint8_t bytes[6];
    TRY(sensor_read(0x88, bytes, sizeof(bytes)));
    bool all_zero = true, all_ff = true;
    for (size_t n = 0; n < sizeof(bytes); n++) {
        all_zero = all_zero && bytes[n] == 0;
        all_ff = all_ff && bytes[n] == 0xff;
    }
    if (all_zero || all_ff) return -EIO;
    calibration = bmp280_decode_temperature_calibration(bytes);
    TRY(sensor_write(0xf5, 0x00)); /* IIR off; remain in sleep until triggered */
    printk("External BMP280 found at I2C address 0x%02x\n", sensor_address);
    return 0;
}

static int temperature(int32_t *micro_c)
{
    /* Forced measurement: temperature x1, pressure skipped, then sleep. */
    TRY(sensor_write(0xf4, 0x21));
    k_msleep(10);
    TRY(wait_sensor_idle(0x09)); /* measuring and im_update clear */
    uint8_t bytes[3];
    TRY(sensor_read(0xfa, bytes, sizeof(bytes)));
    uint32_t raw = ((uint32_t)bytes[0] << 12) |
                   ((uint32_t)bytes[1] << 4) | (bytes[2] >> 4);
    if (raw == 0x80000) return -EIO; /* skipped/uninitialized sample */
    int32_t centi_c = bmp280_temperature_centi_c(raw, &calibration);
    if (centi_c < -4000 || centi_c > 8500) return -ERANGE;
    *micro_c = centi_c * 10000; /* transport scale, native result is 0.01 C */
    return 0;
}


static bool configured;
int lp_sensor_sample(int32_t *micro_c)
{
#ifdef CONFIG_LP_SOFT_I2C
    if(!device_is_ready(gpio))return -ENODEV;
#endif
    int rc=0;
    if(!configured){rc=configure_sensor();configured=(rc==0);}
    if(rc==0)rc=temperature(micro_c);
    if(rc<0){(void)stop();configured=false;}
    return rc;
}
void lp_sensor_sleep(void)
{ if(sensor_address)(void)sensor_write(0xf4,0);(void)stop(); }
