#!/usr/bin/env python3
"""Read-only Linux boot/DT report; does not select or start firmware."""
import json
import platform
from pathlib import Path


def read(path):
    try:
        return path.read_bytes()
    except OSError:
        return None


def text(path):
    data = read(path)
    return data.replace(b"\0", b"\n").decode(errors="replace").strip() if data is not None else None


root = Path("/sys/firmware/devicetree/base")
report = {
    "kernel": platform.release(),
    "model": text(root / "model"),
    "compatible": text(root / "compatible"),
    "cmdline": text(Path("/proc/cmdline")),
    "dt_bootargs": text(root / "chosen/bootargs"),
    "mcore_profile": text(Path("/etc/nxp-lp/board.json")),
    "remoteprocs": [],
}
phandles = {}
for prop in root.rglob("phandle"):
    data = read(prop)
    if data is not None and len(data) == 4:
        phandles[int.from_bytes(data, "big")] = prop.parent
for core in sorted(Path("/sys/class/remoteproc").glob("remoteproc*")):
    node = core / "device/of_node"
    item = {"device": str(core), "name": text(core / "name"), "state": text(core / "state"),
            "firmware": text(core / "firmware"), "compatible": text(node / "compatible"),
            "of_node": str(node.resolve()), "memory_regions": []}
    data = read(node / "memory-region") or b""
    for offset in range(0, len(data), 4):
        region = phandles.get(int.from_bytes(data[offset:offset + 4], "big"))
        if region is not None:
            reg = read(region / "reg")
            item["memory_regions"].append({"node": str(region.relative_to(root)),
                "reg_hex": reg.hex() if reg is not None else None,
                "no_map": (region / "no-map").exists()})
    report["remoteprocs"].append(item)
print(json.dumps(report, indent=2))
