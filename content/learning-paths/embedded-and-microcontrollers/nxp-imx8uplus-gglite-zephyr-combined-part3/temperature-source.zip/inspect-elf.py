#!/usr/bin/env python3
"""Reject incompatible remoteproc artifacts before copying them to the board."""
import struct
import sys
from pathlib import Path

from elftools.elf.elffile import ELFFile


def require(condition, message):
    if not condition:
        raise ValueError(message)


def in_tcm(address, size):
    return any(base <= address and address + size <= base + 0x20000
               for base in (0, 0x20000000))


def inspect(path):
    with path.open("rb") as stream:
        elf = ELFFile(stream)
        require(elf.elfclass == 32 and elf.little_endian and
                elf["e_machine"] == "EM_ARM", "expected ELF32 little-endian ARM")
        require(elf["e_type"] == "ET_EXEC", "expected an executable ELF")
        require(in_tcm(elf["e_entry"] & ~1, 2), "entry point is outside TCM")
        loads = [s for s in elf.iter_segments() if s["p_type"] == "PT_LOAD" and s["p_memsz"]]
        require(loads, "no loadable segments")
        for segment in loads:
            address, size = segment["p_paddr"], segment["p_memsz"]
            require(segment["p_filesz"] <= size, "invalid segment sizes")
            require(in_tcm(address, size), f"PT_LOAD outside TCM: {address:#x}+{size:#x}")
            print(f"PT_LOAD da={address:#010x} filesz={segment['p_filesz']:#x} memsz={size:#x}")
        vectors = next((s for s in loads if s["p_paddr"] == 0 and s["p_filesz"] >= 8), None)
        require(vectors is not None, "missing reset vectors at ITCM address zero")
        sp, reset = struct.unpack_from("<II", vectors.data())
        require(0x20000000 < sp <= 0x20020000 and sp % 8 == 0, "invalid DTCM initial stack")
        require(reset & 1 and in_tcm(reset & ~1, 2), "invalid Thumb reset vector")
        table = elf.get_section_by_name(".resource_table")
        require(table is not None and in_tcm(table["sh_addr"], table["sh_size"]),
                "missing TCM resource table")
        data = table.data()
        require(len(data) >= 20, "truncated resource table")
        require(struct.unpack_from("<4I", data) == (1, 1, 0, 0), "unexpected resource-table header")
        offset, = struct.unpack_from("<I", data, 16)
        require(offset >= 20 and offset + 68 <= len(data), "truncated RPMsg resource")
        require(struct.unpack_from("<2I", data, offset) == (3, 7), "expected RPMsg virtio device")
        require(data[offset + 25] == 2, "expected two vrings")
        for index in range(2):
            da, align, count, _, reserved = struct.unpack_from("<5I", data, offset + 28 + 20 * index)
            require(da == 0xffffffff and align == 16 and count == 8 and reserved == 0,
                    "expected host-allocated eight-entry vrings aligned to 16 bytes")
        symbols = elf.get_section_by_name(".symtab")
        require(symbols is not None, "retain the unstripped ELF for clock verification")
        clock = symbols.get_symbol_by_name("SOC_ClockInit") or []
        require(len(clock) == 1 and clock[0]["st_info"]["bind"] == "STB_GLOBAL",
                "FRDM strong SOC_ClockInit override is missing (upstream weak initializer is unsafe)")
        print(f"Vectors SP={sp:#010x} reset={reset:#010x}; resource table={table['sh_addr']:#x}")
        print("PASS: TCM ELF and strong clock override; Linux DT/boot setup still require board verification.")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("Usage: inspect-elf.py path/to/zephyr.elf")
    try:
        inspect(Path(sys.argv[1]))
    except (ValueError, OSError, struct.error) as error:
        sys.exit(f"FAIL: {error}")
