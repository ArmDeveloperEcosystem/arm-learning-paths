/* SPDX-License-Identifier: Apache-2.0 */

#include <errno.h>
#include <stdint.h>
#include <string.h>

#include <zephyr/cache.h>
#include <zephyr/device.h>
#include <zephyr/drivers/flash.h>
#include <zephyr/kernel.h>
#include <zephyr/sys/crc.h>

#define MAILBOX_ADDRESS 0x20080000u
#define DATA_ADDRESS 0x20081000u
#define MAX_CHUNK_SIZE 0x10000u
#define SECTOR_SIZE 4096u

#define MAILBOX_MAGIC 0x4f535049u
#define MAILBOX_VERSION 1u

#define COMMAND_NONE 0u
#define COMMAND_ERASE 1u
#define COMMAND_WRITE 2u

#define STATUS_READY 0x52454144u
#define STATUS_BUSY 0x42555359u
#define STATUS_DONE 0x444f4e45u
#define STATUS_ERROR 0x45525221u

struct mailbox {
	uint32_t magic;
	uint32_t version;
	uint32_t command;
	uint32_t status;
	uint32_t offset;
	uint32_t length;
	uint32_t expected_crc;
	int32_t result;
	uint32_t sequence;
	uint32_t max_chunk_size;
};

static volatile struct mailbox *const mailbox =
	(volatile struct mailbox *)MAILBOX_ADDRESS;
static uint8_t verify_buffer[1024];

static void invalidate_mailbox(void)
{
	sys_cache_data_invd_range((void *)mailbox, sizeof(*mailbox));
}

static void flush_mailbox(void)
{
	sys_cache_data_flush_range((void *)mailbox, sizeof(*mailbox));
}

static int verify_written_data(const struct device *flash_dev, uint32_t offset,
			       const uint8_t *expected, uint32_t length)
{
	uint32_t position = 0;

	while (position < length) {
		const uint32_t count = MIN(length - position, sizeof(verify_buffer));
		int rc = flash_read(flash_dev, offset + position, verify_buffer, count);

		if (rc != 0) {
			return rc;
		}
		if (memcmp(verify_buffer, expected + position, count) != 0) {
			return -EIO;
		}
		position += count;
	}

	return 0;
}

int main(void)
{
	const struct device *flash_dev = DEVICE_DT_GET(DT_ALIAS(spi_flash0));

	mailbox->magic = MAILBOX_MAGIC;
	mailbox->version = MAILBOX_VERSION;
	mailbox->command = COMMAND_NONE;
	mailbox->status = device_is_ready(flash_dev) ? STATUS_READY : STATUS_ERROR;
	mailbox->offset = 0;
	mailbox->length = 0;
	mailbox->expected_crc = 0;
	mailbox->result = device_is_ready(flash_dev) ? 0 : -ENODEV;
	mailbox->sequence = 0;
	mailbox->max_chunk_size = MAX_CHUNK_SIZE;
	flush_mailbox();

	if (!device_is_ready(flash_dev)) {
		return -ENODEV;
	}

	for (;;) {
		invalidate_mailbox();
		if (mailbox->command == COMMAND_NONE) {
			k_busy_wait(1000);
			continue;
		}

		const uint32_t command = mailbox->command;
		const uint32_t offset = mailbox->offset;
		const uint32_t length = mailbox->length;
		const uint32_t expected_crc = mailbox->expected_crc;
		const uint32_t sequence = mailbox->sequence;
		int result = -EINVAL;

		mailbox->command = COMMAND_NONE;
		mailbox->status = STATUS_BUSY;
		mailbox->result = 0;
		flush_mailbox();

		if (command == COMMAND_ERASE && length != 0 &&
		    offset % SECTOR_SIZE == 0 && length % SECTOR_SIZE == 0) {
			result = flash_erase(flash_dev, offset, length);
		} else if (command == COMMAND_WRITE && length != 0 &&
			   length <= MAX_CHUNK_SIZE) {
			const uint8_t *const data = (const uint8_t *)DATA_ADDRESS;

			sys_cache_data_invd_range((void *)data, length);
			if (crc32_ieee(data, length) != expected_crc) {
				result = -EBADMSG;
			} else {
				result = flash_write(flash_dev, offset, data, length);
				if (result == 0) {
					result = verify_written_data(
						flash_dev, offset, data, length);
				}
			}
		}

		mailbox->result = result;
		mailbox->status = result == 0 ? STATUS_DONE : STATUS_ERROR;
		mailbox->sequence = sequence;
		flush_mailbox();
	}
}
