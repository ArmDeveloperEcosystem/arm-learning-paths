#!/usr/bin/env bash
# Offline checks only: this script does not build images or call AWS.
set -euo pipefail
if [[ $# != 1 ]]; then
    echo "Usage: PYTHON=python3.12 $0 /path/to/services" >&2
    exit 2
fi
repo=$(cd -- "$1" && pwd)
python=${PYTHON:-python3}
"$python" -c 'import sys; sys.exit(sys.version_info < (3, 12))' || {
    echo "Set PYTHON to a Python 3.12+ executable." >&2
    exit 1
}
"$python" -c 'import yaml' || {
    echo "Install PyYAML in the selected Python environment first." >&2
    exit 1
}
for file in deployments/aws/deployment.sh deployments/aws/env/env.bash \
            deployments/debian/deployment.sh end-to-end/end-to-end-aws; do
    bash -n "$repo/$file"
done
if command -v zsh >/dev/null 2>&1; then
    zsh -n "$repo/deployments/aws/env/env.zsh"
else
    echo "SKIP: Zsh syntax check (zsh is not installed)"
fi
"$python" - "$repo" <<'PY'
import ast
from pathlib import Path
import sys
root = Path(sys.argv[1])
for relative in ("deployments/aws/bin/veraison", "deployments/aws/misc/sentinel-commands"):
    ast.parse((root / relative).read_text(), filename=relative)
print("Python and shell syntax checks passed.")
PY
PYTHONDONTWRITEBYTECODE=1 "$python" -m unittest discover -s "$repo/deployments/aws/tests" -v
if command -v packer >/dev/null 2>&1; then
    for file in "$repo"/deployments/aws/templates/*.pkr.hcl; do
        packer validate -syntax-only "$file"
    done
else
    echo "SKIP: Packer syntax check (packer is not installed)"
fi
git -C "$repo" diff --check
echo "Offline verification completed."
