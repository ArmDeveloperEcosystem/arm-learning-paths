# Investigation coverage

| Observed issue or workaround | Delivered source change |
| --- | --- |
| `VERAISON_DEB: unbound variable` | Empty default plus an unset-safe check; unset and empty both build a package; an explicit path uses add-deb |
| `ensurepip` missing after bootstrap selected the Yocto venv's Python | Ubuntu uses /usr/bin/python3 unless explicitly overridden; install python3-venv; require Python 3.12+; document a fresh dedicated venv |
| Make bootstrap sourced an environment in a separate recipe shell | Source the environment and run bootstrap in the same shell; apply the same fix to really-clean |
| Python envsubst console script intercepted GNU envsubst's variable-list argument | Remove the Python dependency, expand AWS templates with string.Template, uninstall the legacy package from the dedicated venv during bootstrap, retain GNU gettext for native/Debian scripts |
| boto3 NoRegionError despite VERAISON_AWS_REGION | Export AWS_DEFAULT_REGION/AWS_REGION from the account configuration and pass the configured region into boto3 setup |
| A valid .deb was created but create-deb could not find its path | Emit and parse a stable VERAISON_DEB= marker instead of dpkg's translated human output or old package name; quote paths and check the reported file exists |
| Sentinel Packer Missing item separator | Add the two missing commas to the inline command list |
| ElastiCache rejected cache.t2.micro | Change the support stack's default to cache.t4g.micro, the replacement used successfully in this investigation |
| RDS rejected unencrypted connections | Use sslmode=require in the generated sentinel CoRIM-store DSN and both service-store DSNs |
| Updated CoRIM-store no longer accepts the old pg driver name | Configure pgx on the sentinel and services |
| Services image used obsolete ta-store/en-store and go-plugin configuration | Configure endorsement-store with corim-store and separate scheme/store plugin directories matching the current package layout |
| Sentinel initialized an old schema without the tokens table | Pin the sentinel tool to a2a60b6a11ad, matching services/go.mod, so fresh initialization applies the necessary migrations |
| Failed Go tool installation was followed by a Packer invocation | Check the Go command's result and stop with its captured diagnostics |
| VTS startup failure disappeared when Packer terminated its instance | Print the recent VTS journal if systemctl restart fails, then fail the image build |
| CLI logged CRITICAL errors but deployment continued | Exit 1 on command exceptions; preserve --no-error behavior for best-effort teardown |
| Failed support stack deletion masked the original error with Stack does not exist | Treat expected disappearance during rollback as completion and retain the original creation failure |
| Retrying create-signer-key hit ResourceExistsException despite a cached signer ARN | Verify and reuse the active secret referenced by the cache; do not fetch or replace its private key |
| Status masked an HTTP/API error as KeyError: version | Check HTTP status, JSON shape, required discovery fields, and request timeouts for verification and provisioning discovery |
| Provisioning wrapper masked failed/duplicate submissions | Enable shell failure/pipe handling; a failed first bundle prevents the second submission |
| New clients needed for the CCA flow | Document cocli v0.1.0 and evcli 0e253e8 alongside the current profile-aware flow |
| First and second Learning Path TODO outputs | User captured successful provisioning and stores output in the separate Learning Path; no output transcript is copied into services source |

## Scope decisions

The final source changes consolidate host workarounds into reusable fixes. In
particular, the envsubst symlink workaround is replaced by removing the Python
console-script collision altogether. Additional failure-path handling and tests
cover the errors revealed during the investigation.

The successful binary compatibility check showed a GLIBC_2.34 requirement,
compatible with the existing Ubuntu 22.04 image. The bundle retains that image
baseline and documents compatibility requirements for externally built packages.

Duplicate token rejection is expected behavior. The CoRIM-store library's
manifest deletion leaving a token record is a separate issue in
veraison/corim-store; no broad store-clearing or manual SQL recovery is added to
this services patch set. Existing-deployment migration and token-reset steps
remain one-time operational procedures.
