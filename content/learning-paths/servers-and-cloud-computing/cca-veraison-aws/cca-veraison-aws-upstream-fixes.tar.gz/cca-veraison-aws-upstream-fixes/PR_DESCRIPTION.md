### Description

The AWS deployment fails on a fresh Ubuntu build host and then continues after
errors, producing missing-cache failures that mask the first cause. It also
builds a sentinel with an older CoRIM-store schema and generates service
configuration for an obsolete endorsement-store layout.

This updates bootstrap, package-path reporting, region selection, Packer
templates, PostgreSQL connection settings, and the sentinel tool revision so a
fresh deployment uses the same store schema and plugin layout as the services.
Command failures now stop deployment and provisioning. Discovery and rollback
errors retain useful diagnostics, and an active cached signing key is reused
without replacement. The AWS README documents the fresh deployment flow and
the optional VERAISON_DEB setting.

Validation: the offline regression suite passes; patch application, reruns,
reversal, staged-change preservation, and conflict handling were checked against
the affected files at both supported services revisions. Bash/Zsh, Python,
YAML, and HCL syntax checks passed. No new complete AWS deployment or full Go
build was run for this assembled patch set; the deployment fixes were developed
while bringing up and provisioning a working CCA test deployment.

### Checklist

- [ ] Full Go build and repository CI completed for this PR branch
- [x] Added offline regression tests for observed failures
- [x] Offline regression tests pass
- [x] Extended the AWS README
- [ ] Fresh AWS deployment repeated with the complete assembled changes
