#!/usr/bin/env python3
"""Check/apply/revert the bundled services patches without staging or committing."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys


BUNDLE = Path(__file__).resolve().parent


def git(repo, *args):
    return subprocess.run(["git", "-C", str(repo), *args],
                          text=True, capture_output=True, check=False)


def run():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo", type=Path, help="Path to your local services clone")
    actions = parser.add_mutually_exclusive_group()
    actions.add_argument("--check", action="store_true", help="Dry run (the default)")
    actions.add_argument("--apply", action="store_true", help="Apply pending patches")
    actions.add_argument("--reverse", action="store_true", help="Revert applied patches")
    args = parser.parse_args()
    root = git(args.repo, "rev-parse", "--show-toplevel")
    if root.returncode:
        raise RuntimeError(root.stderr.strip() or "Not a Git working tree")
    repo = Path(root.stdout.strip()).resolve()
    manifest = json.loads((BUNDLE / "manifest.json").read_text())
    if not (repo / "deployments/aws/bin/veraison").is_file():
        raise RuntimeError("The target does not contain the services AWS deployment")
    module = (repo / "go.mod").read_text()
    dependency = re.search(r"^\s*github.com/veraison/corim-store\s+(\S+)", module, re.M)
    if (not args.reverse and
            (dependency is None or not dependency.group(1).endswith(
                "-" + manifest["corim_store_revision"]))):
        raise RuntimeError("go.mod has a different CoRIM-store revision. Review the "
                           "patch pin before applying this bundle.")
    patches = manifest["patches"]
    series = (BUNDLE / "series").read_text().splitlines()
    if series != [entry["file"] for entry in patches]:
        raise RuntimeError("series and manifest.json disagree")
    pending = []
    seen = set()
    print("Target:", repo)
    print("HEAD:", git(repo, "rev-parse", "HEAD").stdout.strip())
    for entry in patches:
        path = BUNDLE / entry["file"]
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != entry["sha256"]:
            raise RuntimeError("Missing or changed patch: " + entry["file"])
        overlap = seen.intersection(entry["paths"])
        if overlap:
            raise RuntimeError("Overlapping patch groups: " + ", ".join(sorted(overlap)))
        seen.update(entry["paths"])
        forward = git(repo, "apply", "--check", "--whitespace=error-all", str(path))
        reverse = git(repo, "apply", "--reverse", "--check", "--whitespace=nowarn", str(path))
        if forward.returncode == 0:
            state = "pending"
            if not args.reverse:
                pending.append(path)
        elif reverse.returncode == 0:
            state = "already applied"
            if args.reverse:
                pending.append(path)
        else:
            raise RuntimeError(
                "Cannot apply or recognize " + entry["file"] + ".\n"
                "The patch group may be partially applied or locally edited. "
                "Use a clean clone or reconcile those files first.\n" + forward.stderr.strip())
        print("  " + entry["file"] + ": " + state)
    if not pending:
        print("No changes needed.")
        return
    reverse_flag = ["--reverse"] if args.reverse else []
    paths = [str(path) for path in pending]
    whitespace = "--whitespace=nowarn" if args.reverse else "--whitespace=error-all"
    checked = git(repo, "apply", *reverse_flag, "--check", whitespace, *paths)
    if checked.returncode:
        raise RuntimeError(checked.stderr.strip())
    if not (args.apply or args.reverse):
        print("Dry run passed. Run again with --apply to update the clone.")
        return
    # Without --reject, git apply leaves the working tree unchanged on conflicts.
    result = git(repo, "apply", *reverse_flag, whitespace, *paths)
    if result.returncode:
        raise RuntimeError(result.stderr.strip())
    print(("Reverted" if args.reverse else "Applied") + " " + str(len(paths)) + " patch groups.")
    print("Review with: git -C " + str(repo) + " diff")


if __name__ == "__main__":
    try:
        run()
    except (OSError, ValueError, RuntimeError) as error:
        print("ERROR:", error, file=sys.stderr)
        sys.exit(1)
