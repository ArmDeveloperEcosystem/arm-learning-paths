# Veraison AWS deployment patch bundle

Target fork: [DougAnsonAustinTX/services](https://github.com/DougAnsonAustinTX/services).
Upstream: [veraison/services](https://github.com/veraison/services).

Both repositories' `main` branches pointed to
`dceb5dd9e3ab14aded6d840309e24486bc5c71bc` when checked on November 14, 2026.
The patches also support the Learning Path's pinned services revision,
`ebadb733d44ba2f8ffefdae49a0f0d3c1bfc9800`. The updater checks the actual
patch context and requires the matching CoRIM-store dependency in `go.mod`.

## Apply to your fork

Run these commands in the directory containing this extracted bundle. Replace
`./services-pr` with the path to an existing clean clone if you already have one.

```bash
git clone https://github.com/DougAnsonAustinTX/services.git services-pr
git -C services-pr switch -c codex/cca-veraison-aws-fixes

./cca-veraison-aws-upstream-fixes/apply.sh --check ./services-pr
./cca-veraison-aws-upstream-fixes/apply.sh --apply ./services-pr
```

The updater defaults to a dry run. It checks every patch before applying the
pending groups in one Git operation. A rerun skips complete groups that are
already applied. It stops on conflicting edits, partially applied groups,
changed patch checksums, or an incompatible CoRIM-store dependency.

The updater changes source files only. It preserves the Git index and unrelated
edits, and does not stage, commit, push, bootstrap the host, or call AWS. A fresh
clone is the simplest target if another clone already contains the earlier
individual patches or manual fixes.

## Verify and prepare your pull request

Use a Python 3.12+ environment with PyYAML installed, such as the existing AWS
deployment venv. For a separate check environment, create it before verification:

```bash
python3.12 -m venv "$HOME/venv/veraison-pr-check"
"$HOME/venv/veraison-pr-check/bin/python" -m pip install PyYAML==6.0.2
PYTHON="$HOME/venv/veraison-pr-check/bin/python" \
  ./cca-veraison-aws-upstream-fixes/verify.sh ./services-pr

git -C services-pr diff --stat
git -C services-pr diff --check
git -C services-pr diff
git -C services-pr status --short
```

The regression test file is new and therefore untracked after application;
`git diff` does not display its contents until it is added to the index. Review
`services-pr/deployments/aws/tests/test_deployment.py` too, and include it when
staging the PR. The updater deliberately leaves staging to you.

The verifier checks Bash/Zsh and Python syntax and runs the offline regression
suite. If Packer is installed, it also runs
[`packer validate -syntax-only`](https://developer.hashicorp.com/packer/docs/commands/validate)
on the image templates. It reports skipped optional tools explicitly.

Suggested PR title: **Fix AWS deployment bootstrap and CoRIM-store integration**.
`PR_DESCRIPTION.md` provides a draft description with the validation limits.
Review and commit the changes, push your branch to your fork, then open the PR
against `veraison/services:main`.

## Bundle contents

| Patch | Changes |
| --- | --- |
| `0001-bootstrap-and-environment.patch` | Python 3.12+ selection, venv/gettext dependencies, shared Make recipe environment, optional package setting, AWS region exports, legacy envsubst cleanup |
| `0002-cli-and-package-build.patch` | Standard-library template expansion, locale-independent package path, failure exit status, checked Go tool build, matching CoRIM-store pin, discovery diagnostics, rollback diagnostics, cached signing-key reuse |
| `0003-aws-templates-and-store-compatibility.patch` | Sentinel HCL commas, current plugins/store configuration, PostgreSQL driver and encryption, supported cache-node default, VTS startup journal |
| `0004-end-to-end-failure-handling.patch` | Stop CCA provisioning at the first failed submission and preserve its nonzero exit status |
| `0005-deployment-regression-tests.patch` | Offline tests for the observed failures and their fixes |
| `0006-aws-quickstart-documentation.patch` | Fresh deployment instructions, generic account settings, optional VERAISON_DEB behavior, pinned clients, duplicate submission behavior, regression command |

`series` lists the patch order. `manifest.json` records paths, checksums, and
baselines. The six groups touch distinct files, allowing preflight checks of the
complete operation. These are working-tree patches for `git apply`, not email
patches for `git am`. All six groups form the complete update.

`COVERAGE.md` maps the investigation's findings to the delivered changes.
`VALIDATION.md` records the checks actually performed.

## Revert an applied bundle

Before making further edits to the patched files, you can revert the complete
bundle with the following command. The same conflict checks apply.

```bash
./cca-veraison-aws-upstream-fixes/apply.sh --reverse ./services-pr
```

The bundle contains no account credentials, domain-specific configuration,
deployed AMI IDs, live-database migrations, or token-deletion instructions.
The Learning Path remains in the separate `arm-learning-paths` repository.
