#!/usr/bin/env bash
set -euo pipefail
BUNDLE_DIR=$(cd -- "$(dirname -- "$0")" && pwd)
exec "${PYTHON:-python3}" "$BUNDLE_DIR/update.py" "$@"
