# Validation performed

Validation date: November 14, 2026.

## Source and patch compatibility

The public fork and upstream main branches were queried directly. Both pointed
to `dceb5dd9e3ab14aded6d840309e24486bc5c71bc`. Patch fixtures were constructed
from the exact Git blobs and file modes for all affected paths, plus go.mod,
at that revision and at the Learning Path pin,
`ebadb733d44ba2f8ffefdae49a0f0d3c1bfc9800`.

For each baseline, the updater passed these checks:

- Dry run leaves source files and the Git index unchanged.
- Applying produces byte-for-byte matches with the reviewed source changes.
- An unrelated staged file and the index's original bytes are preserved.
- A second apply is a no-op.
- Reversal restores the original files, including original whitespace.
- A series with one complete group already applied can be completed.
- A conflict in the final group blocks all earlier groups from being applied.
- A different CoRIM-store dependency blocks the operation.

A deliberately corrupted copied patch was also rejected without changing the
target. The main fixture's clone path contained spaces. Structured results
are in `updater-test-results.json`.

These fixtures verify patch compatibility with the named revisions. They are
not full repository builds or additional AWS deployments.

## Source checks

- All 18 offline regression tests passed under Python 3.13 with PyYAML 6.0.2.
- Seven selected regression cases were run against unpatched source and failed
  as expected. Their diagnostics are in `baseline-regression-proof.log`.
- Bash syntax checks passed for the AWS and Debian deployment scripts, Bash
  environment setup, and the AWS end-to-end wrapper.
- Zsh syntax validation passed for the Zsh environment file.
- Python AST parsing passed for the AWS CLI and sentinel command dispatcher.
- All four AWS text templates rendered using dummy configuration values.
  Rendered services YAML and CloudWatch JSON parsed successfully.
- All three CloudFormation YAML templates parsed with tag-aware YAML loading.
- All three Packer HCL templates parsed with python-hcl2 8.2.0.
- Git whitespace checks passed.

The packaged verifier was run against the patched main fixture; its output is
in `verification.log`. Packer itself was not installed on this validation host,
so its native syntax check was explicitly skipped. The separate HCL parser
check above was performed; it does not validate AWS resources or Packer plugin
configuration. The verifier runs Packer's syntax check when it is available.

## Remaining validation

No full Go build, repository-wide CI run, or new complete AWS deployment was
executed for this assembled patch set. The investigation's deployment and CCA
provisioning succeeded before packaging; the consolidated changes and added
failure handling have been checked locally as described above. The draft PR
description leaves the full-build and fresh-AWS-run items unchecked.
