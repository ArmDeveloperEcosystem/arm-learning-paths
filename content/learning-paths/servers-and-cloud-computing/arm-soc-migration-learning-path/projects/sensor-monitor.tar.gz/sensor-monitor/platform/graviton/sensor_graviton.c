#include <stdlib.h>
#include <time.h>

static int initialized = 0;

int sensor_init(void) {
    srand(time(NULL));
    initialized = 1;
    return 0;
}

float sensor_read_temperature(void) {
    // Simulated sensor for cloud development
    return 20.0 + (rand() % 15);
}

void sensor_cleanup(void) {
    initialized = 0;
}
