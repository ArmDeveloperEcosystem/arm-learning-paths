# Sensor Monitor Application

Sample application for ARM SoC Migration Learning Path.

## Quick Start on Graviton

```bash
# Build
make

# Run
./sensor_monitor
```

## Manual Build

```bash
gcc -o sensor_monitor src/main.c platform/graviton/sensor_graviton.c -Iinclude
./sensor_monitor
```

## Project Structure

- `src/main.c` - Main application logic
- `include/sensor.h` - Sensor interface
- `platform/graviton/` - Graviton-specific implementation
- `platform/rpi5/` - Raspberry Pi 5 target (created during migration)
