#ifndef SENSOR_H
#define SENSOR_H

int sensor_init(void);
float sensor_read_temperature(void);
void sensor_cleanup(void);

#endif
