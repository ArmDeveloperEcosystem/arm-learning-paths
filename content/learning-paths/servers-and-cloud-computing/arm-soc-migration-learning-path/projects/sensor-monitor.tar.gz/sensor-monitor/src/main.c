#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "sensor.h"

int main(void) {
    printf("Sensor Monitor - Graviton Development\n");
    
    if (sensor_init() != 0) {
        fprintf(stderr, "Failed to initialize sensor\n");
        return EXIT_FAILURE;
    }
    
    // Main monitoring loop
    for (int i = 0; i < 10; i++) {
        float temperature = sensor_read_temperature();
        printf("Temperature: %.2f°C\n", temperature);
        sleep(1);
    }
    
    sensor_cleanup();
    return EXIT_SUCCESS;
}
