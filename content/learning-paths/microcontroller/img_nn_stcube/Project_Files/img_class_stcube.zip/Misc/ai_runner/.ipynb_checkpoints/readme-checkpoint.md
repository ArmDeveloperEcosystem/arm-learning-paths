# History

## 8/3/2021

- Copy of the Python module from X-CUBE-AI pack v7.0 (location `$INSTALL_DIR/scripts`)
  Used to replace the previous Python module: stm32nn (see `ui_python_15luglio_ai_runner.py` file)
